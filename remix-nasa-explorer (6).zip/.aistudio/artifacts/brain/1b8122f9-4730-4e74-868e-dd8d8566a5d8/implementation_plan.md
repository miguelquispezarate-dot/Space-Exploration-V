# NASA Explorer — Guía de Inicio, Selector Celular/Laptop, Cameo de Helio, Modelos Históricos Animados y Superficies Sin Cortes

Plan integral para corregir el espacio negro inferior en la Luna y Marte en cualquier pantalla, añadir una introducción interactiva con selector de formato **Celular / Laptop / Auto** desde el inicio, integrar breves apariciones temporales del personaje **Helio** adaptado al dispositivo sin obstruir la vista, representar los artefactos como miniaturas vectoriales cuya animación responde fielmente a su historia real, hacer minimizable la telemetría ambiental e incorporar cuatro herramientas científicas interactivas.

## User Review & Critical Decisions

> [!IMPORTANT]
> Todos los requerimientos originales y las tres revisiones del usuario quedan integrados en este plan:

- **Personaje Guía "Helio" (Aparición Breve y Adaptable)**: Se integra la ilustración original de **Helio** (`/assets/aistudio/image_2b17453d.png`) sin alterar su diseño ni proporciones, encuadrada con precisión dentro de un módulo espacial calibrado en escala reducida para celular y más amplia para laptop. Aparece solo **unos segundos** (con desvanecimiento automático y cierre manual inmediato) en momentos clave —al iniciar en la plataforma del cohete SLS y al llegar al Sistema Solar, la Luna o Marte— para dar la bienvenida o un dato breve de la dinámica sin tapar jamás el cohete ni el terreno.
- **Selector de Formato al Comienzo (`Celular` · `Laptop` · `Auto`)**: Ubicado directamente en la pantalla de inicio (y cambiable en cualquier momento), adapta la densidad de paneles, tamaño de controles, escala de Helio y encuadre del visor entre formato celular y laptop.
- **Introducción Interactiva ("Cómo funciona")**: Guía clara al inicio que explica en 3 pasos la dinámica de la app: (1) Ignición en plataforma LC-39A, (2) Presionar un planeta en órbita para leer su historia, y (3) Explorar dentro de la Luna y Marte interactuando con sus artefactos.
- **Modelos en Miniatura con Movimiento Fiel a la Historia Real**: En lugar de simples puntos, los artefactos muestran una versión reducida del objeto real; **solo se mueven los que siguen activos según su historia**, mientras que los dañados, atascados o apagados reflejan visualmente su avería o reposo real.
- **Panorama HD Generado + Zoom Libre Sin Cortes Negros + Telemetría Minimizable + 4 Herramientas Científicas**: Cielo infinito y terreno procedural extendido en el 100% del alto de pantalla, telemetría plegable/reactivable, control solar/sombras, línea temporal histórica, mini-mapa radar y comparador de gravedad.

---

## 1. Overview & Core Concept

- **Cameo Dinámico de Helio (Sin Obstrucción)**:
  - **En Plataforma y Cohete SLS**: Al abrir la app o iniciar la ignición, Helio aparece brevemente (~4.5 segundos) en una esquina discreta junto al cohete como copiloto/guía de misión con un mensaje corto de bienvenida, reduciendo automáticamente su tamaño en modo celular para dejar despejado el lanzamiento.
  - **En Órbita, Luna y Marte**: Al aterrizar en un nuevo escenario, realiza un cameo breve (~4 segundos) con una indicación contextual (ej. tocar un planeta o pulsar cualquier robot en la superficie) y luego se oculta solo suavemente. Si el usuario desea volver a verlo brevemente, puede pulsar un botón discreto en el HUD, sin ocupar espacio permanente en pantalla.
  - **Fidelidad Visual al Dibujo**: Se utiliza la imagen original `/assets/aistudio/image_2b17453d.png` directamente con encuadre proporcionado (`object-cover` enfocado en su rostro e insignia NASA sin deformar ni reescribir la ilustración), integrada con marco oscuro `#0b101b` y borde cian/ámbar sutil acorde a la paleta de la aplicación.
- **Dinámica Guiada Desde el Inicio**: La pantalla de lanzamiento presenta una **introducción visual de 3 pasos** junto al **selector de formato (`Auto` / `Laptop` / `Celular`)**, dejando clara toda la interacción desde el primer segundo.
- **Cobertura Total de Pantalla (Cero Franja Negra)**: Al separar el cielo infinito y el terreno extendido respecto al horizonte panorámico HD, la superficie de la Luna y Marte cubre el 100% del alto del visor en cualquier zoom o tamaño de ventana.
- **Movimiento Coherente con la Historia Real de Cada Artefacto**:
  - *Activos con movimiento en Marte*: **Perseverance** (patrullaje suave con ruedas girando, escaneo de mástil y pulso láser) y **Curiosity** (avance lento con ligera vibración por sus ruedas desgastadas tras más de 32 km).
  - *Averiados, atascados o silenciosos en Marte (Sin desplazamiento)*: **Ingenuity** (posado e inclinado en duna con una punta de pala dañada tras su vuelo 72 y leve vaivén por el viento, sin volar), **Spirit** (semihundido en arena blanda con rueda bloqueada), **Opportunity** (estacionado bajo polvo tenue), **Viking 1** (antena orientada fuera de eje), **InSight**, **Phoenix** y **Pathfinder/Sojourner** en reposo fiel.
  - *Luna*: **Retrorreflector LRRR** reflejando periódicamente un haz láser desde la Tierra (activo hoy); demás módulos, rovers LRV, batería SNAP-27, telescopio UV, Surveyor 3, pelotas de golf, huellas y Astronauta Caído en reposo con sombra solar direccional.

---

## 2. User Experience & Visual Design

### Flujos Principales de Usuario

1. **Inicio en Plataforma LC-39A (Cameo de Helio + Guía + Selector de Formato)**:
   - El usuario elige o conserva el formato (**Auto · Laptop · Celular**) desde el comienzo:
     - *Celular*: Adapta el visor a ergonomía móvil compacta, reduce la escala de Helio a formato compacto, minimiza la telemetría por defecto en superficie y sitúa los controles en la zona inferior del pulgar.
     - *Laptop*: Usa el diseño panorámico completo con consola lateral/superior expandida.
     - *Auto*: Se adapta en vivo al tamaño de la ventana.
   - Helio realiza una breve aparición de bienvenida (~4.5 s) que desaparece automáticamente para no tapar el cohete SLS ni el despegue.
   - Una tarjeta clara de **"Cómo funciona la exploración"** resume los 3 pasos (Ignición → Elegir planeta → Explorar Luna y Marte).
2. **Navegación en Superficie (Luna y Marte) Sin Cortes**:
   - El panorama HD generado cubre el horizonte mientras el cielo superior y el regolito inferior se extienden hasta los bordes extremos de la pantalla en todo zoom (`0.45x` a `2.4x`).
   - El panel de **telemetría ambiental** (temperatura, gravedad, presión, ciclo y radiación) se minimiza y reactiva con 1 toque tanto en celular como en laptop.
3. **Interacción con Modelos y 4 Herramientas Científicas**:
   - Tocar cualquier miniatura SVG (hitbox táctil $\ge 48 \times 48\text{px}$) abre su expediente histórico completo.
   - **Control Solar (0°–180°)**: Modula iluminación del cielo, dirección de sombras del terreno/robots y temperatura superficial en vivo.
   - **Línea Temporal (1967–2024)**: Recorre cronológicamente los aterrizajes y centra la cámara en cada hito.
   - **Mini-Mapa Radar**: Muestra el sector de 3800 px con visor arrastrable sincronizado.
   - **Comparador de Gravedad**: Calcula peso en Newtons, peso percibido y altura de salto en Tierra, Luna y Marte.

### Identidad Visual, Color y Ergonomía

- **Sistema Visual**: Estética aeroespacial 60-30-10 (`#07090e` obsidiana, paneles `#0b101b` con borde `#1e293b`, acento ámbar `#f59e0b`, esmeralda para activos y cian para elementos de Helio/visitados).
- **Tipografía Tabular**: `Plus Jakarta Sans` en títulos, `IBM Plex Sans` en lectura e `IBM Plex Mono` (`tabular-nums`) para métricas y fechas.
- **Limpieza y Accesibilidad**: Cero píldoras decorativas; animaciones suaves GPU (`transform`, `opacity`) respetando `prefers-reduced-motion`; objetivos táctiles $\ge 44 \times 44\text{px}$.

---

## 3. Key Product Decisions & Trade-Offs

- **Decisión 1: Cameo Temporal No Obstructivo para Helio**
  - *Enfoque elegido*: Renderizar a Helio en un componente flotante temporal con temporizador automático (4–4.5 s), cierre con 1 toque, posicionamiento seguro en esquina opuesta a los controles y escala adaptada al dispositivo (avatar compacto ~44–48 px en celular, ~64 px en laptop).
  - *Por qué*: Aporta personalidad narrativa y guía sin invadir jamás el cohete, los planetas o los artefactos de superficie, y mantiene intacta la proporción original de la ilustración.

- **Decisión 2: Animación Diferenciada por Estado Histórico Real**
  - *Enfoque elegido*: Vincular explícitamente la animación de cada miniatura SVG con su estado documental (patrullaje en Perseverance, marcha lenta en Curiosity, pulso láser en LRRR vs. pala dañada en Ingenuity, rueda atascada en Spirit y reposo en el resto).
  - *Por qué*: Enseña visualmente por qué unos equipos siguen operativos y otros quedaron detenidos por averías o polvo.

- **Decisión 3: Composición Híbrida HD + Extensión Procedural Sin Costuras**
  - *Enfoque elegido*: Combinar 2 panoramas HD generados (Luna y Marte) centrados en la línea de horizonte con cielo infinito arriba y terreno procedural continuo abajo en un único Canvas de pantalla completa.
  - *Por qué*: Elimina completamente la franja negra inferior a cualquier zoom o tamaño de ventana.

---

## 4. Technical Architecture & Data Strategy

### Diagrama de Arquitectura del Sistema

```
┌───────────────────────────────────────────────────────────────────────────┐
│        Shell Global · Formato (Auto / Laptop / Celular) + Cameo Helio     │
│   [TopBar: Navegación · Selector Formato · Idioma · Audio · Archivo]      │
│   [HelioGuide: Aparición breve 4.5s adaptable en tamaño, cierre auto]     │
└───────────────────────────────────┬───────────────────────────────────────┘
                                    │
          ┌─────────────────────────┼─────────────────────────┐
          ▼                         ▼                         ▼
┌───────────────────┐     ┌───────────────────┐     ┌───────────────────────┐
│  Plataforma Inicio│     │   Sistema Solar   │     │   Superficie Planeta  │
│  • Guía 3 Pasos   │────▶│  • Órbitas 2D     │────▶│  • Luna / Marte       │
│  • Selector Modo  │     │  • Ficha Planeta  │     │  • Panorama HD +      │
│  • Cohete SLS     │     │  • Descenso       │     │    Cielo/Suelo 100dvh │
└───────────────────┘     └───────────────────┘     └───────────┬───────────┘
                                                                │
                    ┌───────────────────────────────────────────┴───────────┐
                    ▼                                                       ▼
      ┌───────────────────────────────────┐     ┌───────────────────────────────────┐
      │  Miniaturas SVG Históricas        │     │  HUD Plegable y 4 Herramientas    │
      │  • Activos: Perseverance,         │     │  • Telemetría Minimizable         │
      │    Curiosity (marcha), LRRR (luz) │     │  • Control Solar (Sombras/Temp)   │
      │  • Averiados/Fijos: Ingenuity     │     │  • Línea Temporal (1967–2024)     │
      │    (pala dañada), Spirit (arena), │     │  • Mini-Mapa Radar Arrastrable    │
      │    Opportunity, Viking 1, Apolo   │     │  • Comparador de Gravedad (kg/N)  │
      └───────────────────────────────────┘     └───────────────────────────────────┘
```

### Estrategia de Activos Visuales

- **Imagen Existente de Helio**: Uso directo de `/assets/aistudio/image_2b17453d.png` (sin modificar ni regenerar el dibujo original), recortado limpiamente por CSS `object-cover` con foco facial para el badge de cameo.
- **2 Panoramas HD Generados en Lote Paralelo** (`16:9`, sin texto ni UI):
  1. **Panorama Lunar HD**: Paisaje lunar amplio con montañas Apeninos, cráteres, regolito gris basalto y cielo negro espacial con la Tierra en el horizonte.
  2. **Panorama Marciano HD**: Paisaje marciano del cráter Jezero con colinas estratificadas en óxido de hierro, cielo caramelo-salmón y dunas rojas.

### Modelo de Datos y Mapeo Interactivo

- **Estado Global de Formato (`displayMode`: `'auto' | 'laptop' | 'mobile'`)**: Controla la geometría del contenedor raíz, escala de Helio y postura colapsable de paneles desde el inicio.
- **Estado de Cameo de Helio (`helioVisible`, `helioContext`)**: Temporizador de 4.5 segundos por transición de pantalla o momento de ignición, cancelable con clic o automáticamente al finalizar, evitando obstruir interacciones.
- **Metadatos Históricos de Animación (`behaviorState`)**: Define la animación o quietud fiel a la historia de cada objeto (`patrol_active`, `slow_worn_drive`, `damaged_rotor_wind`, `stuck_in_sand`, `dust_hibernation`, `misaligned_antenna`, `laser_bounce`, `polar_frost`, `static_heritage`).
- **Motor de Cámara y Cobertura Total**: La transformación `(offsetX, offsetY, zoom)` proyecta el horizonte panorámico HD y las miniaturas respecto al horizonte centrado, mientras el cielo superior y el regolito inferior se dibujan de borde a borde cubriendo el 100% del alto del contenedor en todo momento.
