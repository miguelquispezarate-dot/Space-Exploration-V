/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useState } from 'react';
import type { DisplayMode, Language, ScreenView, SurfaceBodyId } from './types/nasa';
import { NASA_SURFACE_HOTSPOTS } from './data/nasaData';
import { nasaAudio } from './utils/audio';
import { TopBar } from './components/TopBar';
import { LaunchpadView, type LaunchDestination } from './components/LaunchpadView';
import { SolarSystemView } from './components/SolarSystemView';
import { SurfaceView } from './components/SurfaceView';
import { EncyclopediaDrawer } from './components/EncyclopediaDrawer';

const VISITED_STORAGE_KEY = 'nasa_explorer_visited_artifacts_v1';

export default function App() {
  const [lang, setLang] = useState<Language>('es');
  const [screen, setScreen] = useState<ScreenView>('launch');
  const [surfaceBody, setSurfaceBody] = useState<SurfaceBodyId>('moon');
  const [encyclopediaOpen, setEncyclopediaOpen] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [displayMode, setDisplayMode] = useState<DisplayMode>('auto');
  const [windowWidth, setWindowWidth] = useState<number>(() =>
    typeof window !== 'undefined' ? window.innerWidth : 1280
  );

  const [visitedIds, setVisitedIds] = useState<Set<string>>(() => {
    try {
      const raw = localStorage.getItem(VISITED_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return new Set(parsed);
      }
    } catch {
      // Ignore storage errors
    }
    return new Set<string>();
  });

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    const onResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && encyclopediaOpen) {
        setEncyclopediaOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [encyclopediaOpen]);

  const isMobileLayout =
    displayMode === 'mobile' || (displayMode === 'auto' && windowWidth < 768);
  const usePhoneFrame = displayMode === 'mobile' && windowWidth > 460;

  const handleMarkVisited = (id: string) => {
    setVisitedIds((prev) => {
      if (prev.has(id)) return prev;
      const next = new Set(prev);
      next.add(id);
      try {
        localStorage.setItem(VISITED_STORAGE_KEY, JSON.stringify([...next]));
      } catch {
        // Ignore storage errors
      }
      return next;
    });
  };

  const visitedCountByBody = useMemo(
    () => ({
      moon: NASA_SURFACE_HOTSPOTS.moon.filter((s) => visitedIds.has(s.id)).length,
      mars: NASA_SURFACE_HOTSPOTS.mars.filter((s) => visitedIds.has(s.id)).length,
    }),
    [visitedIds]
  );

  const totalCountByBody = useMemo(
    () => ({
      moon: NASA_SURFACE_HOTSPOTS.moon.length,
      mars: NASA_SURFACE_HOTSPOTS.mars.length,
    }),
    []
  );

  const handleNavigateScreen = (nextScreen: ScreenView, nextSurface?: SurfaceBodyId) => {
    nasaAudio.playTelemetryChirp(820);
    if (nextSurface) {
      setSurfaceBody(nextSurface);
    }
    setScreen(nextScreen);
  };

  const handleLiftoffComplete = (destination: LaunchDestination) => {
    if (destination === 'moon' || destination === 'mars') {
      setSurfaceBody(destination);
      setScreen('surface');
    } else {
      setScreen('solar');
    }
  };

  const handleToggleAudio = () => {
    const next = !audioEnabled;
    setAudioEnabled(next);
    nasaAudio.setEnabled(next);
    if (next) nasaAudio.playTelemetryChirp(980);
  };

  const handleToggleLang = () => {
    nasaAudio.playTelemetryChirp(880);
    setLang((prev) => (prev === 'es' ? 'en' : 'es'));
  };

  return (
    <div className="h-dvh w-full overflow-hidden bg-[#03050a] text-slate-50">
      <div
        className={`relative h-full overflow-hidden bg-[#07090e] ${
          usePhoneFrame
            ? 'mx-auto w-full max-w-[430px] border-x border-slate-800 shadow-[0_0_60px_rgba(0,0,0,0.9)]'
            : 'w-full'
        }`}
        style={usePhoneFrame ? { transform: 'translateZ(0)' } : undefined}
      >
        <TopBar
          lang={lang}
          onToggleLang={handleToggleLang}
          currentScreen={screen}
          currentSurface={surfaceBody}
          onNavigateScreen={handleNavigateScreen}
          onToggleEncyclopedia={() => {
            nasaAudio.playTelemetryChirp(850);
            setEncyclopediaOpen((v) => !v);
          }}
          audioEnabled={audioEnabled}
          onToggleAudio={handleToggleAudio}
          displayMode={displayMode}
          onChangeDisplayMode={setDisplayMode}
          isMobileLayout={isMobileLayout}
        />

        <main className="h-full w-full">
          {screen === 'launch' && (
            <LaunchpadView
              lang={lang}
              isActive={screen === 'launch'}
              onLiftoffComplete={handleLiftoffComplete}
              onQuickNavigate={handleNavigateScreen}
              displayMode={displayMode}
              onChangeDisplayMode={setDisplayMode}
              isMobileLayout={isMobileLayout}
            />
          )}

          {screen === 'solar' && (
            <SolarSystemView
              lang={lang}
              isActive={screen === 'solar'}
              onDiveSurface={(target) => {
                setSurfaceBody(target);
                setScreen('surface');
              }}
              visitedCountByBody={visitedCountByBody}
              totalCountByBody={totalCountByBody}
              isMobileLayout={isMobileLayout}
            />
          )}

          {screen === 'surface' && (
            <SurfaceView
              lang={lang}
              body={surfaceBody}
              onChangeBody={(b) => setSurfaceBody(b)}
              visitedIds={visitedIds}
              onMarkVisited={handleMarkVisited}
              isMobileLayout={isMobileLayout}
            />
          )}
        </main>

        <EncyclopediaDrawer
          lang={lang}
          isOpen={encyclopediaOpen}
          onClose={() => setEncyclopediaOpen(false)}
        />
      </div>
    </div>
  );
}
