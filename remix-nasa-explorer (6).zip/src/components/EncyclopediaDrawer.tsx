import React, { useMemo, useState } from 'react';
import { Award, BookOpen, CheckCircle2, RotateCcw, Search, X, XCircle } from 'lucide-react';
import type { EncyclopediaTabId, Language } from '../types/nasa';
import {
  NASA_ENCYCLOPEDIA_ARTICLES,
  NASA_QUIZ_QUESTIONS,
  UI_COPY,
} from '../data/nasaData';
import { nasaAudio } from '../utils/audio';

interface EncyclopediaDrawerProps {
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
}

const TABS: Array<{
  id: EncyclopediaTabId;
  copyKey: 'tabApollo' | 'tabMars' | 'tabDeep' | 'tabConcepts' | 'tabQuiz';
}> = [
  { id: 'apollo', copyKey: 'tabApollo' },
  { id: 'mars', copyKey: 'tabMars' },
  { id: 'deep', copyKey: 'tabDeep' },
  { id: 'concepts', copyKey: 'tabConcepts' },
  { id: 'quiz', copyKey: 'tabQuiz' },
];

export const EncyclopediaDrawer: React.FC<EncyclopediaDrawerProps> = ({
  lang,
  isOpen,
  onClose,
}) => {
  const t = UI_COPY[lang];
  const [activeTab, setActiveTab] = useState<EncyclopediaTabId>('apollo');
  const [query, setQuery] = useState('');
  const [answers, setAnswers] = useState<Record<string, number>>({});

  const filteredArticles = useMemo(() => {
    if (activeTab === 'quiz' && !query.trim()) return [];
    const q = query.trim().toLowerCase();
    const list = q
      ? Object.values(NASA_ENCYCLOPEDIA_ARTICLES).flat()
      : NASA_ENCYCLOPEDIA_ARTICLES[activeTab as Exclude<EncyclopediaTabId, 'quiz'>] || [];

    if (!q) return list;
    return list.filter((art) => {
      const titleMatch = art.title[lang].toLowerCase().includes(q);
      const textMatch = art.text[lang].toLowerCase().includes(q);
      const tagMatch = art.tag[lang].toLowerCase().includes(q);
      const tableMatch = art.table.some(
        ([k, v]) => k[lang].toLowerCase().includes(q) || v[lang].toLowerCase().includes(q)
      );
      return titleMatch || textMatch || tagMatch || tableMatch;
    });
  }, [activeTab, lang, query]);

  const quizScore = useMemo(() => {
    return NASA_QUIZ_QUESTIONS.reduce((acc, q) => {
      return answers[q.id] === q.correctIndex ? acc + 1 : acc;
    }, 0);
  }, [answers]);

  const answeredCount = Object.keys(answers).length;

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={t.encTitle}
      className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <aside className="flex h-full w-full max-w-2xl flex-col border-l border-slate-800 bg-[#07090e]">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-slate-800 bg-[#0b101b] px-5 py-4">
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-400">
              <BookOpen className="h-4 w-4" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold tracking-tight text-slate-50">
                {t.encTitle}
              </h2>
              <p className="text-xs text-slate-400">{t.encSubtitle}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              nasaAudio.playTelemetryChirp(600);
              onClose();
            }}
            aria-label={t.closeDossier}
            className="flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 transition-colors hover:border-slate-600 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Search + Segmented Tabs */}
        <div className="space-y-3 border-b border-slate-800 bg-[#0b101b]/60 px-5 py-3.5">
          <div className="relative">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.encSearchPlaceholder}
              className="w-full rounded-lg border border-slate-800 bg-[#07090e] py-2 pr-3 pl-9 text-sm text-slate-100 placeholder:text-slate-500 focus:border-amber-500 focus:outline-none"
            />
          </div>

          <div className="no-scrollbar flex items-center gap-1.5 overflow-x-auto">
            {TABS.map((tab) => {
              const active = activeTab === tab.id && !query.trim();
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    nasaAudio.playTelemetryChirp(780);
                    setQuery('');
                    setActiveTab(tab.id);
                  }}
                  className={`min-h-[36px] shrink-0 cursor-pointer rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                    active
                      ? 'bg-amber-500 text-slate-950'
                      : 'border border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  {t[tab.copyKey]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          {activeTab === 'quiz' && !query.trim() ? (
            <div className="space-y-4">
              {/* Score Banner */}
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-800 bg-[#0b101b] p-4">
                <div className="flex items-center gap-3">
                  <Award className="h-6 w-6 text-amber-400" />
                  <div>
                    <h3 className="font-display text-base font-bold text-slate-50">
                      {t.quizTitle}
                    </h3>
                    <p className="text-xs text-slate-400">{t.quizSubtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className="text-[10px] tracking-wider text-slate-400 uppercase">
                      {t.quizScoreLabel}
                    </div>
                    <div className="font-mono-tabular text-lg font-bold text-amber-400">
                      {quizScore} / {NASA_QUIZ_QUESTIONS.length}
                    </div>
                  </div>
                  {answeredCount > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        nasaAudio.playTelemetryChirp(720);
                        setAnswers({});
                      }}
                      title={t.quizResetBtn}
                      className="flex min-h-[36px] cursor-pointer items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:border-slate-500"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      <span>{t.quizResetBtn}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Quiz Questions */}
              {NASA_QUIZ_QUESTIONS.map((q, qIdx) => {
                const chosen = answers[q.id];
                const hasAnswered = chosen !== undefined;
                const isRight = chosen === q.correctIndex;

                return (
                  <div
                    key={q.id}
                    className="rounded-xl border border-slate-800 bg-[#0b101b] p-4 sm:p-5"
                  >
                    <p className="font-mono-tabular text-[11px] font-semibold text-amber-400">
                      {String(qIdx + 1).padStart(2, '0')} / {NASA_QUIZ_QUESTIONS.length}
                    </p>
                    <h4 className="font-display mt-1 text-base font-bold text-slate-50">
                      {q.question[lang]}
                    </h4>

                    <div className="mt-3 space-y-2">
                      {q.options[lang].map((opt, idx) => {
                        const isThisChosen = chosen === idx;
                        const isThisCorrect = q.correctIndex === idx;
                        let styleClass =
                          'border-slate-800 bg-[#07090e]/70 text-slate-200 hover:border-slate-600';
                        if (hasAnswered) {
                          if (isThisCorrect) {
                            styleClass =
                              'border-emerald-500/60 bg-emerald-500/12 text-emerald-200';
                          } else if (isThisChosen) {
                            styleClass = 'border-rose-500/60 bg-rose-500/12 text-rose-200';
                          } else {
                            styleClass = 'border-slate-800/60 bg-[#07090e]/40 text-slate-500';
                          }
                        }

                        return (
                          <button
                            key={idx}
                            type="button"
                            disabled={hasAnswered}
                            onClick={() => {
                              if (idx === q.correctIndex) {
                                nasaAudio.playBeaconPing();
                              } else {
                                nasaAudio.playTelemetryChirp(420);
                              }
                              setAnswers((prev) => ({ ...prev, [q.id]: idx }));
                            }}
                            className={`flex min-h-[42px] w-full cursor-pointer items-center justify-between gap-2 rounded-lg border px-3.5 py-2 text-left text-xs font-medium transition-colors disabled:cursor-default sm:text-sm ${styleClass}`}
                          >
                            <span>{opt}</span>
                            {hasAnswered && isThisCorrect && (
                              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                            )}
                            {hasAnswered && isThisChosen && !isThisCorrect && (
                              <XCircle className="h-4 w-4 shrink-0 text-rose-400" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {hasAnswered && (
                      <div className="mt-3 rounded-lg border border-slate-800 bg-[#07090e] p-3 text-xs leading-relaxed text-slate-300">
                        <span
                          className={`font-semibold ${
                            isRight ? 'text-emerald-400' : 'text-amber-400'
                          }`}
                        >
                          {isRight ? t.quizCorrect : t.quizIncorrect}{' '}
                        </span>
                        {q.explanation[lang]}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ) : filteredArticles.length === 0 ? (
            <div className="rounded-xl border border-slate-800 bg-[#0b101b] p-8 text-center text-sm text-slate-400">
              {t.encNoResults}
            </div>
          ) : (
            filteredArticles.map((art) => (
              <article
                key={art.id}
                className="rounded-xl border border-slate-800 bg-[#0b101b] p-5 transition-colors hover:border-slate-700"
              >
                <p className="font-mono-tabular text-[11px] font-semibold tracking-wide text-amber-400 uppercase">
                  {art.tag[lang]}
                </p>
                <h3 className="font-display mt-1 text-lg font-bold tracking-tight text-slate-50">
                  {art.title[lang]}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-slate-300">{art.text[lang]}</p>

                {art.table.length > 0 && (
                  <dl className="mt-4 divide-y divide-slate-800/80 border-t border-slate-800/80 text-xs">
                    {art.table.map(([k, v], idx) => (
                      <div
                        key={idx}
                        className="flex flex-col gap-1 py-2.5 sm:flex-row sm:items-baseline sm:justify-between sm:gap-4"
                      >
                        <dt className="shrink-0 font-medium text-slate-400">{k[lang]}</dt>
                        <dd className="font-mono-tabular text-left text-slate-100 sm:text-right">
                          {v[lang]}
                        </dd>
                      </div>
                    ))}
                  </dl>
                )}
              </article>
            ))
          )}
        </div>
      </aside>
    </div>
  );
};
