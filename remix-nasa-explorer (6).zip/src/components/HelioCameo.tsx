import React, { useEffect, useState } from 'react';
import { Sparkles, X } from 'lucide-react';
import type { Language } from '../types/nasa';
import { UI_COPY } from '../data/nasaData';

interface HelioCameoProps {
  lang: Language;
  isMobileLayout: boolean;
  message: string;
  triggerKey: string;
  durationMs?: number;
  position?: 'launch' | 'surface' | 'top-right';
}

export const HELIO_IMAGE_SRC = '/assets/aistudio/image_2b17453d.png';

export const HelioCameo: React.FC<HelioCameoProps> = ({
  lang,
  isMobileLayout,
  message,
  triggerKey,
  durationMs = 4600,
  position = 'top-right',
}) => {
  const t = UI_COPY[lang];
  const [visible, setVisible] = useState(true);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    setVisible(true);
    const timer = window.setTimeout(() => {
      setVisible(false);
    }, durationMs);
    return () => window.clearTimeout(timer);
  }, [triggerKey, durationMs]);

  const positionClass =
    position === 'launch'
      ? isMobileLayout
        ? 'top-[114px] right-2.5'
        : 'top-20 right-6'
      : position === 'surface'
        ? isMobileLayout
          ? 'top-[110px] left-2.5'
          : 'top-20 right-6'
        : isMobileLayout
          ? 'top-16 right-2.5'
          : 'top-20 right-6';

  if (!visible) {
    return (
      <button
        type="button"
        onClick={() => setVisible(true)}
        aria-label={t.helioSummon}
        title={t.helioSummon}
        className={`fixed z-20 flex cursor-pointer items-center gap-1.5 rounded-lg border border-sky-500/35 bg-[#0b101b]/90 px-2 py-1.5 backdrop-blur-md transition-colors hover:border-sky-400/70 ${positionClass}`}
      >
        <span className="relative flex h-6 w-6 shrink-0 overflow-hidden rounded-md border border-sky-400/50 bg-slate-900">
          {!imgError ? (
            <img
              src={HELIO_IMAGE_SRC}
              alt={t.helioName}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="h-full w-full object-cover object-[56%_22%]"
            />
          ) : (
            <Sparkles className="m-auto h-3.5 w-3.5 text-sky-300" />
          )}
        </span>
        <span className="font-mono-tabular text-[11px] font-semibold text-sky-300">
          {t.helioName}
        </span>
      </button>
    );
  }

  return (
    <aside
      aria-label={t.helioName}
      className={`animate-helio-enter fixed z-25 flex items-center gap-2.5 rounded-xl border border-sky-500/40 bg-[#0b101b]/94 shadow-xl backdrop-blur-md ${positionClass} ${
        isMobileLayout ? 'max-w-[268px] p-2' : 'max-w-[340px] p-2.5'
      }`}
    >
      {/* Helio Original Artwork Preserved Aspect Portrait */}
      <div
        className={`relative shrink-0 overflow-hidden rounded-lg border border-sky-400/50 bg-[#07090e] ${
          isMobileLayout ? 'h-11 w-11' : 'h-14 w-14'
        }`}
      >
        {!imgError ? (
          <img
            src={HELIO_IMAGE_SRC}
            alt={t.helioName}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover object-[56%_22%]"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-slate-900 text-sky-300">
            <Sparkles className="h-5 w-5" />
          </div>
        )}
      </div>

      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-[10px]">
          <span className="font-mono-tabular font-bold tracking-wider text-sky-300">
            {t.helioName}
          </span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="truncate text-slate-400">{t.helioRole}</span>
        </div>
        <p
          className={`mt-0.5 leading-snug text-slate-200 ${
            isMobileLayout ? 'text-[11px]' : 'text-xs'
          }`}
        >
          {message}
        </p>
      </div>

      <button
        type="button"
        onClick={() => setVisible(false)}
        aria-label={t.helioDismiss}
        className="flex h-7 w-7 shrink-0 cursor-pointer items-center justify-center rounded-md text-slate-400 transition-colors hover:bg-slate-800 hover:text-white"
      >
        <X className="h-3.5 w-3.5" />
      </button>
    </aside>
  );
};
