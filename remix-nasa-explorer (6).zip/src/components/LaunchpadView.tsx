import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Laptop,
  MonitorSmartphone,
  Rocket,
  Smartphone,
} from 'lucide-react';
import type { DisplayMode, Language, ScreenView, SurfaceBodyId } from '../types/nasa';
import { UI_COPY } from '../data/nasaData';
import { nasaAudio } from '../utils/audio';
import { HELIO_IMAGE_SRC, HelioCameo } from './HelioCameo';

export type LaunchDestination = 'solar' | 'moon' | 'mars';

interface LaunchpadViewProps {
  lang: Language;
  isActive: boolean;
  onLiftoffComplete: (destination: LaunchDestination) => void;
  onQuickNavigate: (screen: ScreenView, surface?: SurfaceBodyId) => void;
  displayMode: DisplayMode;
  onChangeDisplayMode: (mode: DisplayMode) => void;
  isMobileLayout: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  type: 'fire' | 'smoke' | 'steam';
  life: number;
  decay: number;
}

interface Star {
  nx: number;
  ny: number;
  size: number;
  alpha: number;
}

export const LaunchpadView: React.FC<LaunchpadViewProps> = ({
  lang,
  isActive,
  onLiftoffComplete,
  onQuickNavigate,
  displayMode,
  onChangeDisplayMode,
  isMobileLayout,
}) => {
  const t = UI_COPY[lang];
  const sectionRef = useRef<HTMLElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [destination, setDestination] = useState<LaunchDestination>('solar');
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isLaunching, setIsLaunching] = useState(false);
  const [telemetry, setTelemetry] = useState({ altKm: 0, velKmh: 0, stage: 'T-00:03' });
  const [guideOpen, setGuideOpen] = useState<boolean>(() => !isMobileLayout);

  const animRef = useRef<number | null>(null);
  const countdownTimerRef = useRef<number | null>(null);
  const destinationRef = useRef<LaunchDestination>('solar');

  useEffect(() => {
    destinationRef.current = destination;
  }, [destination]);

  const launchStateRef = useRef({
    launching: false,
    preIgnition: false,
    rocketY: 0,
    rocketV: 0,
    altKm: 0,
    completed: false,
  });

  useEffect(() => {
    if (isActive) {
      if (countdownTimerRef.current !== null) {
        window.clearInterval(countdownTimerRef.current);
        countdownTimerRef.current = null;
      }
      setCountdown(null);
      setIsLaunching(false);
      setTelemetry({ altKm: 0, velKmh: 0, stage: 'T-00:03' });
      launchStateRef.current = {
        launching: false,
        preIgnition: false,
        rocketY: 0,
        rocketV: 0,
        altKm: 0,
        completed: false,
      };
    }
  }, [isActive]);

  useEffect(() => {
    return () => {
      if (countdownTimerRef.current !== null) {
        window.clearInterval(countdownTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const section = sectionRef.current;
    const canvas = canvasRef.current;
    if (!canvas || !section) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const stars: Star[] = Array.from({ length: 170 }, () => ({
      nx: Math.random(),
      ny: Math.random(),
      size: Math.random() * 1.6 + 0.4,
      alpha: Math.random() * 0.75 + 0.25,
    }));

    const particles: Particle[] = [];
    let width = section.clientWidth || window.innerWidth;
    let height = section.clientHeight || window.innerHeight;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      const rect = section.getBoundingClientRect();
      width = rect.width || window.innerWidth;
      height = rect.height || window.innerHeight;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (!launchStateRef.current.launching) {
        launchStateRef.current.rocketY = width >= 900 ? height * 0.62 : height * 0.44;
      }
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(section);
    window.addEventListener('resize', resize);

    const drawPad = (cx: number, y: number) => {
      ctx.fillStyle = '#141c2c';
      ctx.fillRect(cx - 130, y, 260, 92);

      ctx.fillStyle = '#090d16';
      ctx.fillRect(cx - 44, y + 10, 88, 36);

      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 2.5;
      ctx.strokeRect(cx + 48, y - 216, 46, 216);

      for (let gy = y - 190; gy < y; gy += 28) {
        ctx.beginPath();
        ctx.moveTo(cx + 48, gy);
        ctx.lineTo(cx + 94, gy + 28);
        ctx.stroke();
      }

      if (!launchStateRef.current.launching && !launchStateRef.current.preIgnition) {
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(cx + 48, y - 144);
        ctx.lineTo(cx + 12, y - 144);
        ctx.stroke();
      }

      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.arc(cx - 110, y + 12, 3.5, 0, Math.PI * 2);
      ctx.arc(cx + 110, y + 12, 3.5, 0, Math.PI * 2);
      ctx.fill();
    };

    const drawSLS = (x: number, y: number, launching: boolean) => {
      ctx.save();
      ctx.translate(x, y);

      const scale = width < 520 ? 0.78 : width < 900 ? 0.92 : 1.12;
      ctx.scale(scale, scale);

      const coreGrad = ctx.createLinearGradient(-14, 0, 14, 0);
      coreGrad.addColorStop(0, '#c2410c');
      coreGrad.addColorStop(0.5, '#ea580c');
      coreGrad.addColorStop(1, '#9a3412');
      ctx.fillStyle = coreGrad;
      ctx.fillRect(-14, -22, 28, 98);

      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(-14, -2, 28, 8);
      ctx.fillRect(-14, 38, 28, 6);

      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.moveTo(0, -78);
      ctx.lineTo(2.2, -46);
      ctx.lineTo(12, -22);
      ctx.lineTo(-12, -22);
      ctx.lineTo(-2.2, -46);
      ctx.closePath();
      ctx.fill();

      ctx.fillStyle = '#0b3d91';
      ctx.beginPath();
      ctx.arc(0, 19, 4.5, 0, Math.PI * 2);
      ctx.fill();

      const drawBooster = (bx: number) => {
        ctx.fillStyle = '#e2e8f0';
        ctx.beginPath();
        ctx.moveTo(bx, -28);
        ctx.lineTo(bx + 7, -11);
        ctx.lineTo(bx + 7, 76);
        ctx.lineTo(bx - 7, 76);
        ctx.lineTo(bx - 7, -11);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#0f172a';
        ctx.fillRect(bx - 7, 10, 14, 3);
        ctx.fillRect(bx - 7, 40, 14, 3);
      };

      drawBooster(-21);
      drawBooster(21);

      ctx.fillStyle = '#334155';
      ctx.fillRect(-10, 76, 20, 10);

      if (launching) {
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.moveTo(-10, 86);
        ctx.lineTo(0, 156 + Math.random() * 28);
        ctx.lineTo(10, 86);
        ctx.closePath();
        ctx.fill();

        const drawBoosterFlame = (bx: number) => {
          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.moveTo(bx - 5, 76);
          ctx.lineTo(bx, 124 + Math.random() * 18);
          ctx.lineTo(bx + 5, 76);
          ctx.closePath();
          ctx.fill();
        };
        drawBoosterFlame(-21);
        drawBoosterFlame(21);
      }

      ctx.restore();
    };

    let tickCount = 0;

    const frame = () => {
      if (!isActive) {
        animRef.current = requestAnimationFrame(frame);
        return;
      }

      tickCount += 1;
      const st = launchStateRef.current;
      const rocketCenterX = width >= 900 ? width * 0.7 : width * 0.56;
      const progress = Math.min(st.altKm / 120, 1);

      ctx.clearRect(0, 0, width, height);

      const skyGrad = ctx.createLinearGradient(0, 0, 0, height);
      if (progress < 0.5) {
        skyGrad.addColorStop(0, '#040814');
        skyGrad.addColorStop(0.65, '#0f1a33');
        skyGrad.addColorStop(1, '#1e1620');
      } else {
        skyGrad.addColorStop(0, '#020409');
        skyGrad.addColorStop(1, '#081022');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, width, height);

      for (const s of stars) {
        ctx.fillStyle = `rgba(255, 255, 255, ${s.alpha * (0.28 + progress * 0.72)})`;
        ctx.beginPath();
        ctx.arc(s.nx * width, s.ny * height, s.size, 0, Math.PI * 2);
        ctx.fill();
      }

      const baseGroundY =
        (width >= 900 ? height * 0.75 : height * 0.54) + (st.launching ? st.altKm * 5.2 : 0);
      if (baseGroundY < height + 240) {
        drawPad(rocketCenterX, baseGroundY);
      }

      if (st.launching || st.preIgnition || Math.random() < 0.22) {
        const count = st.launching ? 9 : st.preIgnition ? 5 : 2;
        for (let i = 0; i < count; i++) {
          particles.push({
            x: rocketCenterX + (Math.random() - 0.5) * (st.preIgnition ? 60 : 34),
            y: st.rocketY + 88,
            vx: (Math.random() - 0.5) * (st.launching ? 7 : st.preIgnition ? 5 : 1.4),
            vy: st.preIgnition
              ? -(Math.random() * 1.4 + 0.4)
              : Math.random() * (st.launching ? 8 : 1.8) + 4.5,
            radius: Math.random() * (st.launching ? 18 : 10) + 4,
            type: st.launching ? (Math.random() > 0.42 ? 'fire' : 'smoke') : 'steam',
            life: 1,
            decay: Math.random() * 0.03 + 0.018,
          });
        }
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.radius += 0.45;
        p.life -= p.decay;

        if (p.life <= 0) {
          particles.splice(i, 1);
          continue;
        }

        if (p.type === 'fire') {
          ctx.fillStyle = `rgba(245, 158, 11, ${p.life * 0.85})`;
        } else if (p.type === 'steam') {
          ctx.fillStyle = `rgba(226, 232, 240, ${p.life * 0.35})`;
        } else {
          ctx.fillStyle = `rgba(148, 163, 184, ${p.life * 0.45})`;
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      drawSLS(rocketCenterX, st.rocketY, st.launching);

      if (st.launching) {
        st.rocketV += 0.17;
        st.rocketY -= st.rocketV;
        st.altKm += st.rocketV * 0.42;

        if (tickCount % 4 === 0) {
          const secs = Math.min(Math.floor(st.altKm / 6), 59)
            .toString()
            .padStart(2, '0');
          setTelemetry({
            altKm: Math.round(st.altKm),
            velKmh: Math.round(st.rocketV * 1450),
            stage: `T+00:${secs}`,
          });
        }

        if (st.rocketY < -240 && !st.completed) {
          st.completed = true;
          window.setTimeout(() => {
            onLiftoffComplete(destinationRef.current);
          }, 240);
        }
      }

      animRef.current = requestAnimationFrame(frame);
    };

    animRef.current = requestAnimationFrame(frame);

    return () => {
      ro.disconnect();
      window.removeEventListener('resize', resize);
      if (animRef.current !== null) cancelAnimationFrame(animRef.current);
    };
  }, [isActive, onLiftoffComplete]);

  const handleStartCountdown = () => {
    if (isLaunching || countdown !== null) return;
    nasaAudio.initContext();
    nasaAudio.playTelemetryChirp(980);
    launchStateRef.current.preIgnition = true;

    let remaining = 3;
    setCountdown(remaining);
    setTelemetry({ altKm: 0, velKmh: 0, stage: `T-00:0${remaining}` });

    countdownTimerRef.current = window.setInterval(() => {
      remaining -= 1;
      if (remaining > 0) {
        nasaAudio.playTelemetryChirp(980);
        setCountdown(remaining);
        setTelemetry({ altKm: 0, velKmh: 0, stage: `T-00:0${remaining}` });
      } else {
        if (countdownTimerRef.current !== null) {
          window.clearInterval(countdownTimerRef.current);
          countdownTimerRef.current = null;
        }
        setCountdown(null);
        setIsLaunching(true);
        launchStateRef.current.preIgnition = false;
        launchStateRef.current.launching = true;
        launchStateRef.current.rocketV = 0.95;
        nasaAudio.playRocketIgnition(4.5);
        if (typeof navigator !== 'undefined' && navigator.vibrate) {
          navigator.vibrate([120, 60, 220, 60, 380]);
        }
      }
    }, 850);
  };

  return (
    <section
      ref={sectionRef}
      className={`relative h-full w-full overflow-hidden ${
        isLaunching ? 'camera-shake-active' : ''
      }`}
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-[#07090e]/85 via-transparent to-[#07090e]/95 lg:bg-gradient-to-r lg:from-[#07090e]/95 lg:via-[#07090e]/65 lg:to-transparent" />

      {/* Brief Timed Helio Cameo near launchpad (auto-fades after 4.6s, shrinks on mobile, triggers again on ignition) */}
      <HelioCameo
        lang={lang}
        isMobileLayout={isMobileLayout}
        message={isLaunching || countdown !== null ? t.helioLiftoffMsg : t.helioLaunchMsg}
        triggerKey={isLaunching ? 'liftoff' : 'launch-idle'}
        position="launch"
      />

      <div
        className={`relative z-10 mx-auto flex h-full max-w-[1440px] flex-col justify-between overflow-y-auto px-3.5 pt-16 pb-4 sm:px-8 ${
          isMobileLayout ? '' : 'lg:justify-center lg:pt-14'
        }`}
      >
        <div className={`flex flex-col gap-3 ${isMobileLayout ? '' : 'lg:max-w-xl lg:gap-4'}`}>
          {/* Display Format Selector right at the start of the app (Auto / Laptop / Celular) */}
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-800/90 bg-[#0b101b]/90 px-3 py-2 backdrop-blur-sm">
            <span className="text-[11px] font-semibold text-slate-300">{t.formatLabel}</span>
            <div className="flex items-center gap-1 rounded-lg bg-[#07090e] p-0.5">
              {(
                [
                  { id: 'auto', label: t.formatAuto, Icon: MonitorSmartphone },
                  { id: 'laptop', label: t.formatLaptop, Icon: Laptop },
                  { id: 'mobile', label: t.formatMobile, Icon: Smartphone },
                ] as const
              ).map(({ id, label, Icon }) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => {
                    nasaAudio.playTelemetryChirp(860);
                    onChangeDisplayMode(id);
                  }}
                  className={`flex min-h-[30px] cursor-pointer items-center gap-1 rounded-md px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                    displayMode === id
                      ? 'bg-sky-500 text-slate-950'
                      : 'text-slate-400 hover:text-slate-100'
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="font-mono-tabular mb-1 text-[11px] font-medium tracking-wide text-amber-400 sm:text-xs">
              {t.launchLocation}
            </p>
            <h1
              className={`font-display text-balance font-extrabold tracking-tight text-slate-50 ${
                isMobileLayout ? 'text-2xl' : 'text-2xl sm:text-4xl lg:text-5xl lg:leading-[1.08]'
              }`}
            >
              {t.launchHeroTitle}
            </h1>
            <p
              className={`mt-2 max-w-md leading-relaxed text-slate-300 ${
                isMobileLayout ? 'text-xs' : 'text-xs sm:text-sm lg:text-base'
              }`}
            >
              {t.launchHeroDesc}
            </p>
          </div>

          {/* 3-Step Interactive Mission Guide ("Cómo funciona") */}
          <div className="rounded-xl border border-slate-800/90 bg-[#0b101b]/92 backdrop-blur-sm">
            <button
              type="button"
              onClick={() => setGuideOpen((v) => !v)}
              className="flex w-full cursor-pointer items-center justify-between gap-2 px-3 py-2 text-left"
            >
              <span className="flex items-center gap-2 text-xs font-semibold text-sky-300">
                <HelpCircle className="h-3.5 w-3.5 shrink-0" />
                <span>{t.introTitle}</span>
              </span>
              <span className="flex items-center gap-1 text-[11px] text-slate-400">
                <span>{guideOpen ? t.introHide : t.introShow}</span>
                {guideOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
              </span>
            </button>

            {guideOpen && (
              <ol className="grid grid-cols-1 gap-2 border-t border-slate-800/80 px-3 py-2.5 text-xs sm:grid-cols-3">
                <li className="rounded-lg border border-slate-800/80 bg-[#07090e]/75 p-2">
                  <div className="font-semibold text-amber-300">{t.introStep1Title}</div>
                  <p className="mt-1 text-[11px] leading-snug text-slate-300">{t.introStep1Desc}</p>
                </li>
                <li className="rounded-lg border border-slate-800/80 bg-[#07090e]/75 p-2">
                  <div className="font-semibold text-amber-300">{t.introStep2Title}</div>
                  <p className="mt-1 text-[11px] leading-snug text-slate-300">{t.introStep2Desc}</p>
                </li>
                <li className="rounded-lg border border-slate-800/80 bg-[#07090e]/75 p-2">
                  <div className="font-semibold text-amber-300">{t.introStep3Title}</div>
                  <p className="mt-1 text-[11px] leading-snug text-slate-300">{t.introStep3Desc}</p>
                </li>
              </ol>
            )}
          </div>

          {/* Desktop Vehicle Specifications + Helio Crew Patch */}
          {!isMobileLayout && (
            <div className="hidden rounded-xl border border-slate-800/90 bg-[#0b101b]/90 p-3.5 backdrop-blur-sm lg:block">
              <div className="mb-2 flex items-center justify-between gap-2">
                <span className="text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                  {t.stageInspectorTitle}
                </span>
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-sky-300">
                  <img
                    src={HELIO_IMAGE_SRC}
                    alt={t.helioName}
                    referrerPolicy="no-referrer"
                    className="h-5 w-5 rounded-full border border-sky-400/60 object-cover object-[56%_22%]"
                  />
                  <span>{t.helioName} · {t.helioRole}</span>
                </span>
              </div>
              <dl className="divide-y divide-slate-800/80 text-xs">
                <div className="flex items-center justify-between py-1">
                  <dt className="text-slate-400">{t.vehicleLabel}</dt>
                  <dd className="font-mono-tabular font-semibold text-slate-100">NASA SLS Block 1B</dd>
                </div>
                <div className="flex items-center justify-between py-1">
                  <dt className="text-slate-400">{t.thrustLabel}</dt>
                  <dd className="font-mono-tabular font-semibold text-slate-100">39.1 MN (8.8M lbf)</dd>
                </div>
                <div className="flex items-center justify-between py-1">
                  <dt className="text-slate-400">{t.propellantLabel}</dt>
                  <dd className="font-mono-tabular font-semibold text-slate-100">Cryogenic LOX / LH₂</dd>
                </div>
              </dl>
            </div>
          )}
        </div>

        {/* Bottom Thumb Zone Controls */}
        <div className={`mt-auto flex flex-col gap-2 pt-3 ${isMobileLayout ? '' : 'lg:mt-4 lg:max-w-xl'}`}>
          {/* Destination Selector */}
          <div className="rounded-xl border border-slate-800/90 bg-[#0b101b]/90 p-2 backdrop-blur-sm">
            <div className="mb-1 px-1 text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
              {t.destinationLabel}
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {(
                [
                  { id: 'solar', label: t.destSolar },
                  { id: 'moon', label: t.destMoon },
                  { id: 'mars', label: t.destMars },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  type="button"
                  disabled={isLaunching || countdown !== null}
                  onClick={() => {
                    nasaAudio.playTelemetryChirp(820);
                    setDestination(item.id);
                  }}
                  className={`min-h-[38px] cursor-pointer rounded-lg px-2 py-1.5 text-xs font-semibold transition-colors disabled:opacity-60 ${
                    destination === item.id
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900/90 text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Live Telemetry Strip */}
          <div className="grid grid-cols-3 gap-2 rounded-xl border border-slate-800/90 bg-[#0b101b]/90 p-2.5 backdrop-blur-sm">
            <div>
              <div className="text-[10px] tracking-wider text-slate-400 uppercase">
                {t.countdownLabel}
              </div>
              <div className="font-mono-tabular mt-0.5 text-sm font-bold text-amber-400">
                {telemetry.stage}
              </div>
            </div>
            <div>
              <div className="text-[10px] tracking-wider text-slate-400 uppercase">
                {t.altitudeLabel}
              </div>
              <div className="font-mono-tabular mt-0.5 text-sm font-bold text-slate-100">
                {telemetry.altKm} <span className="text-[11px] font-normal text-slate-400">km</span>
              </div>
            </div>
            <div>
              <div className="text-[10px] tracking-wider text-slate-400 uppercase">
                {t.velocityLabel}
              </div>
              <div className="font-mono-tabular mt-0.5 text-sm font-bold text-slate-100">
                {telemetry.velKmh.toLocaleString()}{' '}
                <span className="text-[11px] font-normal text-slate-400">km/h</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <button
              type="button"
              disabled={isLaunching || countdown !== null}
              onClick={handleStartCountdown}
              className="flex min-h-[48px] w-full cursor-pointer items-center justify-center gap-2.5 rounded-xl bg-amber-500 px-6 py-3 text-sm font-bold tracking-wide text-slate-950 transition-all hover:bg-amber-400 active:scale-[0.98] disabled:cursor-wait disabled:bg-amber-500/85 sm:w-auto sm:flex-1"
            >
              <Rocket className="h-4 w-4 shrink-0" />
              <span>
                {countdown !== null
                  ? `${t.countdownPrefix} ${countdown}...`
                  : isLaunching
                    ? t.launchingCta
                    : t.launchCta}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                nasaAudio.playTelemetryChirp(800);
                if (destination === 'moon' || destination === 'mars') {
                  onQuickNavigate('surface', destination);
                } else {
                  onQuickNavigate('solar');
                }
              }}
              className="flex min-h-[44px] cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-slate-700/80 bg-slate-900/80 px-4 py-2.5 text-xs font-semibold whitespace-nowrap text-slate-200 transition-colors hover:border-slate-500 hover:text-white"
            >
              <span>
                {destination === 'moon'
                  ? t.destMoon
                  : destination === 'mars'
                    ? t.destMars
                    : t.navSolar}
              </span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
