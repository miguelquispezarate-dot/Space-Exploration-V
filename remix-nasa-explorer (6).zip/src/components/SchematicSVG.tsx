import React from 'react';
import type { SchematicIconType } from '../types/nasa';

interface SchematicSVGProps {
  type: SchematicIconType;
}

export const SchematicSVG: React.FC<SchematicSVGProps> = ({ type }) => {
  const renderDiagram = () => {
    switch (type) {
      case 'lunar_module':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <polygon
              points="76,66 164,66 180,92 158,104 82,104 60,92"
              fill="#d97706"
              fillOpacity="0.85"
              stroke="#fbbf24"
              strokeWidth="1.5"
            />
            <line x1="65" y1="92" x2="28" y2="118" stroke="#cbd5e1" strokeWidth="2.8" />
            <line x1="175" y1="92" x2="212" y2="118" stroke="#cbd5e1" strokeWidth="2.8" />
            <line x1="120" y1="104" x2="120" y2="118" stroke="#94a3b8" strokeWidth="2" />
            <ellipse cx="28" cy="120" rx="12" ry="3.5" fill="#64748b" />
            <ellipse cx="212" cy="120" rx="12" ry="3.5" fill="#64748b" />
            <ellipse cx="120" cy="120" rx="10" ry="3" fill="#475569" />
            <polygon points="104,104 136,104 142,116 98,116" fill="#334155" stroke="#64748b" />
            <rect
              x="82"
              y="34"
              width="76"
              height="32"
              rx="6"
              fill="#334155"
              stroke="#94a3b8"
              strokeWidth="1.5"
            />
            <polygon points="93,41 105,41 96,51" fill="#38bdf8" />
            <polygon points="147,41 135,41 144,51" fill="#38bdf8" />
            <line x1="120" y1="34" x2="120" y2="14" stroke="#f8fafc" strokeWidth="1.8" />
            <circle cx="120" cy="13" r="5" fill="#f59e0b" />
            <line
              x1="70"
              y1="70"
              x2="48"
              y2="114"
              stroke="#f8fafc"
              strokeWidth="1.5"
              strokeDasharray="2 3"
            />
          </svg>
        );

      case 'lrv_rover':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <rect
              x="54"
              y="66"
              width="132"
              height="14"
              rx="3"
              fill="#cbd5e1"
              stroke="#94a3b8"
              strokeWidth="1.5"
            />
            <rect x="96" y="46" width="18" height="20" rx="2" fill="#475569" stroke="#94a3b8" />
            <rect x="120" y="46" width="18" height="20" rx="2" fill="#475569" stroke="#94a3b8" />
            <line x1="117" y1="66" x2="117" y2="50" stroke="#f59e0b" strokeWidth="2" />
            <line x1="110" y1="50" x2="124" y2="50" stroke="#f59e0b" strokeWidth="2" />
            <line x1="72" y1="66" x2="72" y2="30" stroke="#94a3b8" strokeWidth="2" />
            <path d="M54,22 Q72,36 90,22" stroke="#f59e0b" strokeWidth="2.5" fill="none" />
            <circle
              cx="70"
              cy="94"
              r="19"
              fill="none"
              stroke="#e2e8f0"
              strokeWidth="3"
              strokeDasharray="3 3"
            />
            <circle cx="70" cy="94" r="7" fill="#64748b" />
            <circle
              cx="170"
              cy="94"
              r="19"
              fill="none"
              stroke="#e2e8f0"
              strokeWidth="3"
              strokeDasharray="3 3"
            />
            <circle cx="170" cy="94" r="7" fill="#64748b" />
          </svg>
        );

      case 'snap27':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <rect
              x="92"
              y="26"
              width="56"
              height="68"
              rx="4"
              fill="#1e293b"
              stroke="#94a3b8"
              strokeWidth="1.5"
            />
            {[36, 50, 64, 78].map((y) => (
              <React.Fragment key={y}>
                <line x1="76" y1={y} x2="92" y2={y} stroke="#f59e0b" strokeWidth="3" />
                <line x1="148" y1={y} x2="164" y2={y} stroke="#f59e0b" strokeWidth="3" />
              </React.Fragment>
            ))}
            <circle cx="120" cy="60" r="14" fill="#78350f" stroke="#f59e0b" strokeWidth="1.5" />
            <circle cx="120" cy="60" r="4" fill="#fbbf24" />
            <rect x="74" y="94" width="92" height="14" rx="2" fill="#475569" />
            <text x="120" y="122" fill="#94a3b8" fontSize="9" fontFamily="monospace" textAnchor="middle">
              Pu-238 · 73.5 W
            </text>
          </svg>
        );

      case 'rover_curiosity':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <rect
              x="70"
              y="56"
              width="96"
              height="26"
              rx="4"
              fill="#e2e8f0"
              stroke="#94a3b8"
              strokeWidth="1.5"
            />
            <line x1="146" y1="56" x2="146" y2="20" stroke="#64748b" strokeWidth="3" />
            <rect
              x="136"
              y="14"
              width="20"
              height="11"
              rx="2"
              fill="#1e293b"
              stroke="#f59e0b"
              strokeWidth="1.2"
            />
            <circle cx="146" cy="19.5" r="3.2" fill="#38bdf8" />
            <rect
              x="54"
              y="52"
              width="18"
              height="22"
              rx="2"
              fill="#78350f"
              stroke="#f59e0b"
              strokeWidth="1.5"
            />
            <polyline points="164,70 192,76 200,92" stroke="#94a3b8" strokeWidth="2.5" />
            <circle cx="200" cy="92" r="4.5" fill="#f59e0b" />
            <line x1="76" y1="82" x2="162" y2="82" stroke="#64748b" strokeWidth="2" />
            {[76, 118, 160].map((cx) => (
              <g key={cx}>
                <circle cx={cx} cy="99" r="13" fill="#1e293b" stroke="#94a3b8" strokeWidth="2" />
                <circle cx={cx} cy="99" r="4" fill="#64748b" />
              </g>
            ))}
          </svg>
        );

      case 'rover_mer':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <polygon
              points="46,56 194,56 182,70 58,70"
              fill="#1e3a8a"
              stroke="#60a5fa"
              strokeWidth="1.5"
            />
            <line x1="85" y1="56" x2="85" y2="70" stroke="#38bdf8" strokeWidth="0.8" />
            <line x1="120" y1="56" x2="120" y2="70" stroke="#38bdf8" strokeWidth="0.8" />
            <line x1="155" y1="56" x2="155" y2="70" stroke="#38bdf8" strokeWidth="0.8" />
            <line x1="142" y1="56" x2="142" y2="24" stroke="#cbd5e1" strokeWidth="2.5" />
            <rect x="130" y="18" width="24" height="8" rx="2" fill="#334155" stroke="#f59e0b" />
            <circle cx="136" cy="22" r="2" fill="#38bdf8" />
            <circle cx="148" cy="22" r="2" fill="#38bdf8" />
            <rect x="86" y="70" width="68" height="16" rx="2" fill="#d97706" stroke="#fbbf24" />
            {[82, 120, 158].map((cx) => (
              <circle
                key={cx}
                cx={cx}
                cy="102"
                r="11"
                fill="#1e293b"
                stroke="#cbd5e1"
                strokeWidth="2"
              />
            ))}
          </svg>
        );

      case 'helicopter':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <ellipse cx="120" cy="30" rx="86" ry="4" fill="#334155" stroke="#94a3b8" strokeWidth="1" />
            <ellipse cx="120" cy="40" rx="86" ry="4" fill="#334155" stroke="#94a3b8" strokeWidth="1" />
            <rect x="104" y="16" width="32" height="7" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1" />
            <line x1="120" y1="23" x2="120" y2="54" stroke="#64748b" strokeWidth="2.5" />
            <rect x="106" y="54" width="28" height="26" rx="3" fill="#f59e0b" stroke="#fbbf24" strokeWidth="1.5" />
            <line x1="106" y1="78" x2="74" y2="112" stroke="#94a3b8" strokeWidth="2" />
            <line x1="134" y1="78" x2="166" y2="112" stroke="#94a3b8" strokeWidth="2" />
            <circle cx="72" cy="113" r="3" fill="#cbd5e1" />
            <circle cx="168" cy="113" r="3" fill="#cbd5e1" />
          </svg>
        );

      case 'footprint':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <rect
              x="95"
              y="14"
              width="50"
              height="102"
              rx="25"
              fill="#1e293b"
              stroke="#cbd5e1"
              strokeWidth="2"
            />
            {[30, 42, 54, 66, 78, 90, 102].map((y) => (
              <line key={y} x1="104" y1={y} x2="136" y2={y} stroke="#94a3b8" strokeWidth="3.5" />
            ))}
          </svg>
        );

      case 'lrrr':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <polygon
              points="54,94 186,94 168,38 72,38"
              fill="#1e293b"
              stroke="#94a3b8"
              strokeWidth="1.5"
            />
            {[0, 1, 2, 3].map((r) =>
              [0, 1, 2, 3, 4, 5, 6, 7].map((c) => (
                <circle
                  key={`${r}-${c}`}
                  cx={82 + c * 11}
                  cy={48 + r * 11}
                  r="3.2"
                  fill="#38bdf8"
                  stroke="#fff"
                  strokeWidth="0.5"
                />
              ))
            )}
            <line x1="66" y1="94" x2="46" y2="114" stroke="#cbd5e1" strokeWidth="2.5" />
            <line x1="174" y1="94" x2="194" y2="114" stroke="#cbd5e1" strokeWidth="2.5" />
          </svg>
        );

      case 'volcano':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <polygon points="16,110 82,52 158,52 224,110" fill="#7c2d12" stroke="#ea580c" strokeWidth="2" />
            <ellipse cx="120" cy="52" rx="38" ry="11" fill="#431407" stroke="#f97316" strokeWidth="1.5" />
            <ellipse cx="120" cy="53" rx="22" ry="5" fill="#1c0702" stroke="#f59e0b" strokeWidth="1" />
            <path d="M84,66 Q98,84 94,110" stroke="#ea580c" strokeWidth="1.5" strokeDasharray="3 3" />
            <path d="M138,66 Q148,84 158,110" stroke="#ea580c" strokeWidth="1.5" strokeDasharray="3 3" />
            <line x1="184" y1="30" x2="184" y2="110" stroke="#f8fafc" strokeWidth="1" strokeDasharray="2 2" />
            <text x="190" y="42" fill="#f59e0b" fontSize="9.5" fontFamily="monospace" fontWeight="bold">
              21.9 KM
            </text>
          </svg>
        );

      case 'pathfinder':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <polygon points="35,96 90,72 150,72 205,96" fill="#1e293b" stroke="#94a3b8" strokeWidth="1.5" />
            <polygon points="90,72 120,42 150,72" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.5" />
            <line x1="120" y1="42" x2="120" y2="20" stroke="#f8fafc" strokeWidth="1.8" />
            <circle cx="120" cy="18" r="4" fill="#f59e0b" />
            <rect x="155" y="92" width="38" height="10" rx="2" fill="#1e3a8a" stroke="#60a5fa" />
            <circle cx="162" cy="108" r="5" fill="#334155" stroke="#cbd5e1" strokeWidth="1.5" />
            <circle cx="174" cy="108" r="5" fill="#334155" stroke="#cbd5e1" strokeWidth="1.5" />
            <circle cx="186" cy="108" r="5" fill="#334155" stroke="#cbd5e1" strokeWidth="1.5" />
          </svg>
        );

      case 'viking':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <polygon points="74,64 166,64 156,88 84,88" fill="#cbd5e1" stroke="#94a3b8" strokeWidth="1.5" />
            <line x1="84" y1="88" x2="54" y2="114" stroke="#94a3b8" strokeWidth="2.8" />
            <line x1="156" y1="88" x2="186" y2="114" stroke="#94a3b8" strokeWidth="2.8" />
            <ellipse cx="52" cy="116" rx="10" ry="3" fill="#64748b" />
            <ellipse cx="188" cy="116" rx="10" ry="3" fill="#64748b" />
            <line x1="100" y1="64" x2="100" y2="30" stroke="#94a3b8" strokeWidth="2" />
            <path d="M82,24 Q100,38 118,24" stroke="#f59e0b" strokeWidth="2.5" fill="none" />
            <rect x="132" y="48" width="22" height="16" rx="2" fill="#78350f" stroke="#f59e0b" />
            <line x1="166" y1="74" x2="206" y2="86" stroke="#cbd5e1" strokeWidth="2" />
          </svg>
        );

      case 'fallen_astronaut':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <rect x="60" y="92" width="120" height="8" rx="2" fill="#475569" />
            <rect x="74" y="64" width="38" height="26" rx="2" fill="#1e293b" stroke="#94a3b8" strokeWidth="1.2" />
            <line x1="80" y1="72" x2="106" y2="72" stroke="#cbd5e1" strokeWidth="1.2" />
            <line x1="80" y1="78" x2="102" y2="78" stroke="#94a3b8" strokeWidth="1" />
            <line x1="80" y1="83" x2="104" y2="83" stroke="#94a3b8" strokeWidth="1" />
            <rect x="134" y="76" width="36" height="10" rx="5" fill="#cbd5e1" stroke="#f8fafc" />
            <circle cx="132" cy="81" r="6" fill="#e2e8f0" />
          </svg>
        );

      case 'golf_met':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            {/* Modular Equipment Transporter (MET) Cart */}
            <rect x="62" y="64" width="64" height="18" rx="3" fill="#334155" stroke="#94a3b8" strokeWidth="1.5" />
            <line x1="62" y1="72" x2="36" y2="52" stroke="#cbd5e1" strokeWidth="2.5" />
            <circle cx="94" cy="96" r="14" fill="none" stroke="#e2e8f0" strokeWidth="3" />
            <circle cx="94" cy="96" r="4" fill="#64748b" />
            {/* 6-iron Golf Club & 2 Golf Balls */}
            <line x1="158" y1="24" x2="178" y2="96" stroke="#cbd5e1" strokeWidth="2.5" />
            <path d="M178,96 L192,98 L190,88 Z" fill="#94a3b8" />
            <circle cx="155" cy="102" r="5" fill="#f8fafc" />
            <circle cx="204" cy="94" r="4.5" fill="#f8fafc" />
            <path d="M158,98 Q182,42 204,88" stroke="#f59e0b" strokeWidth="1.2" strokeDasharray="3 3" />
          </svg>
        );

      case 'uv_camera':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            {/* Tripod */}
            <line x1="120" y1="68" x2="78" y2="112" stroke="#cbd5e1" strokeWidth="2.5" />
            <line x1="120" y1="68" x2="120" y2="114" stroke="#94a3b8" strokeWidth="2.5" />
            <line x1="120" y1="68" x2="162" y2="112" stroke="#cbd5e1" strokeWidth="2.5" />
            {/* Gold-plated Schmidt UV Camera Barrel */}
            <g transform="rotate(-24 120 56)">
              <rect x="86" y="42" width="68" height="28" rx="4" fill="#d97706" stroke="#fbbf24" strokeWidth="1.8" />
              <ellipse cx="154" cy="56" rx="5" ry="13" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
            </g>
            {/* UV rays */}
            <line x1="168" y1="30" x2="196" y2="18" stroke="#818cf8" strokeWidth="1.5" strokeDasharray="3 2" />
            <line x1="172" y1="40" x2="202" y2="30" stroke="#818cf8" strokeWidth="1.5" strokeDasharray="3 2" />
          </svg>
        );

      case 'insight':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            {/* Twin Circular UltraFlex Solar Arrays */}
            <circle cx="62" cy="64" r="28" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.5" />
            <circle cx="178" cy="64" r="28" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.5" />
            {/* Lander Deck */}
            <polygon points="88,64 152,64 142,84 98,84" fill="#cbd5e1" stroke="#94a3b8" strokeWidth="1.5" />
            <line x1="98" y1="84" x2="78" y2="112" stroke="#94a3b8" strokeWidth="2.5" />
            <line x1="142" y1="84" x2="162" y2="112" stroke="#94a3b8" strokeWidth="2.5" />
            {/* SEIS Seismometer Dome on ground */}
            <path d="M180,112 A16,16 0 0 1 212,112 Z" fill="#f59e0b" stroke="#fbbf24" strokeWidth="1.5" />
            <path d="M168,116 Q180,110 196,116 T224,116" stroke="#38bdf8" strokeWidth="1.4" />
          </svg>
        );

      case 'phoenix':
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            {/* Octagonal Solar Wings */}
            <polygon points="36,56 84,56 76,74 42,74" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.4" />
            <polygon points="156,56 204,56 198,74 164,74" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.4" />
            {/* Lander Deck */}
            <rect x="86" y="54" width="68" height="22" rx="3" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1.5" />
            <line x1="94" y1="76" x2="72" y2="108" stroke="#94a3b8" strokeWidth="2.5" />
            <line x1="146" y1="76" x2="168" y2="108" stroke="#94a3b8" strokeWidth="2.5" />
            {/* Robotic Ice Scoop Arm */}
            <polyline points="140,62 178,86 192,108" stroke="#f59e0b" strokeWidth="2.5" />
            {/* Subsurface Ice Trench */}
            <rect x="178" y="108" width="38" height="8" rx="2" fill="#38bdf8" fillOpacity="0.65" />
          </svg>
        );

      case 'surveyor':
      default:
        return (
          <svg viewBox="0 0 240 130" className="h-full w-full max-w-[260px]" fill="none">
            <polygon points="88,82 152,82 138,52 102,52" fill="none" stroke="#cbd5e1" strokeWidth="2" />
            <line x1="88" y1="82" x2="54" y2="114" stroke="#94a3b8" strokeWidth="2.5" />
            <line x1="152" y1="82" x2="186" y2="114" stroke="#94a3b8" strokeWidth="2.5" />
            <line x1="120" y1="52" x2="120" y2="20" stroke="#94a3b8" strokeWidth="2" />
            <rect x="96" y="16" width="48" height="10" rx="2" fill="#1e3a8a" stroke="#60a5fa" />
            <circle cx="120" cy="68" r="10" fill="#f59e0b" fillOpacity="0.8" stroke="#fbbf24" />
          </svg>
        );
    }
  };

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden bg-[#080d17] p-4">
      <div
        className="pointer-events-none absolute inset-0 opacity-20"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(148,163,184,0.2) 1px, transparent 1px), linear-gradient(to bottom, rgba(148,163,184,0.2) 1px, transparent 1px)',
          backgroundSize: '20px 20px',
        }}
      />
      <div className="relative z-10 flex h-full w-full items-center justify-center">
        {renderDiagram()}
      </div>
    </div>
  );
};
