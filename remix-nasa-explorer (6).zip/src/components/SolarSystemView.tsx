import React, { useEffect, useRef, useState } from 'react';
import { ChevronRight, Minus, Pause, Play, Plus, RotateCcw, X } from 'lucide-react';
import type { CelestialBody, Language, OperationalStatus, SurfaceBodyId } from '../types/nasa';
import { NASA_CELESTIAL_BODIES, UI_COPY } from '../data/nasaData';
import { nasaAudio } from '../utils/audio';
import { HelioCameo } from './HelioCameo';

interface SolarSystemViewProps {
  lang: Language;
  isActive: boolean;
  onDiveSurface: (surface: SurfaceBodyId) => void;
  visitedCountByBody: Record<SurfaceBodyId, number>;
  totalCountByBody: Record<SurfaceBodyId, number>;
  isMobileLayout: boolean;
}

const ORDERED_BODY_IDS = [
  'sun',
  'mercury',
  'venus',
  'earth',
  'moon',
  'mars',
  'asteroids',
  'jupiter',
  'saturn',
  'uranus',
  'neptune',
  'voyager',
] as const;

export const SolarSystemView: React.FC<SolarSystemViewProps> = ({
  lang,
  isActive,
  onDiveSurface,
  visitedCountByBody,
  totalCountByBody,
  isMobileLayout,
}) => {
  const t = UI_COPY[lang];
  const sectionRef = useRef<HTMLElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [focusedChip, setFocusedChip] = useState<string>('all');
  const [selectedBodyId, setSelectedBodyId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);

  const stateRef = useRef({
    camX: 0,
    camY: 0,
    scale: 0.72,
    targetX: 0,
    targetY: 0,
    targetScale: 0.72,
    trackingId: null as string | null,
    orbitTime: 220,
    paused: false,
    dragging: false,
    dragStartX: 0,
    dragStartY: 0,
    dragMoved: false,
    lastPinchDist: 0,
    viewportW: 1280,
    viewportH: 720,
  });

  useEffect(() => {
    stateRef.current.paused = isPaused;
  }, [isPaused]);

  useEffect(() => {
    if (!isActive) return;
    const section = sectionRef.current;
    const w = section?.clientWidth || window.innerWidth;
    const h = section?.clientHeight || window.innerHeight;
    const initialScale = w < 640 ? 0.42 : w < 1024 ? 0.6 : 0.74;
    stateRef.current.camX = w / 2;
    stateRef.current.camY = h / 2;
    stateRef.current.targetX = w / 2;
    stateRef.current.targetY = h / 2;
    stateRef.current.scale = initialScale;
    stateRef.current.targetScale = initialScale;
  }, [isActive, isMobileLayout]);

  useEffect(() => {
    const section = sectionRef.current;
    const canvas = canvasRef.current;
    if (!canvas || !section) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = section.clientWidth || window.innerWidth;
    let height = section.clientHeight || window.innerHeight;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    const stars = Array.from({ length: 400 }, () => ({
      x: (Math.random() - 0.5) * 4200,
      y: (Math.random() - 0.5) * 4200,
      r: Math.random() * 1.5 + 0.35,
      a: Math.random() * 0.65 + 0.3,
    }));

    const asteroidBelt = Array.from({ length: 260 }, () => ({
      angle: Math.random() * Math.PI * 2,
      dist: 254 + (Math.random() - 0.5) * 38,
      speed: Math.random() * 0.0014 + 0.0007,
      size: Math.random() * 1.9 + 0.65,
    }));

    const resize = () => {
      const rect = section.getBoundingClientRect();
      width = rect.width || window.innerWidth;
      height = rect.height || window.innerHeight;
      stateRef.current.viewportW = width;
      stateRef.current.viewportH = height;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(section);
    window.addEventListener('resize', resize);

    const drawPlanet = (bx: number, by: number, body: CelestialBody, isSelected: boolean) => {
      ctx.save();
      ctx.translate(bx, by);
      const r = body.radius;

      if (isSelected) {
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.8)';
        ctx.lineWidth = 1.6 / stateRef.current.scale;
        ctx.setLineDash([4 / stateRef.current.scale, 4 / stateRef.current.scale]);
        ctx.beginPath();
        ctx.arc(0, 0, r + (body.textureType === 'saturn' ? 18 : 9), 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      if (body.textureType === 'sun') {
        const corona = ctx.createRadialGradient(0, 0, r * 0.4, 0, 0, r * 2.2);
        corona.addColorStop(0, '#fffbeb');
        corona.addColorStop(0.3, '#f59e0b');
        corona.addColorStop(0.75, 'rgba(217, 119, 6, 0.25)');
        corona.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = corona;
        ctx.beginPath();
        ctx.arc(0, 0, r * 2.2, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
      } else if (body.textureType === 'mercury') {
        const grad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        grad.addColorStop(0, '#d1d5db');
        grad.addColorStop(0.7, '#6b7280');
        grad.addColorStop(1, '#1f2937');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
      } else if (body.textureType === 'venus') {
        const grad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        grad.addColorStop(0, '#fef08a');
        grad.addColorStop(0.55, '#eab308');
        grad.addColorStop(1, '#713f12');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
      } else if (body.textureType === 'earth') {
        const sphereGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        sphereGrad.addColorStop(0, '#60a5fa');
        sphereGrad.addColorStop(0.55, '#1d4ed8');
        sphereGrad.addColorStop(1, '#0f172a');
        ctx.fillStyle = sphereGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#15803d';
        ctx.beginPath();
        ctx.arc(-2, -1, r * 0.48, 0, Math.PI * 1.4);
        ctx.fill();

        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.beginPath();
        ctx.ellipse(1, -2, r * 0.7, r * 0.25, 0.4, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = 'rgba(56, 189, 248, 0.55)';
        ctx.lineWidth = 1.4;
        ctx.stroke();
      } else if (body.textureType === 'moon') {
        const moonGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        moonGrad.addColorStop(0, '#f1f5f9');
        moonGrad.addColorStop(0.7, '#64748b');
        moonGrad.addColorStop(1, '#1e293b');
        ctx.fillStyle = moonGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
      } else if (body.textureType === 'mars') {
        const marsGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        marsGrad.addColorStop(0, '#f97316');
        marsGrad.addColorStop(0.6, '#c2410c');
        marsGrad.addColorStop(1, '#431407');
        ctx.fillStyle = marsGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#f8fafc';
        ctx.beginPath();
        ctx.ellipse(0, -r + 2, r * 0.4, r * 0.18, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (body.textureType === 'jupiter') {
        const jupGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        jupGrad.addColorStop(0, '#fed7aa');
        jupGrad.addColorStop(0.7, '#c2410c');
        jupGrad.addColorStop(1, '#451a03');
        ctx.fillStyle = jupGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = 'rgba(124, 45, 18, 0.7)';
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(-r * 0.85, -6);
        ctx.lineTo(r * 0.85, -6);
        ctx.moveTo(-r * 0.95, 2);
        ctx.lineTo(r * 0.95, 2);
        ctx.moveTo(-r * 0.85, 9);
        ctx.lineTo(r * 0.85, 9);
        ctx.stroke();

        ctx.fillStyle = '#b91c1c';
        ctx.beginPath();
        ctx.ellipse(6, 6, 4.2, 2.8, 0.1, 0, Math.PI * 2);
        ctx.fill();
      } else if (body.textureType === 'saturn') {
        // Back ring half
        ctx.strokeStyle = 'rgba(253, 224, 71, 0.42)';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 1.9, r * 0.55, -0.25, Math.PI, Math.PI * 2);
        ctx.stroke();

        // Planet body
        const satGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        satGrad.addColorStop(0, '#fef3c7');
        satGrad.addColorStop(0.65, '#d97706');
        satGrad.addColorStop(1, '#451a03');
        ctx.fillStyle = satGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();

        // Front ring half
        ctx.strokeStyle = 'rgba(253, 230, 138, 0.72)';
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 1.9, r * 0.55, -0.25, 0, Math.PI);
        ctx.stroke();
      } else if (body.textureType === 'uranus') {
        const uraGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        uraGrad.addColorStop(0, '#cffafe');
        uraGrad.addColorStop(0.65, '#22d3ee');
        uraGrad.addColorStop(1, '#0e7490');
        ctx.fillStyle = uraGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = 'rgba(165, 243, 252, 0.45)';
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.ellipse(0, 0, r * 0.45, r * 1.55, 0.2, 0, Math.PI * 2);
        ctx.stroke();
      } else if (body.textureType === 'neptune') {
        const nepGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        nepGrad.addColorStop(0, '#93c5fd');
        nepGrad.addColorStop(0.6, '#2563eb');
        nepGrad.addColorStop(1, '#1e1b4b');
        ctx.fillStyle = nepGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
      } else if (body.textureType === 'voyager') {
        // Golden Voyager high-gain dish & boom
        ctx.strokeStyle = '#fbbf24';
        ctx.lineWidth = 1.8;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, 0, r * 0.48, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(r * 1.8, -r * 1.1);
        ctx.stroke();
      } else {
        const genGrad = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
        genGrad.addColorStop(0, body.color);
        genGrad.addColorStop(1, '#0f172a');
        ctx.fillStyle = genGrad;
        ctx.beginPath();
        ctx.arc(0, 0, r, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    };

    let animId: number;

    const frame = () => {
      const st = stateRef.current;

      if (!st.paused && isActive) {
        st.orbitTime += 1;
        for (const ast of asteroidBelt) {
          ast.angle += ast.speed;
        }
      }

      if (st.trackingId && st.trackingId !== 'all') {
        const body = NASA_CELESTIAL_BODIES[st.trackingId];
        if (body) {
          const angle = st.orbitTime * body.speed;
          const bx = body.orbitRadius > 0 ? Math.cos(angle) * body.orbitRadius : 0;
          const by = body.orbitRadius > 0 ? Math.sin(angle) * body.orbitRadius : 0;
          const offsetX = width >= 1024 ? 175 : 0;
          const offsetY = width < 1024 ? -height * 0.15 : 0;
          st.targetX = width / 2 + offsetX - bx * st.targetScale;
          st.targetY = height / 2 + offsetY - by * st.targetScale;
        }
      }

      st.camX += (st.targetX - st.camX) * 0.14;
      st.camY += (st.targetY - st.camY) * 0.14;
      st.scale += (st.targetScale - st.scale) * 0.14;

      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = '#05070c';
      ctx.fillRect(0, 0, width, height);

      ctx.save();
      ctx.translate(st.camX, st.camY);
      ctx.scale(st.scale, st.scale);

      for (const s of stars) {
        ctx.fillStyle = `rgba(255, 255, 255, ${s.a})`;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }

      for (const key of ORDERED_BODY_IDS) {
        const body = NASA_CELESTIAL_BODIES[key];
        if (body.orbitRadius > 0) {
          ctx.strokeStyle =
            st.trackingId === key ? 'rgba(245, 158, 11, 0.38)' : 'rgba(148, 163, 184, 0.14)';
          ctx.lineWidth = (st.trackingId === key ? 1.5 : 1) / st.scale;
          ctx.setLineDash([4 / st.scale, 4 / st.scale]);
          ctx.beginPath();
          ctx.arc(0, 0, body.orbitRadius, 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
        }
      }

      ctx.fillStyle = 'rgba(148, 163, 184, 0.45)';
      for (const ast of asteroidBelt) {
        const ax = Math.cos(ast.angle) * ast.dist;
        const ay = Math.sin(ast.angle) * ast.dist;
        ctx.beginPath();
        ctx.arc(ax, ay, ast.size, 0, Math.PI * 2);
        ctx.fill();
      }

      for (const key of ORDERED_BODY_IDS) {
        const body = NASA_CELESTIAL_BODIES[key];
        const angle = st.orbitTime * body.speed;
        const bx = body.orbitRadius > 0 ? Math.cos(angle) * body.orbitRadius : 0;
        const by = body.orbitRadius > 0 ? Math.sin(angle) * body.orbitRadius : 0;

        drawPlanet(bx, by, body, st.trackingId === key);

        ctx.fillStyle = st.trackingId === key ? '#fbbf24' : '#cbd5e1';
        ctx.font = `600 ${Math.max(10, Math.round(11 / Math.sqrt(st.scale)))}px "IBM Plex Mono", monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(body.shortName[lang].toUpperCase(), bx, by + body.radius + 16);
      }

      ctx.restore();
      animId = requestAnimationFrame(frame);
    };

    animId = requestAnimationFrame(frame);

    return () => {
      ro.disconnect();
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animId);
    };
  }, [isActive, lang]);

  const focusBody = (id: string) => {
    setFocusedChip(id);
    const st = stateRef.current;

    if (id === 'all') {
      st.trackingId = null;
      const w = st.viewportW;
      const h = st.viewportH;
      st.targetX = w / 2;
      st.targetY = h / 2;
      st.targetScale = w < 640 ? 0.42 : w < 1024 ? 0.6 : 0.74;
      setSelectedBodyId(null);
      return;
    }

    st.trackingId = id;
    st.targetScale = st.viewportW < 640 ? 1.38 : 1.65;
    setSelectedBodyId(id);
    nasaAudio.playBeaconPing();
  };

  const adjustZoom = (factor: number) => {
    const st = stateRef.current;
    const nextScale = Math.min(Math.max(st.targetScale * factor, 0.28), 3.4);
    if (!st.trackingId) {
      const cx = st.viewportW / 2;
      const cy = st.viewportH / 2;
      const ratio = nextScale / st.targetScale;
      st.targetX = cx - (cx - st.targetX) * ratio;
      st.targetY = cy - (cy - st.targetY) * ratio;
    }
    st.targetScale = nextScale;
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const st = stateRef.current;
    const rect = e.currentTarget.getBoundingClientRect();
    const lx = e.clientX - rect.left;
    const ly = e.clientY - rect.top;
    st.dragging = true;
    st.dragMoved = false;
    st.trackingId = null;
    st.dragStartX = lx - st.targetX;
    st.dragStartY = ly - st.targetY;
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const st = stateRef.current;
    if (!st.dragging) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const nx = e.clientX - rect.left - st.dragStartX;
    const ny = e.clientY - rect.top - st.dragStartY;
    if (Math.hypot(nx - st.targetX, ny - st.targetY) > 4) {
      st.dragMoved = true;
    }
    st.targetX = nx;
    st.targetY = ny;
    st.camX = nx;
    st.camY = ny;
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const st = stateRef.current;
    const wasMoved = st.dragMoved;
    st.dragging = false;

    if (!wasMoved) {
      const rect = e.currentTarget.getBoundingClientRect();
      const worldX = (e.clientX - rect.left - st.camX) / st.scale;
      const worldY = (e.clientY - rect.top - st.camY) / st.scale;

      for (const key of ORDERED_BODY_IDS) {
        const body = NASA_CELESTIAL_BODIES[key];
        const angle = st.orbitTime * body.speed;
        const bx = body.orbitRadius > 0 ? Math.cos(angle) * body.orbitRadius : 0;
        const by = body.orbitRadius > 0 ? Math.sin(angle) * body.orbitRadius : 0;
        const hitRadius = Math.max(body.radius * 1.85, 28);
        if (Math.hypot(worldX - bx, worldY - by) <= hitRadius) {
          focusBody(key);
          return;
        }
      }
    }
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length === 2) {
      stateRef.current.dragging = false;
      stateRef.current.lastPinchDist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      if (stateRef.current.lastPinchDist > 0) {
        adjustZoom(dist / stateRef.current.lastPinchDist);
      }
      stateRef.current.lastPinchDist = dist;
    }
  };

  const renderStatusText = (status: OperationalStatus) => {
    if (status === 'active') {
      return <span className="font-mono-tabular text-[11px] font-semibold text-emerald-400">● {t.statusActive}</span>;
    }
    if (status === 'impacted') {
      return <span className="font-mono-tabular text-[11px] font-semibold text-amber-400">◆ {t.statusImpacted}</span>;
    }
    return <span className="font-mono-tabular text-[11px] font-semibold text-slate-400">○ {t.statusSilent}</span>;
  };

  const selectedBody = selectedBodyId ? NASA_CELESTIAL_BODIES[selectedBodyId] : null;

  return (
    <section ref={sectionRef} className="relative h-full w-full overflow-hidden bg-[#05070c]">
      <HelioCameo
        lang={lang}
        isMobileLayout={isMobileLayout}
        message={t.helioSolarMsg}
        triggerKey="solar-orbit"
        position="top-right"
      />
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onWheel={(e) => {
          e.preventDefault();
          adjustZoom(e.deltaY < 0 ? 1.14 : 0.88);
        }}
        className="h-full w-full cursor-grab touch-none active:cursor-grabbing"
      />

      {/* Right Floating Camera Controls */}
      <div className="fixed right-3 bottom-20 z-20 flex flex-col gap-2 sm:right-6 sm:bottom-24">
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(820);
            setIsPaused((p) => !p);
          }}
          title={isPaused ? t.resumeOrbit : t.pauseOrbit}
          aria-label={isPaused ? t.resumeOrbit : t.pauseOrbit}
          className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-xl border border-slate-800 bg-[#0b101b]/90 text-slate-200 backdrop-blur-md transition-colors hover:border-amber-400/60 hover:text-amber-300"
        >
          {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
        </button>
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(760);
            focusBody('all');
          }}
          title={t.resetCamera}
          aria-label={t.resetCamera}
          className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-xl border border-slate-800 bg-[#0b101b]/90 text-slate-200 backdrop-blur-md transition-colors hover:border-amber-400/60 hover:text-amber-300"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(900);
            adjustZoom(1.25);
          }}
          title={t.zoomIn}
          aria-label={t.zoomIn}
          className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-xl border border-slate-800 bg-[#0b101b]/90 text-slate-200 backdrop-blur-md transition-colors hover:border-amber-400/60 hover:text-amber-300"
        >
          <Plus className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(700);
            adjustZoom(0.8);
          }}
          title={t.zoomOut}
          aria-label={t.zoomOut}
          className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-xl border border-slate-800 bg-[#0b101b]/90 text-slate-200 backdrop-blur-md transition-colors hover:border-amber-400/60 hover:text-amber-300"
        >
          <Minus className="h-4 w-4" />
        </button>
      </div>

      {/* Bottom Celestial Body Selector Bar */}
      <nav
        aria-label="Celestial bodies"
        className="no-scrollbar fixed bottom-3 left-1/2 z-20 flex max-w-[94vw] -translate-x-1/2 items-center gap-1 overflow-x-auto rounded-xl border border-slate-800 bg-[#0b101b]/95 p-1.5 backdrop-blur-md sm:bottom-5"
      >
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(780);
            focusBody('all');
          }}
          className={`min-h-[38px] shrink-0 cursor-pointer rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
            focusedChip === 'all'
              ? 'bg-amber-500 text-slate-950'
              : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
          }`}
        >
          {t.fullSystem}
        </button>
        {ORDERED_BODY_IDS.filter((id) => id !== 'sun').map((id) => {
          const body = NASA_CELESTIAL_BODIES[id];
          const active = focusedChip === id;
          const highlighted = id === 'moon' || id === 'mars';
          return (
            <button
              key={id}
              type="button"
              onClick={() => focusBody(id)}
              className={`min-h-[38px] shrink-0 cursor-pointer rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                active
                  ? 'bg-amber-500 text-slate-950'
                  : highlighted
                    ? 'text-amber-300 hover:bg-slate-800/80 hover:text-amber-200'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
              }`}
            >
              {body.shortName[lang]}
            </button>
          );
        })}
      </nav>

      {/* Celestial Inspector Drawer */}
      {selectedBody && (
        <aside
          aria-label={selectedBody.name[lang]}
          className={`fixed right-0 bottom-0 left-0 z-30 flex max-h-[75dvh] flex-col overflow-y-auto rounded-t-2xl border-t border-slate-700/80 bg-[#0b101b]/96 p-5 pb-7 backdrop-blur-xl ${
            isMobileLayout
              ? ''
              : 'lg:top-20 lg:right-auto lg:bottom-24 lg:left-6 lg:max-h-[calc(100dvh-11rem)] lg:w-[410px] lg:rounded-xl lg:border lg:border-slate-800'
          }`}
        >
          <div className="mx-auto mb-3 h-1 w-10 shrink-0 rounded-full bg-slate-700 lg:hidden" />

          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="font-mono-tabular text-[11px] font-medium tracking-wide text-amber-400">
                {selectedBody.tag[lang]}
              </p>
              <h2 className="font-display mt-1 text-2xl font-bold tracking-tight text-slate-50">
                {selectedBody.name[lang]}
              </h2>
            </div>
            <button
              type="button"
              onClick={() => {
                nasaAudio.playTelemetryChirp(600);
                setSelectedBodyId(null);
              }}
              aria-label={t.closeDossier}
              className="flex h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 transition-colors hover:border-slate-600 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <dl className="mt-4 grid grid-cols-3 divide-x divide-slate-800 rounded-lg border border-slate-800 bg-[#07090e]/70 py-2.5">
            <div className="px-2.5 text-center">
              <dt className="text-[10px] tracking-wider text-slate-400 uppercase">{t.solarDist}</dt>
              <dd className="font-mono-tabular mt-1 text-xs font-semibold text-slate-100">
                {selectedBody.dist[lang]}
              </dd>
            </div>
            <div className="px-2.5 text-center">
              <dt className="text-[10px] tracking-wider text-slate-400 uppercase">{t.gravity}</dt>
              <dd className="font-mono-tabular mt-1 text-xs font-semibold text-slate-100">
                {selectedBody.grav}
              </dd>
            </div>
            <div className="px-2.5 text-center">
              <dt className="text-[10px] tracking-wider text-slate-400 uppercase">{t.diameter}</dt>
              <dd className="font-mono-tabular mt-1 text-xs font-semibold text-slate-100">
                {selectedBody.diam}
              </dd>
            </div>
          </dl>

          {/* Left-Behind NASA Hardware Summary */}
          <div className="mt-4 rounded-lg border border-amber-500/30 bg-amber-500/6 p-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-semibold tracking-wide text-amber-300 uppercase">
                {t.leftBehindLabel}
              </span>
              {renderStatusText(selectedBody.leftBehindStatus)}
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-slate-200">
              {selectedBody.leftBehindSummary[lang]}
            </p>
          </div>

          <div className="mt-3.5 border-t border-slate-800/80 pt-3">
            <div className="text-[11px] font-medium tracking-wide text-slate-400 uppercase">
              {t.exclusiveMissions}
            </div>
            <p className="mt-1 text-xs leading-relaxed text-sky-300">
              {selectedBody.missions.join(' · ')}
            </p>
          </div>

          <p className="mt-3 text-sm leading-relaxed text-slate-300">
            {selectedBody.narrative[lang]}
          </p>

          {selectedBody.hasSurface && selectedBody.surfaceType ? (
            <div className="mt-5">
              <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
                <span>{t.exploredCount}</span>
                <span className="font-mono-tabular font-semibold text-amber-400">
                  {visitedCountByBody[selectedBody.surfaceType]} /{' '}
                  {totalCountByBody[selectedBody.surfaceType]}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  nasaAudio.playTelemetryChirp(1040);
                  onDiveSurface(selectedBody.surfaceType!);
                }}
                className="flex min-h-[46px] w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-bold text-slate-950 transition-colors hover:bg-amber-400"
              >
                <span>
                  {t.exploreSurface} {selectedBody.name[lang]}
                </span>
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <p className="mt-4 border-t border-slate-800/80 pt-3 text-xs text-slate-500">
              {t.noSurfaceHint}
            </p>
          )}
        </aside>
      )}
    </section>
  );
};
