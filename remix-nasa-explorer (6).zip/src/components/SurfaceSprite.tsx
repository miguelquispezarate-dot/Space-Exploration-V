import React from 'react';
import type { SchematicIconType, SurfaceBehaviorState } from '../types/nasa';

interface SurfaceSpriteProps {
  type: SchematicIconType;
  behaviorState: SurfaceBehaviorState;
  solarAngle: number;
  isCompact: boolean;
}

export const SurfaceSprite: React.FC<SurfaceSpriteProps> = ({
  type,
  behaviorState,
  solarAngle,
  isCompact,
}) => {
  // Compute directional ground shadow offset from solarAngle (0=left dawn, 90=noon, 180=right dusk)
  const rad = ((solarAngle - 90) * Math.PI) / 180;
  const shadowShiftX = Math.round(Math.sin(rad) * -14);
  const shadowScaleX = 1 + Math.abs(Math.sin(rad)) * 0.45;
  const shadowOpacity = solarAngle < 15 || solarAngle > 165 ? 0.25 : 0.55;

  const sizeClass = isCompact ? 'w-12 h-8' : 'w-16 h-10';

  const motionClass =
    behaviorState === 'patrol_active'
      ? 'animate-rover-patrol'
      : behaviorState === 'slow_worn_drive'
        ? 'animate-rover-worn'
        : behaviorState === 'damaged_rotor_wind'
          ? 'animate-wind-sway'
          : '';

  const renderModel = () => {
    switch (type) {
      case 'rover_curiosity': {
        const isWorn = behaviorState === 'slow_worn_drive';
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            {/* Active ChemCam / Laser glint */}
            <line
              x1="62"
              y1="14"
              x2="86"
              y2="24"
              stroke={isWorn ? '#38bdf8' : '#34d399'}
              strokeWidth="1.2"
              strokeDasharray="2 3"
              opacity="0.7"
            />
            {/* Body chassis */}
            <rect
              x="24"
              y="22"
              width="42"
              height="13"
              rx="2.5"
              fill="#e2e8f0"
              stroke="#475569"
              strokeWidth="1.4"
            />
            {/* MMRTG rear nuclear battery */}
            <rect
              x="16"
              y="20"
              width="9"
              height="12"
              rx="1.5"
              fill="#78350f"
              stroke="#f59e0b"
              strokeWidth="1.2"
            />
            {/* Camera mast + lens */}
            <line x1="56" y1="22" x2="56" y2="9" stroke="#94a3b8" strokeWidth="2.2" />
            <rect
              x="51"
              y="6"
              width="12"
              height="7"
              rx="1.5"
              fill="#0f172a"
              stroke="#f59e0b"
              strokeWidth="1.2"
            />
            <circle cx="59" cy="9.5" r="2" fill="#38bdf8" />
            {/* Robotic arm */}
            <polyline points="66,28 79,32 82,42" stroke="#cbd5e1" strokeWidth="2" />
            <circle cx="82" cy="42" r="2.6" fill="#f59e0b" />
            {/* Suspension bogie */}
            <line x1="28" y1="35" x2="62" y2="35" stroke="#64748b" strokeWidth="1.8" />
            {/* 3 visible side wheels */}
            {[28, 45, 62].map((cx, i) => (
              <g key={cx}>
                <circle
                  cx={cx}
                  cy="43"
                  r="6.2"
                  fill="#1e293b"
                  stroke={isWorn && i === 1 ? '#fbbf24' : '#cbd5e1'}
                  strokeWidth="1.8"
                />
                <circle cx={cx} cy="43" r="2" fill="#94a3b8" />
              </g>
            ))}
          </svg>
        );
      }

      case 'helicopter': {
        // Ingenuity: grounded on sand dune with damaged/bent upper rotor tip (flight 72, 2024)
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            {/* Small sand dune beneath landing legs */}
            <path d="M18,52 Q48,44 78,52" fill="#9a4419" opacity="0.65" />
            {/* Upper rotor with chipped/bent right blade */}
            <line x1="20" y1="15" x2="48" y2="15" stroke="#cbd5e1" strokeWidth="2" />
            <path d="M48,15 L68,15 L74,20" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" />
            {/* Lower coaxial rotor */}
            <line x1="22" y1="21" x2="72" y2="21" stroke="#94a3b8" strokeWidth="1.8" />
            {/* Solar panel */}
            <rect x="40" y="9" width="16" height="4" rx="1" fill="#1d4ed8" stroke="#60a5fa" strokeWidth="1" />
            {/* Mast & gold cube body */}
            <line x1="48" y1="13" x2="48" y2="27" stroke="#64748b" strokeWidth="2" />
            <rect x="41" y="27" width="14" height="12" rx="2" fill="#f59e0b" stroke="#fbbf24" strokeWidth="1.2" />
            {/* Landing legs resting on dune */}
            <line x1="42" y1="39" x2="29" y2="50" stroke="#cbd5e1" strokeWidth="1.6" />
            <line x1="54" y1="39" x2="67" y2="50" stroke="#cbd5e1" strokeWidth="1.6" />
          </svg>
        );
      }

      case 'rover_mer': {
        const isStuck = behaviorState === 'stuck_in_sand';
        const isDusty = behaviorState === 'dust_hibernation';
        return (
          <svg
            viewBox="0 0 96 58"
            className="h-full w-full overflow-visible"
            fill="none"
            style={isStuck ? { transform: 'rotate(11deg)' } : undefined}
          >
            {/* Soft sand trap mound on Spirit */}
            {isStuck && (
              <path
                d="M14,50 Q52,38 82,50 Z"
                fill="#b4532a"
                opacity="0.85"
              />
            )}
            {/* Solar deck */}
            <polygon
              points="18,26 78,26 72,33 24,33"
              fill={isDusty ? '#475569' : '#1e3a8a'}
              stroke={isDusty ? '#94a3b8' : '#60a5fa'}
              strokeWidth="1.3"
            />
            {/* Mast */}
            <line x1="56" y1="26" x2="56" y2="12" stroke="#cbd5e1" strokeWidth="2" />
            <rect x="50" y="9" width="12" height="5" rx="1" fill="#1e293b" stroke="#f59e0b" />
            {/* Warm electronics box */}
            <rect
              x="34"
              y="33"
              width="28"
              height="8"
              rx="1.5"
              fill={isDusty ? '#92400e' : '#d97706'}
              stroke="#fbbf24"
            />
            {/* Wheels (Spirit's front wheel highlighted as stuck) */}
            {[32, 48, 64].map((cx, idx) => (
              <circle
                key={cx}
                cx={cx}
                cy={isStuck && idx === 2 ? 48 : 45}
                r="5.2"
                fill="#1e293b"
                stroke={isStuck && idx === 2 ? '#f59e0b' : '#cbd5e1'}
                strokeWidth="1.6"
              />
            ))}
          </svg>
        );
      }

      case 'insight':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <circle cx="24" cy="30" r="11" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.2" opacity="0.85" />
            <circle cx="72" cy="30" r="11" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.2" opacity="0.85" />
            <polygon points="34,30 62,30 58,39 38,39" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.2" />
            <line x1="38" y1="39" x2="31" y2="50" stroke="#94a3b8" strokeWidth="2" />
            <line x1="58" y1="39" x2="65" y2="50" stroke="#94a3b8" strokeWidth="2" />
            {/* SEIS dome */}
            <path d="M72,50 A7,7 0 0 1 86,50 Z" fill="#f59e0b" stroke="#fbbf24" strokeWidth="1.2" />
          </svg>
        );

      case 'phoenix':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <polygon points="14,26 34,26 30,34 18,34" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.1" />
            <polygon points="62,26 82,26 78,34 66,34" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.1" />
            <rect x="34" y="25" width="28" height="10" rx="2" fill="#e2e8f0" stroke="#64748b" />
            <line x1="38" y1="35" x2="29" y2="49" stroke="#94a3b8" strokeWidth="2" />
            <line x1="58" y1="35" x2="67" y2="49" stroke="#94a3b8" strokeWidth="2" />
            {/* Water ice trench shimmer */}
            <rect
              x="70"
              y="47"
              width="16"
              height="4"
              rx="1.5"
              fill="#38bdf8"
              className="animate-frost-shimmer"
            />
          </svg>
        );

      case 'viking':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <polygon points="28,30 68,30 64,40 32,40" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.3" />
            <line x1="32" y1="40" x2="21" y2="51" stroke="#94a3b8" strokeWidth="2" />
            <line x1="64" y1="40" x2="75" y2="51" stroke="#94a3b8" strokeWidth="2" />
            {/* Misaligned antenna dish (1982 command error) */}
            <line x1="40" y1="30" x2="36" y2="16" stroke="#94a3b8" strokeWidth="1.8" />
            <path d="M27,13 Q36,20 45,11" stroke="#f59e0b" strokeWidth="2" fill="none" />
            <rect x="53" y="23" width="10" height="7" rx="1" fill="#78350f" stroke="#f59e0b" />
          </svg>
        );

      case 'pathfinder':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <polygon points="18,46 36,34 56,34 74,46" fill="#1e293b" stroke="#94a3b8" strokeWidth="1.2" />
            <polygon points="36,34 46,20 56,34" fill="#1e3a8a" stroke="#60a5fa" strokeWidth="1.2" />
            {/* Parked Sojourner */}
            <rect x="64" y="42" width="16" height="5" rx="1" fill="#1d4ed8" stroke="#60a5fa" />
            {[67, 72, 77].map((cx) => (
              <circle key={cx} cx={cx} cy="49" r="2.2" fill="#cbd5e1" />
            ))}
          </svg>
        );

      case 'volcano':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <polygon points="8,50 36,22 60,22 88,50" fill="#7c2d12" stroke="#f97316" strokeWidth="1.5" />
            <ellipse cx="48" cy="22" rx="12" ry="4" fill="#431407" stroke="#fbbf24" strokeWidth="1.2" />
          </svg>
        );

      case 'lrrr':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            {/* Active reflected Earth laser pulse */}
            <line
              x1="48"
              y1="26"
              x2="48"
              y2="-12"
              stroke="#34d399"
              strokeWidth="2"
              className="animate-laser-bounce"
            />
            <polygon points="24,44 72,44 64,26 32,26" fill="#1e293b" stroke="#94a3b8" strokeWidth="1.4" />
            <rect x="34" y="30" width="28" height="10" rx="1.5" fill="#0ea5e9" fillOpacity="0.65" />
            <line x1="28" y1="44" x2="22" y2="51" stroke="#cbd5e1" strokeWidth="1.8" />
            <line x1="68" y1="44" x2="74" y2="51" stroke="#cbd5e1" strokeWidth="1.8" />
          </svg>
        );

      case 'lunar_module':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <polygon points="30,28 66,28 72,39 62,45 34,45 24,39" fill="#d97706" stroke="#fbbf24" strokeWidth="1.4" />
            <line x1="26" y1="39" x2="14" y2="51" stroke="#cbd5e1" strokeWidth="2" />
            <line x1="70" y1="39" x2="82" y2="51" stroke="#cbd5e1" strokeWidth="2" />
            <line x1="48" y1="45" x2="48" y2="51" stroke="#94a3b8" strokeWidth="1.8" />
            <rect x="34" y="15" width="28" height="13" rx="3" fill="#334155" stroke="#94a3b8" strokeWidth="1.2" />
            <circle cx="48" cy="10" r="2.5" fill="#f59e0b" />
          </svg>
        );

      case 'lrv_rover':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <rect x="24" y="30" width="48" height="6" rx="2" fill="#cbd5e1" stroke="#94a3b8" strokeWidth="1.2" />
            <rect x="38" y="21" width="16" height="9" rx="1.5" fill="#475569" stroke="#94a3b8" />
            <line x1="32" y1="30" x2="32" y2="14" stroke="#94a3b8" strokeWidth="1.5" />
            <path d="M24,11 Q32,17 40,11" stroke="#f59e0b" strokeWidth="1.8" fill="none" />
            <circle cx="30" cy="43" r="7.5" fill="#1e293b" stroke="#e2e8f0" strokeWidth="2" strokeDasharray="2 2" />
            <circle cx="66" cy="43" r="7.5" fill="#1e293b" stroke="#e2e8f0" strokeWidth="2" strokeDasharray="2 2" />
          </svg>
        );

      case 'snap27':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <rect x="38" y="16" width="20" height="28" rx="2" fill="#1e293b" stroke="#94a3b8" strokeWidth="1.3" />
            {[21, 28, 35].map((y) => (
              <React.Fragment key={y}>
                <line x1="30" y1={y} x2="38" y2={y} stroke="#f59e0b" strokeWidth="2.2" />
                <line x1="58" y1={y} x2="66" y2={y} stroke="#f59e0b" strokeWidth="2.2" />
              </React.Fragment>
            ))}
            <rect x="30" y="44" width="36" height="6" rx="1" fill="#475569" />
          </svg>
        );

      case 'uv_camera':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <line x1="48" y1="30" x2="32" y2="50" stroke="#cbd5e1" strokeWidth="2" />
            <line x1="48" y1="30" x2="48" y2="51" stroke="#94a3b8" strokeWidth="2" />
            <line x1="48" y1="30" x2="64" y2="50" stroke="#cbd5e1" strokeWidth="2" />
            <g transform="rotate(-22 48 25)">
              <rect x="34" y="18" width="28" height="12" rx="2" fill="#d97706" stroke="#fbbf24" strokeWidth="1.4" />
              <ellipse cx="62" cy="24" rx="2.5" ry="5.5" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.2" />
            </g>
          </svg>
        );

      case 'golf_met':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <rect x="22" y="28" width="26" height="8" rx="1.5" fill="#334155" stroke="#94a3b8" />
            <circle cx="35" cy="43" r="6" fill="none" stroke="#e2e8f0" strokeWidth="2" />
            <line x1="58" y1="14" x2="66" y2="45" stroke="#cbd5e1" strokeWidth="1.8" />
            <circle cx="60" cy="47" r="2.6" fill="#f8fafc" />
            <circle cx="77" cy="43" r="2.3" fill="#f8fafc" />
          </svg>
        );

      case 'footprint':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <rect x="38" y="14" width="20" height="36" rx="10" fill="#1e293b" stroke="#cbd5e1" strokeWidth="1.6" />
            {[22, 28, 34, 40].map((y) => (
              <line key={y} x1="42" y1={y} x2="54" y2={y} stroke="#94a3b8" strokeWidth="2" />
            ))}
          </svg>
        );

      case 'fallen_astronaut':
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <rect x="26" y="42" width="44" height="5" rx="1" fill="#475569" />
            <rect x="30" y="28" width="16" height="12" rx="1" fill="#1e293b" stroke="#94a3b8" />
            <rect x="52" y="34" width="16" height="5" rx="2.5" fill="#e2e8f0" />
            <circle cx="51" cy="36.5" r="3" fill="#f8fafc" />
          </svg>
        );

      case 'surveyor':
      default:
        return (
          <svg viewBox="0 0 96 58" className="h-full w-full overflow-visible" fill="none">
            <polygon points="35,34 61,34 55,21 41,21" fill="none" stroke="#cbd5e1" strokeWidth="1.6" />
            <line x1="35" y1="34" x2="23" y2="50" stroke="#94a3b8" strokeWidth="2" />
            <line x1="61" y1="34" x2="73" y2="50" stroke="#94a3b8" strokeWidth="2" />
            <line x1="48" y1="21" x2="48" y2="10" stroke="#94a3b8" strokeWidth="1.5" />
            <rect x="39" y="8" width="18" height="4.5" rx="1" fill="#1e3a8a" stroke="#60a5fa" />
          </svg>
        );
    }
  };

  return (
    <div className={`relative flex items-end justify-center ${sizeClass}`}>
      {/* Solar directional shadow grounded on surface */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute bottom-0.5 h-2.5 w-11 rounded-full bg-black/70 blur-[2px] transition-transform duration-300"
        style={{
          transform: `translateX(${shadowShiftX}px) scaleX(${shadowScaleX})`,
          opacity: shadowOpacity,
        }}
      />
      <div className={`relative h-full w-full ${motionClass}`}>{renderModel()}</div>
    </div>
  );
};
