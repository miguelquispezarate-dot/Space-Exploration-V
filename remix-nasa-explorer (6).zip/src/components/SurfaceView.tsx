import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock,
  Compass,
  Minus,
  Plus,
  Radar,
  RotateCcw,
  Scale,
  Sun,
  X,
} from 'lucide-react';
import type { Language, SurfaceBehaviorState, SurfaceBodyId, SurfaceHotspot } from '../types/nasa';
import { NASA_SURFACE_HOTSPOTS, UI_COPY } from '../data/nasaData';
import { nasaAudio } from '../utils/audio';
import { SchematicSVG } from './SchematicSVG';
import { SurfaceSprite } from './SurfaceSprite';
import { HelioCameo } from './HelioCameo';
import moonPanoramaUrl from '../assets/images/moon_surface_panorama_1794763351903.jpg';
import marsPanoramaUrl from '../assets/images/mars_surface_panorama_1794763351899.jpg';

interface SurfaceViewProps {
  lang: Language;
  body: SurfaceBodyId;
  onChangeBody: (body: SurfaceBodyId) => void;
  visitedIds: Set<string>;
  onMarkVisited: (id: string) => void;
  isMobileLayout: boolean;
}

const PANORAMA_WIDTH = 3800;

type StatusFilter = 'all' | 'active' | 'silent';
type ActiveTool = 'none' | 'solar' | 'timeline' | 'gravity' | 'radar';

export const SurfaceView: React.FC<SurfaceViewProps> = ({
  lang,
  body,
  onChangeBody,
  visitedIds,
  onMarkVisited,
  isMobileLayout,
}) => {
  const t = UI_COPY[lang];
  const sectionRef = useRef<HTMLElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const hotspotsLayerRef = useRef<HTMLDivElement | null>(null);
  const radarTrackRef = useRef<HTMLDivElement | null>(null);

  const [selectedHotspot, setSelectedHotspot] = useState<SurfaceHotspot | null>(null);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [telemetryOpen, setTelemetryOpen] = useState<boolean>(() => !isMobileLayout);
  const [activeTool, setActiveTool] = useState<ActiveTool>('none');
  const [solarAngle, setSolarAngle] = useState<number>(68); // 0=dawn, 90=noon, 180=dusk, 195+=night
  const [testMassKg, setTestMassKg] = useState<number>(70);
  const [containerSize, setContainerSize] = useState({ w: 1280, h: 720 });
  const [cameraSnapshot, setCameraSnapshot] = useState({ offsetX: -140, offsetY: 0, zoom: 1 });
  const [imagesLoadedTick, setImagesLoadedTick] = useState(0);

  const imagesRef = useRef<{ moon: HTMLImageElement | null; mars: HTMLImageElement | null }>({
    moon: null,
    mars: null,
  });

  const panState = useRef({
    offsetX: -140,
    offsetY: 0,
    targetX: -140,
    targetY: 0,
    zoom: 1,
    targetZoom: 1,
    isPanning: false,
    startX: 0,
    startY: 0,
    originX: 0,
    originY: 0,
    lastPinchDist: 0,
    animatingTarget: false,
  });

  // Auto-collapse telemetry when entering mobile mode or compact height
  useEffect(() => {
    if (isMobileLayout || containerSize.h < 620) {
      setTelemetryOpen(false);
    } else {
      setTelemetryOpen(true);
    }
  }, [isMobileLayout, containerSize.h]);

  // Load both generated HD panoramas once
  useEffect(() => {
    const moonImg = new Image();
    moonImg.onload = () => {
      imagesRef.current.moon = moonImg;
      setImagesLoadedTick((n) => n + 1);
    };
    moonImg.src = moonPanoramaUrl;

    const marsImg = new Image();
    marsImg.onload = () => {
      imagesRef.current.mars = marsImg;
      setImagesLoadedTick((n) => n + 1);
    };
    marsImg.src = marsPanoramaUrl;
  }, []);

  // Measure actual container dimensions via ResizeObserver (works for mobile frame, phones & resized laptop windows)
  useEffect(() => {
    const el = sectionRef.current;
    if (!el) return;
    const updateSize = () => {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        setContainerSize({ w: Math.round(rect.width), h: Math.round(rect.height) });
      }
    };
    updateSize();
    const ro = new ResizeObserver(updateSize);
    ro.observe(el);
    window.addEventListener('resize', updateSize);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  const allHotspots = useMemo(() => NASA_SURFACE_HOTSPOTS[body] || [], [body]);

  const hotspots = useMemo(() => {
    if (statusFilter === 'all') return allHotspots;
    return allHotspots.filter((h) => h.status === statusFilter);
  }, [allHotspots, statusFilter]);

  const timelineHotspots = useMemo(
    () => [...allHotspots].sort((a, b) => a.missionYear - b.missionYear),
    [allHotspots]
  );

  const visitedInBody = useMemo(
    () => allHotspots.filter((h) => visitedIds.has(h.id)).length,
    [allHotspots, visitedIds]
  );

  const clampPan = useCallback(
    (x: number, y: number, zoom: number, cw: number, ch: number) => {
      const scaledW = PANORAMA_WIDTH * zoom;
      const minX = Math.min(0, -(scaledW - cw));
      const maxX = scaledW < cw ? (cw - scaledW) / 2 : 0;
      const clampedX = scaledW < cw ? maxX : Math.min(Math.max(x, minX), 0);

      // Gentle vertical horizon pan bounds while sky & terrain always cover 100% height
      const maxVertShift = Math.max(80, ch * 0.18 * zoom);
      const clampedY = Math.min(Math.max(y, -maxVertShift), maxVertShift);

      return { x: clampedX, y: clampedY };
    },
    []
  );

  // Sync camera snapshot for React-positioned sprites, mini-map radar, and canvas redraw
  const syncCamera = useCallback(() => {
    const st = panState.current;
    setCameraSnapshot({
      offsetX: st.offsetX,
      offsetY: st.offsetY,
      zoom: st.zoom,
    });
  }, []);

  // Reset camera cleanly when switching Moon <-> Mars or layout mode
  useEffect(() => {
    setSelectedHotspot(null);
    setStatusFilter('all');
    const cw = containerSize.w || 1280;
    const ch = containerSize.h || 720;
    const initialZoom = cw < 520 ? 0.72 : cw < 900 ? 0.86 : 1.0;
    const initialX = cw < 520 ? -50 : -110;
    const clamped = clampPan(initialX, 0, initialZoom, cw, ch);

    panState.current.offsetX = clamped.x;
    panState.current.offsetY = clamped.y;
    panState.current.targetX = clamped.x;
    panState.current.targetY = clamped.y;
    panState.current.zoom = initialZoom;
    panState.current.targetZoom = initialZoom;
    panState.current.animatingTarget = false;
    syncCamera();
    // Only run on body switch or mobile layout toggle, not every resize tick
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [body, isMobileLayout]);

  // Smooth camera glide loop
  useEffect(() => {
    let rafId: number;
    const tick = () => {
      const st = panState.current;
      if (st.animatingTarget) {
        const dx = st.targetX - st.offsetX;
        const dy = st.targetY - st.offsetY;
        const dz = st.targetZoom - st.zoom;
        st.offsetX += dx * 0.16;
        st.offsetY += dy * 0.16;
        st.zoom += dz * 0.16;
        syncCamera();
        if (Math.abs(dx) < 0.7 && Math.abs(dy) < 0.7 && Math.abs(dz) < 0.004) {
          st.offsetX = st.targetX;
          st.offsetY = st.targetY;
          st.zoom = st.targetZoom;
          st.animatingTarget = false;
          syncCamera();
        }
      }
      rafId = requestAnimationFrame(tick);
    };
    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [syncCamera]);

  // Helper: project world spot coordinates into full-viewport screen coordinates
  const projectSpot = useCallback(
    (spotX: number, spotYRatio: number, offsetX: number, offsetY: number, zoom: number, ch: number) => {
      const horizonScreenY = ch * 0.45 + offsetY;
      const vertScale = Math.max(ch, 500) * 0.92 * (0.62 + 0.38 * zoom);
      const screenX = spotX * zoom + offsetX;
      const screenY = horizonScreenY + (spotYRatio - 0.5) * vertScale;
      return { x: screenX, y: screenY };
    },
    []
  );

  // Full-viewport adaptive Canvas renderer (Infinite Sky + HD Panorama + Endless Extended Terrain + Solar Lighting)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cw = containerSize.w;
    const ch = containerSize.h;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    canvas.width = Math.floor(cw * dpr);
    canvas.height = Math.floor(ch * dpr);
    canvas.style.width = `${cw}px`;
    canvas.style.height = `${ch}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const { offsetX, offsetY, zoom } = cameraSnapshot;

    // Solar illumination intensity: solarAngle 0..180 (day), >180 (night)
    const isNight = solarAngle > 180;
    const clampedDay = Math.min(Math.max(solarAngle, 0), 180);
    const sunElevation = isNight ? 0 : Math.sin((clampedDay * Math.PI) / 180); // 0..1
    const sunNormX = clampedDay / 180; // 0 (left) .. 1 (right)
    const shadowDir = isNight ? -0.35 : Math.cos((clampedDay * Math.PI) / 180) * -1.4;

    const horizonScreenY = ch * 0.45 + offsetY;
    const panoBandH = Math.max(ch * 0.64, 340) * (0.62 + 0.38 * zoom);
    const panoTop = horizonScreenY - panoBandH * 0.44;
    const panoBottom = panoTop + panoBandH;

    let seed = body === 'moon' ? 19690720 : 20210218;
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) % 4294967296;
      return seed / 4294967296;
    };

    // 1. INFINITE SKY LAYER (Always fills 0 .. ch)
    if (body === 'moon') {
      ctx.fillStyle = '#03050a';
      ctx.fillRect(0, 0, cw, ch);

      // Stars with gentle parallax
      for (let i = 0; i < 420; i++) {
        const worldStarX = rand() * PANORAMA_WIDTH;
        const sx = ((worldStarX * 0.45 + offsetX * 0.35) % cw + cw) % cw;
        const sy = rand() * Math.max(horizonScreenY + 40, ch * 0.55);
        const sr = rand() < 0.85 ? 1 : 1.7;
        const alpha = 0.25 + rand() * 0.72;
        ctx.fillStyle = `rgba(255, 255, 255, ${alpha})`;
        ctx.fillRect(sx, sy, sr, sr);
      }
    } else {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, Math.max(horizonScreenY + 80, ch * 0.6));
      if (isNight) {
        skyGrad.addColorStop(0, '#070b16');
        skyGrad.addColorStop(0.65, '#191d32');
        skyGrad.addColorStop(1, '#3b251c');
      } else {
        const duskMix = 1 - sunElevation;
        skyGrad.addColorStop(0, duskMix > 0.65 ? '#352229' : '#6c3c19');
        skyGrad.addColorStop(0.55, duskMix > 0.65 ? '#8f472d' : '#bf7839');
        skyGrad.addColorStop(1, duskMix > 0.65 ? '#c47b54' : '#ebba82');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, cw, ch);

      if (isNight || sunElevation < 0.28) {
        for (let i = 0; i < 160; i++) {
          const sx = rand() * cw;
          const sy = rand() * (horizonScreenY * 0.75);
          ctx.fillStyle = `rgba(255,255,255,${(1 - sunElevation) * 0.45 * rand()})`;
          ctx.fillRect(sx, sy, 1.2, 1.2);
        }
      }
    }

    // Dynamic Solar Disc in sky when daytime
    if (!isNight) {
      const sunScreenX = cw * (0.14 + sunNormX * 0.72);
      const sunScreenY = Math.max(58, horizonScreenY - sunElevation * (ch * 0.32) - 18);
      const sunRadius = body === 'moon' ? 16 : 11;
      const glow = ctx.createRadialGradient(
        sunScreenX,
        sunScreenY,
        sunRadius * 0.4,
        sunScreenX,
        sunScreenY,
        sunRadius * 5.2
      );
      if (body === 'moon') {
        glow.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
        glow.addColorStop(0.25, 'rgba(254, 243, 199, 0.45)');
        glow.addColorStop(1, 'rgba(255, 255, 255, 0)');
      } else {
        // Mars dusty blue sunset/sun halo!
        const isLowSun = sunElevation < 0.32;
        glow.addColorStop(0, isLowSun ? 'rgba(219, 234, 254, 0.95)' : 'rgba(255, 247, 237, 0.92)');
        glow.addColorStop(0.32, isLowSun ? 'rgba(125, 211, 252, 0.4)' : 'rgba(253, 186, 116, 0.35)');
        glow.addColorStop(1, 'rgba(253, 186, 116, 0)');
      }
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(sunScreenX, sunScreenY, sunRadius * 5.2, 0, Math.PI * 2);
      ctx.fill();
    }

    // 2. ENDLESS EXTENDED FOREGROUND SOIL (Always reaches bottom y = ch, zero black cut!)
    const soilStart = Math.max(0, horizonScreenY - 8);
    const groundGrad = ctx.createLinearGradient(0, soilStart, 0, ch);
    if (body === 'moon') {
      const bright = isNight ? 0.38 : 0.65 + sunElevation * 0.35;
      const c1 = Math.round(72 * bright);
      const c2 = Math.round(98 * bright);
      const c3 = Math.round(58 * bright);
      groundGrad.addColorStop(0, `rgb(${c1}, ${c1 + 6}, ${c1 + 14})`);
      groundGrad.addColorStop(0.45, `rgb(${c2}, ${c2 + 6}, ${c2 + 12})`);
      groundGrad.addColorStop(1, `rgb(${c3}, ${c3 + 5}, ${c3 + 10})`);
    } else {
      const bright = isNight ? 0.32 : 0.65 + sunElevation * 0.35;
      groundGrad.addColorStop(
        0,
        `rgb(${Math.round(145 * bright)}, ${Math.round(68 * bright)}, ${Math.round(32 * bright)})`
      );
      groundGrad.addColorStop(
        0.5,
        `rgb(${Math.round(168 * bright)}, ${Math.round(80 * bright)}, ${Math.round(36 * bright)})`
      );
      groundGrad.addColorStop(
        1,
        `rgb(${Math.round(115 * bright)}, ${Math.round(48 * bright)}, ${Math.round(20 * bright)})`
      );
    }
    ctx.fillStyle = groundGrad;
    ctx.fillRect(0, soilStart, cw, ch - soilStart);

    // 3. GENERATED HD PANORAMA BAND (Seamless tiling + bottom crop + soft top/bottom fade)
    const hdImg = body === 'moon' ? imagesRef.current.moon : imagesRef.current.mars;
    if (hdImg && hdImg.complete && hdImg.naturalWidth > 0) {
      const tileW = (PANORAMA_WIDTH / 2) * zoom;
      const srcH = Math.floor(hdImg.naturalHeight * 0.9); // Crop bottom 10% flat margin cleanly

      ctx.save();
      ctx.globalAlpha = isNight ? 0.45 : 0.78 + sunElevation * 0.22;

      // Tile 1: 0 .. 1900 world px
      ctx.drawImage(
        hdImg,
        0,
        0,
        hdImg.naturalWidth,
        srcH,
        offsetX,
        panoTop,
        tileW,
        panoBandH
      );

      // Tile 2: 1900 .. 3800 world px (mirrored seamlessly; on Moon crop out Earthrise so Earth appears once!)
      ctx.save();
      const tile2X = offsetX + tileW;
      ctx.translate(tile2X + tileW, panoTop);
      ctx.scale(-1, 1);
      const cropX = body === 'moon' ? Math.floor(hdImg.naturalWidth * 0.28) : 0;
      const cropW = hdImg.naturalWidth - cropX;
      ctx.drawImage(hdImg, cropX, 0, cropW, srcH, 0, 0, tileW, panoBandH);
      ctx.restore();

      ctx.restore();

      // Top & bottom feather blends so the HD horizon melts invisibly into sky & extended soil
      const topFeather = ctx.createLinearGradient(0, panoTop, 0, panoTop + panoBandH * 0.22);
      if (body === 'moon') {
        topFeather.addColorStop(0, 'rgba(3, 5, 10, 0.96)');
        topFeather.addColorStop(1, 'rgba(3, 5, 10, 0)');
      } else {
        topFeather.addColorStop(0, isNight ? 'rgba(15, 19, 34, 0.9)' : 'rgba(130, 74, 34, 0.55)');
        topFeather.addColorStop(1, 'rgba(130, 74, 34, 0)');
      }
      ctx.fillStyle = topFeather;
      ctx.fillRect(0, panoTop - 2, cw, panoBandH * 0.24);

      const bottomFeatherH = Math.max(60, panoBandH * 0.24);
      const bottomFeather = ctx.createLinearGradient(0, panoBottom - bottomFeatherH, 0, panoBottom + 6);
      if (body === 'moon') {
        const c = isNight ? '28, 32, 38' : '74, 82, 92';
        bottomFeather.addColorStop(0, `rgba(${c}, 0)`);
        bottomFeather.addColorStop(0.8, `rgba(${c}, 0.88)`);
        bottomFeather.addColorStop(1, `rgba(${c}, 1)`);
      } else {
        const c = isNight ? '45, 22, 12' : '138, 66, 30';
        bottomFeather.addColorStop(0, `rgba(${c}, 0)`);
        bottomFeather.addColorStop(0.8, `rgba(${c}, 0.88)`);
        bottomFeather.addColorStop(1, `rgba(${c}, 1)`);
      }
      ctx.fillStyle = bottomFeather;
      ctx.fillRect(0, panoBottom - bottomFeatherH, cw, bottomFeatherH + 8);
    }

    // 4. PROCEDURAL FOREGROUND EXTENSION (Craters, ripples & rocks extending seamlessly to bottom edge!)
    const extStart = Math.max(horizonScreenY + panoBandH * 0.34, horizonScreenY + 40);
    if (extStart < ch) {
      if (body === 'moon') {
        // Subtle lunar craters in extended foreground
        for (let i = 0; i < 28; i++) {
          const wx = rand() * PANORAMA_WIDTH;
          const sx = wx * zoom + offsetX;
          if (sx < -160 || sx > cw + 160) {
            rand();
            rand();
            continue;
          }
          const sy = extStart + rand() * (ch - extStart + 30);
          const rx = (28 + rand() * 78) * Math.max(0.7, zoom);
          const ry = rx * 0.26;
          const rimGrad = ctx.createLinearGradient(
            sx + shadowDir * rx * 0.6,
            sy,
            sx - shadowDir * rx * 0.6,
            sy
          );
          rimGrad.addColorStop(0, 'rgba(8, 12, 20, 0.72)');
          rimGrad.addColorStop(0.55, 'rgba(51, 65, 85, 0.42)');
          rimGrad.addColorStop(1, 'rgba(148, 163, 184, 0.45)');
          ctx.fillStyle = rimGrad;
          ctx.beginPath();
          ctx.ellipse(sx, sy, rx, ry, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      } else {
        // Martian wind-rippled dunes in extended foreground
        ctx.strokeStyle = isNight ? 'rgba(28, 12, 6, 0.35)' : 'rgba(92, 34, 12, 0.32)';
        for (let r = 0; r < 18; r++) {
          const ry = extStart + (r / 18) * (ch - extStart + 10);
          ctx.lineWidth = 1.2 + (r / 18) * 1.8;
          ctx.beginPath();
          ctx.moveTo(0, ry);
          for (let x = 0; x <= cw; x += 48) {
            ctx.lineTo(x, ry + Math.sin((x - offsetX) * 0.014 + r) * 4);
          }
          ctx.stroke();
        }
      }

      // Scattered foreground boulders with directional solar shadows
      for (let i = 0; i < 110; i++) {
        const wx = rand() * PANORAMA_WIDTH;
        const sx = wx * zoom + offsetX;
        const sy = extStart + rand() * (ch - extStart + 10);
        const bw = (3 + rand() * 14) * Math.max(0.65, zoom);
        const bh = bw * (0.45 + rand() * 0.35);
        if (sx < -40 || sx > cw + 40) continue;

        ctx.fillStyle = 'rgba(4, 6, 10, 0.55)';
        ctx.beginPath();
        ctx.ellipse(sx + shadowDir * bw * 0.85, sy + bh * 0.25, bw * 1.15, bh * 0.32, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle =
          body === 'moon'
            ? isNight
              ? '#475569'
              : '#cbd5e1'
            : isNight
              ? '#5c2612'
              : '#b4532a';
        ctx.beginPath();
        ctx.moveTo(sx - bw * 0.5, sy + bh * 0.25);
        ctx.lineTo(sx - bw * 0.2, sy - bh * 0.5);
        ctx.lineTo(sx + bw * 0.35, sy - bh * 0.4);
        ctx.lineTo(sx + bw * 0.55, sy + bh * 0.25);
        ctx.closePath();
        ctx.fill();
      }
    }

    // 5. SOLAR LIGHTING OVERLAY + MEASURED CONTRAST SCRIM
    if (isNight) {
      ctx.fillStyle = body === 'moon' ? 'rgba(6, 12, 28, 0.36)' : 'rgba(8, 10, 24, 0.42)';
      ctx.fillRect(0, 0, cw, ch);
    } else if (sunElevation < 0.42) {
      const tintAlpha = (0.42 - sunElevation) * 0.45;
      ctx.fillStyle =
        body === 'moon'
          ? `rgba(15, 23, 42, ${tintAlpha})`
          : `rgba(154, 52, 18, ${tintAlpha})`;
      ctx.fillRect(0, 0, cw, ch);
    }

    const edgeScrim = ctx.createLinearGradient(0, 0, 0, ch);
    edgeScrim.addColorStop(0, 'rgba(7, 9, 14, 0.35)');
    edgeScrim.addColorStop(0.22, 'rgba(7, 9, 14, 0)');
    edgeScrim.addColorStop(0.82, 'rgba(7, 9, 14, 0)');
    edgeScrim.addColorStop(1, 'rgba(7, 9, 14, 0.52)');
    ctx.fillStyle = edgeScrim;
    ctx.fillRect(0, 0, cw, ch);
  }, [body, cameraSnapshot, containerSize, solarAngle, imagesLoadedTick]);

  const adjustSurfaceZoom = useCallback(
    (factor: number, originX?: number, originY?: number) => {
      const cw = containerSize.w;
      const ch = containerSize.h;
      const ox = originX ?? cw / 2;
      const oy = originY ?? ch / 2;
      const st = panState.current;
      st.animatingTarget = false;

      // Free zoom out down to panoramic overview without ever showing black bottom void!
      const minScale = Math.max(cw / PANORAMA_WIDTH, 0.38);
      const newZoom = Math.min(Math.max(st.zoom * factor, minScale), 2.4);
      const ratio = newZoom / st.zoom;

      const nextX = ox - (ox - st.offsetX) * ratio;
      const nextY = st.offsetY + (oy - ch * 0.5) * (1 - ratio) * 0.25;
      const clamped = clampPan(nextX, nextY, newZoom, cw, ch);

      st.zoom = newZoom;
      st.offsetX = clamped.x;
      st.offsetY = clamped.y;
      syncCamera();
    },
    [clampPan, containerSize.h, containerSize.w, syncCamera]
  );

  const resetCameraView = useCallback(() => {
    const cw = containerSize.w;
    const ch = containerSize.h;
    const st = panState.current;
    const defaultZoom = cw < 520 ? 0.72 : cw < 900 ? 0.86 : 1.0;
    const clamped = clampPan(cw < 520 ? -50 : -110, 0, defaultZoom, cw, ch);
    st.targetX = clamped.x;
    st.targetY = clamped.y;
    st.targetZoom = defaultZoom;
    st.animatingTarget = true;
  }, [clampPan, containerSize.h, containerSize.w]);

  const panToHotspot = useCallback(
    (spot: SurfaceHotspot, openModal = false) => {
      const cw = containerSize.w;
      const ch = containerSize.h;
      const st = panState.current;
      const desiredZoom = cw < 520 ? 0.92 : 1.08;
      const rawTargetX = cw / 2 - spot.x * desiredZoom;
      const clamped = clampPan(rawTargetX, 0, desiredZoom, cw, ch);
      st.targetX = clamped.x;
      st.targetY = clamped.y;
      st.targetZoom = desiredZoom;
      st.animatingTarget = true;

      nasaAudio.playBeaconPing();
      if (openModal) {
        onMarkVisited(spot.id);
        setSelectedHotspot(spot);
      }
    },
    [clampPan, containerSize.h, containerSize.w, onMarkVisited]
  );

  const handleOpenHotspot = (spot: SurfaceHotspot) => {
    nasaAudio.playBeaconPing();
    onMarkVisited(spot.id);
    setSelectedHotspot(spot);
  };

  const selectedIndex = selectedHotspot
    ? hotspots.findIndex((h) => h.id === selectedHotspot.id)
    : -1;

  const navigateHotspot = (dir: -1 | 1) => {
    if (hotspots.length === 0) return;
    const nextIdx = (selectedIndex + dir + hotspots.length) % hotspots.length;
    const nextSpot = hotspots[nextIdx];
    panToHotspot(nextSpot, true);
  };

  // Dynamic surface temperature computed from solarAngle
  const dynamicTempDisplay = useMemo(() => {
    const isNight = solarAngle > 180;
    const elev = isNight ? 0 : Math.sin((Math.min(Math.max(solarAngle, 0), 180) * Math.PI) / 180);
    if (body === 'moon') {
      const tempC = Math.round(-130 + elev * 251); // -130°C to +121°C
      return `${tempC > 0 ? '+' : ''}${tempC} °C`;
    }
    const tempC = Math.round(-98 + elev * 112); // -98°C to +14°C
    return `${tempC > 0 ? '+' : ''}${tempC} °C`;
  }, [body, solarAngle]);

  // Human-readable physical behavior explanation for modal & telemetry
  const getBehaviorExplanation = (state: SurfaceBehaviorState): string => {
    const map: Record<SurfaceBehaviorState, Record<Language, string>> = {
      patrol_active: {
        es: 'En patrulla activa · Ruedas y espectrómetro operando en Jezero',
        en: 'Active patrol · Wheels & spectrometer operating at Jezero',
      },
      slow_worn_drive: {
        es: 'Avance lento activo · Ruedas de aluminio desgastadas tras >32 km',
        en: 'Slow active drive · Worn aluminum wheels after >32 km',
      },
      damaged_rotor_wind: {
        es: 'Inmovilizado en tierra · Pala de rotor dañada en vuelo 72 (2024)',
        en: 'Grounded on dune · Rotor blade chipped on Flight 72 (2024)',
      },
      stuck_in_sand: {
        es: 'Inmovilizado desde 2010 · Rueda delantera atascada en arena blanda',
        en: 'Immobilized since 2010 · Front wheel trapped in soft sand',
      },
      dust_hibernation: {
        es: 'En reposo desde 2018 · Paneles cubiertos tras tormenta global de polvo',
        en: 'Dormant since 2018 · Solar panels covered by global dust storm',
      },
      misaligned_antenna: {
        es: 'Estacionado desde 1982 · Antena desviada por error de comando',
        en: 'Stationary since 1982 · Dish mispointed by software command',
      },
      laser_bounce: {
        es: 'Óptica pasiva activa · Refleja pulsos láser desde la Tierra sin motores',
        en: 'Active passive optics · Bounces Earth laser pulses with zero motors',
      },
      seismic_station: {
        es: 'Estación fija silenciosa · Sismómetro SEIS apoyado sobre regolito',
        en: 'Silent fixed lander · SEIS seismometer resting on regolith',
      },
      polar_frost: {
        es: 'Inactivo en polo norte · Zanja de hielo preservada bajo invierno de CO₂',
        en: 'Inactive at north pole · Ice trench preserved under CO₂ frost',
      },
      static_heritage: {
        es: 'Hardware estacionado · Preservado como patrimonio histórico NASA',
        en: 'Parked heritage hardware · Preserved as NASA historic site',
      },
    };
    return map[state][lang];
  };

  // Radar mini-map scrubbing helper
  const handleRadarScrub = (clientX: number) => {
    const track = radarTrackRef.current;
    if (!track) return;
    const rect = track.getBoundingClientRect();
    const ratio = Math.min(Math.max((clientX - rect.left) / rect.width, 0), 1);
    const worldX = ratio * PANORAMA_WIDTH;
    const cw = containerSize.w;
    const ch = containerSize.h;
    const st = panState.current;
    st.animatingTarget = false;
    const clamped = clampPan(cw / 2 - worldX * st.zoom, st.offsetY, st.zoom, cw, ch);
    st.offsetX = clamped.x;
    st.offsetY = clamped.y;
    syncCamera();
  };

  // Gravity calculations
  const earthWeightN = testMassKg * 9.807;
  const moonWeightN = testMassKg * 1.622;
  const marsWeightN = testMassKg * 3.72;
  const moonApparentKg = testMassKg * (1.622 / 9.807);
  const marsApparentKg = testMassKg * (3.72 / 9.807);

  // Camera window metrics for Radar Mini-Map
  const radarViewLeftPct = Math.max(
    0,
    Math.min(100, (-cameraSnapshot.offsetX / (PANORAMA_WIDTH * cameraSnapshot.zoom)) * 100)
  );
  const radarViewWidthPct = Math.min(
    100 - radarViewLeftPct,
    Math.max(6, (containerSize.w / (PANORAMA_WIDTH * cameraSnapshot.zoom)) * 100)
  );

  const toggleTool = (tool: ActiveTool) => {
    nasaAudio.playTelemetryChirp(790);
    setActiveTool((prev) => (prev === tool ? 'none' : tool));
  };

  return (
    <section
      ref={sectionRef}
      className="relative h-full w-full overflow-hidden bg-[#05070c] select-none"
    >
      {/* Full-Viewport Adaptive Surface Canvas + Interactive Sprite Layer */}
      <div
        onPointerDown={(e) => {
          if ((e.target as HTMLElement).closest('button')) return;
          const st = panState.current;
          st.animatingTarget = false;
          st.isPanning = true;
          st.startX = e.clientX;
          st.startY = e.clientY;
          st.originX = st.offsetX;
          st.originY = st.offsetY;
        }}
        onPointerMove={(e) => {
          const st = panState.current;
          if (!st.isPanning) return;
          const dx = e.clientX - st.startX;
          const dy = e.clientY - st.startY;
          const clamped = clampPan(
            st.originX + dx,
            st.originY + dy,
            st.zoom,
            containerSize.w,
            containerSize.h
          );
          st.offsetX = clamped.x;
          st.offsetY = clamped.y;
          syncCamera();
        }}
        onPointerUp={() => {
          panState.current.isPanning = false;
        }}
        onPointerCancel={() => {
          panState.current.isPanning = false;
        }}
        onTouchStart={(e) => {
          if (e.touches.length === 2) {
            panState.current.isPanning = false;
            panState.current.lastPinchDist = Math.hypot(
              e.touches[0].clientX - e.touches[1].clientX,
              e.touches[0].clientY - e.touches[1].clientY
            );
          }
        }}
        onTouchMove={(e) => {
          if (e.touches.length === 2) {
            const dist = Math.hypot(
              e.touches[0].clientX - e.touches[1].clientX,
              e.touches[0].clientY - e.touches[1].clientY
            );
            if (panState.current.lastPinchDist > 0) {
              const rect = sectionRef.current?.getBoundingClientRect();
              const cx = (e.touches[0].clientX + e.touches[1].clientX) / 2 - (rect?.left ?? 0);
              const cy = (e.touches[0].clientY + e.touches[1].clientY) / 2 - (rect?.top ?? 0);
              adjustSurfaceZoom(dist / panState.current.lastPinchDist, cx, cy);
            }
            panState.current.lastPinchDist = dist;
          }
        }}
        onWheel={(e) => {
          e.preventDefault();
          const rect = sectionRef.current?.getBoundingClientRect();
          const ox = e.clientX - (rect?.left ?? 0);
          const oy = e.clientY - (rect?.top ?? 0);
          adjustSurfaceZoom(e.deltaY < 0 ? 1.12 : 0.89, ox, oy);
        }}
        className="relative h-full w-full cursor-grab touch-none overflow-hidden active:cursor-grabbing"
      >
        <canvas ref={canvasRef} className="pointer-events-none block h-full w-full" />

        {/* Projected Miniature Hardware Sprites & Labels */}
        <div ref={hotspotsLayerRef} className="pointer-events-none absolute inset-0 overflow-hidden">
          {hotspots.map((spot) => {
            const pos = projectSpot(
              spot.x,
              spot.yRatio,
              cameraSnapshot.offsetX,
              cameraSnapshot.offsetY,
              cameraSnapshot.zoom,
              containerSize.h
            );
            if (pos.x < -120 || pos.x > containerSize.w + 120) return null;

            const isVisited = visitedIds.has(spot.id);
            const isActiveSpot = spot.status === 'active';
            const isSelected = selectedHotspot?.id === spot.id;

            return (
              <button
                key={spot.id}
                type="button"
                onClick={() => handleOpenHotspot(spot)}
                style={{ left: `${Math.round(pos.x)}px`, top: `${Math.round(pos.y)}px` }}
                className="group pointer-events-auto absolute z-10 flex min-h-[54px] min-w-[60px] -translate-x-1/2 -translate-y-1/2 cursor-pointer flex-col items-center justify-end focus-visible:outline-2 focus-visible:outline-amber-400"
                aria-label={spot.name[lang]}
              >
                {/* Status Indicator Ring behind active objects */}
                {isActiveSpot && (
                  <span
                    aria-hidden="true"
                    className="hotspot-radar-wave pointer-events-none absolute bottom-5 h-10 w-10 rounded-full border border-emerald-400/70"
                  />
                )}

                {/* Miniature Hardware Sprite (History-accurate motion or stillness) */}
                <div
                  className={`transition-transform duration-150 group-hover:scale-110 ${
                    isSelected ? 'scale-110 drop-shadow-[0_0_8px_rgba(245,158,11,0.75)]' : ''
                  }`}
                >
                  <SurfaceSprite
                    type={spot.iconType}
                    behaviorState={spot.behaviorState}
                    solarAngle={solarAngle}
                    isCompact={isMobileLayout || cameraSnapshot.zoom < 0.72}
                  />
                </div>

                {/* Concise Terrain Label + Status Marker */}
                <span
                  className={`mt-0.5 flex items-center gap-1 rounded-md border px-1.5 py-0.5 font-mono text-[10px] font-semibold whitespace-nowrap shadow-md transition-colors ${
                    isSelected
                      ? 'border-amber-400 bg-amber-500 text-slate-950'
                      : isVisited
                        ? 'border-sky-400/50 bg-[#07090e]/92 text-sky-200'
                        : isActiveSpot
                          ? 'border-emerald-500/50 bg-[#07090e]/92 text-emerald-300'
                          : 'border-slate-700/80 bg-[#07090e]/88 text-slate-100'
                  }`}
                >
                  {isVisited && !isSelected && <Check className="h-2.5 w-2.5 text-sky-400" strokeWidth={3} />}
                  {isActiveSpot && !isVisited && !isSelected && (
                    <span className="text-[8px] text-emerald-400">●</span>
                  )}
                  <span>{spot.shortLabel[lang]}</span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Top Left Collapsible Environmental Telemetry & Body Switcher */}
      <aside
        className={`fixed z-20 transition-all ${
          isMobileLayout
            ? 'top-15 left-2.5 max-w-[calc(100%-20px)]'
            : 'top-16 left-3 w-[calc(100%-24px)] max-w-[340px] sm:top-18 sm:left-6'
        }`}
      >
        <div className="rounded-xl border border-slate-800 bg-[#0b101b]/92 backdrop-blur-md">
          {/* Compact Top Row: Moon/Mars Switch + Temp Preview + Minimize/Expand Button */}
          <div className="flex items-center justify-between gap-2 px-2.5 py-2">
            <div className="flex items-center gap-1 rounded-lg bg-[#07090e] p-0.5">
              <button
                type="button"
                onClick={() => {
                  nasaAudio.playTelemetryChirp(820);
                  onChangeBody('moon');
                }}
                className={`min-h-[32px] cursor-pointer rounded-md px-2.5 py-1 text-xs font-semibold whitespace-nowrap transition-colors ${
                  body === 'moon'
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {t.navMoon}
              </button>
              <button
                type="button"
                onClick={() => {
                  nasaAudio.playTelemetryChirp(820);
                  onChangeBody('mars');
                }}
                className={`min-h-[32px] cursor-pointer rounded-md px-2.5 py-1 text-xs font-semibold whitespace-nowrap transition-colors ${
                  body === 'mars'
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {t.navMars}
              </button>
            </div>

            <div className="flex items-center gap-2">
              {!telemetryOpen && (
                <span className="font-mono-tabular text-[11px] font-medium text-slate-300">
                  {dynamicTempDisplay}
                </span>
              )}
              <span className="font-mono-tabular text-[11px] font-semibold text-amber-400">
                {visitedInBody}/{allHotspots.length}
              </span>
              <button
                type="button"
                onClick={() => {
                  nasaAudio.playTelemetryChirp(740);
                  setTelemetryOpen((v) => !v);
                }}
                aria-label={telemetryOpen ? t.minimizeTelemetry : t.expandTelemetry}
                title={telemetryOpen ? t.minimizeTelemetry : t.expandTelemetry}
                className="flex min-h-[32px] cursor-pointer items-center gap-1 rounded-lg border border-slate-700/80 bg-slate-900/80 px-2 py-1 text-[11px] font-medium whitespace-nowrap text-slate-200 transition-colors hover:border-amber-400/60 hover:text-amber-300"
              >
                {telemetryOpen ? (
                  <>
                    <ChevronUp className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">{t.hideTelemetry}</span>
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-3.5 w-3.5" />
                    <span>{t.showTelemetry}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Expandable Body: Filters + Full Environmental Telemetry */}
          {telemetryOpen && (
            <>
              <div className="grid grid-cols-3 gap-1 border-t border-slate-800/80 px-2.5 py-1.5">
                {(
                  [
                    { id: 'all', label: t.filterAll },
                    { id: 'active', label: t.filterActive },
                    { id: 'silent', label: t.filterSilent },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => {
                      nasaAudio.playTelemetryChirp(760);
                      setStatusFilter(f.id);
                    }}
                    className={`min-h-[30px] cursor-pointer rounded-md px-2 py-1 text-[11px] font-medium whitespace-nowrap transition-colors ${
                      statusFilter === f.id
                        ? 'bg-slate-800 text-amber-300'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              <div className="border-t border-slate-800/80 px-3 py-2.5">
                <div className="mb-1.5 text-[11px] font-semibold tracking-wide text-amber-400 uppercase">
                  {body === 'moon' ? t.telemetryPanelMoon : t.telemetryPanelMars}
                </div>
                <dl className="divide-y divide-slate-800/70 text-xs">
                  <div className="flex justify-between gap-2 py-1">
                    <dt className="text-slate-400">{t.surfaceTemp}</dt>
                    <dd className="font-mono-tabular text-right font-semibold text-amber-300">
                      {dynamicTempDisplay}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-2 py-1">
                    <dt className="text-slate-400">{t.surfaceGrav}</dt>
                    <dd className="font-mono-tabular text-right font-semibold text-slate-100">
                      {body === 'moon' ? '1.622 m/s² (0.166 g)' : '3.720 m/s² (0.379 g)'}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-2 py-1">
                    <dt className="text-slate-400">{t.atmoPress}</dt>
                    <dd className="font-mono-tabular text-right font-semibold text-slate-100">
                      {body === 'moon' ? '3 × 10⁻¹⁵ atm' : '6.1 mbar (95.3% CO₂)'}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-2 py-1">
                    <dt className="text-slate-400">{body === 'moon' ? t.diurnalCycle : t.diurnalSol}</dt>
                    <dd className="font-mono-tabular text-right font-semibold text-slate-100">
                      {body === 'moon' ? '27.3 d' : '24h 39m 35s'}
                    </dd>
                  </div>
                  <div className="flex justify-between gap-2 py-1">
                    <dt className="text-slate-400">{t.radiation}</dt>
                    <dd className="font-mono-tabular text-right font-semibold text-slate-100">
                      {body === 'moon' ? '1.32 mSv/d' : '0.67 mSv/d'}
                    </dd>
                  </div>
                </dl>
              </div>
            </>
          )}
        </div>
      </aside>

      {/* Brief Timed Helio Surface Cameo */}
      <HelioCameo
        lang={lang}
        isMobileLayout={isMobileLayout}
        message={body === 'moon' ? t.helioMoonMsg : t.helioMarsMsg}
        triggerKey={`surface-${body}`}
        position="surface"
      />

      {/* Right Surface Zoom & Reset Controls */}
      <div
        className={`fixed z-20 flex flex-col gap-1.5 ${
          isMobileLayout ? 'right-2.5 bottom-28' : 'right-3 bottom-32 sm:right-6'
        }`}
      >
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(900);
            adjustSurfaceZoom(1.22);
          }}
          aria-label={t.zoomIn}
          title={t.zoomIn}
          className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl border border-slate-800 bg-[#0b101b]/90 text-slate-200 backdrop-blur-md hover:border-amber-400/60 hover:text-amber-300 sm:h-11 sm:w-11"
        >
          <Plus className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(700);
            adjustSurfaceZoom(0.8);
          }}
          aria-label={t.zoomOut}
          title={t.zoomOut}
          className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl border border-slate-800 bg-[#0b101b]/90 text-slate-200 backdrop-blur-md hover:border-amber-400/60 hover:text-amber-300 sm:h-11 sm:w-11"
        >
          <Minus className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => {
            nasaAudio.playTelemetryChirp(800);
            resetCameraView();
          }}
          aria-label={t.resetView}
          title={t.resetView}
          className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-xl border border-slate-800 bg-[#0b101b]/90 text-slate-200 backdrop-blur-md hover:border-amber-400/60 hover:text-amber-300 sm:h-11 sm:w-11"
        >
          <RotateCcw className="h-4 w-4" />
        </button>
      </div>

      {/* Bottom Interactive Dock: Tools Panel + Radar Mini-Map + Waypoints */}
      <div className="fixed right-0 bottom-2.5 left-0 z-20 mx-auto flex max-w-[1260px] flex-col items-center gap-1.5 px-2.5 sm:bottom-4 sm:px-4">
        {/* Active Tool Popover Drawer */}
        {activeTool !== 'none' && (
          <div className="w-full max-w-xl rounded-xl border border-slate-700/90 bg-[#0b101b]/96 p-3 shadow-2xl backdrop-blur-xl">
            {/* 1. SOLAR ILLUMINATION & SHADOWS */}
            {activeTool === 'solar' && (
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-amber-300">
                    {t.solarElevationLabel} · {dynamicTempDisplay}
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveTool('none')}
                    aria-label={t.closeTool}
                    className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-md text-slate-400 hover:bg-slate-800 hover:text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
                <input
                  type="range"
                  min={8}
                  max={195}
                  value={solarAngle}
                  onChange={(e) => setSolarAngle(Number(e.target.value))}
                  aria-label={t.solarElevationLabel}
                  className="mt-2.5 h-2 w-full cursor-pointer accent-amber-400"
                />
                <div className="mt-2 grid grid-cols-4 gap-1.5">
                  {[
                    { label: t.solarPresetDawn, angle: 20 },
                    { label: t.solarPresetNoon, angle: 90 },
                    { label: t.solarPresetDusk, angle: 162 },
                    { label: t.solarPresetNight, angle: 192 },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => {
                        nasaAudio.playTelemetryChirp(820);
                        setSolarAngle(preset.angle);
                      }}
                      className={`min-h-[32px] cursor-pointer rounded-md px-2 py-1 text-[11px] font-semibold transition-colors ${
                        Math.abs(solarAngle - preset.angle) < 12
                          ? 'bg-amber-500 text-slate-950'
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 2. HISTORICAL MISSION TIMELINE */}
            {activeTool === 'timeline' && (
              <div>
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="text-xs font-semibold text-amber-300">{t.timelineTitle}</div>
                    <div className="text-[11px] text-slate-400">{t.timelineSubtitle}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTool('none')}
                    aria-label={t.closeTool}
                    className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-md text-slate-400 hover:bg-slate-800 hover:text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="no-scrollbar mt-2.5 flex items-center gap-1.5 overflow-x-auto pb-1">
                  {timelineHotspots.map((spot) => {
                    const active = selectedHotspot?.id === spot.id;
                    return (
                      <button
                        key={spot.id}
                        type="button"
                        onClick={() => panToHotspot(spot, false)}
                        className={`flex shrink-0 cursor-pointer flex-col items-start rounded-lg border px-2.5 py-1.5 text-left transition-colors ${
                          active
                            ? 'border-amber-400 bg-amber-500/15 text-amber-200'
                            : 'border-slate-800 bg-[#07090e] text-slate-300 hover:border-slate-600'
                        }`}
                      >
                        <span className="font-mono-tabular text-[11px] font-bold text-amber-400">
                          {spot.missionYear}
                        </span>
                        <span className="text-[11px] font-medium whitespace-nowrap">
                          {spot.shortLabel[lang]}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 3. GRAVITY & WEIGHT COMPARATOR */}
            {activeTool === 'gravity' && (
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-amber-300">{t.gravityTitle}</span>
                  <button
                    type="button"
                    onClick={() => setActiveTool('none')}
                    aria-label={t.closeTool}
                    className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-md text-slate-400 hover:bg-slate-800 hover:text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <label className="text-[11px] text-slate-300">
                    {t.gravityInputLabel}:{' '}
                    <span className="font-mono-tabular font-bold text-amber-400">{testMassKg} kg</span>
                  </label>
                  <div className="flex flex-wrap gap-1">
                    {[
                      { label: t.gravityPresetHuman, kg: 70 },
                      { label: t.gravityPresetSuit, kg: 150 },
                      { label: t.gravityPresetRover, kg: 1025 },
                    ].map((p) => (
                      <button
                        key={p.kg}
                        type="button"
                        onClick={() => setTestMassKg(p.kg)}
                        className={`cursor-pointer rounded-md px-2 py-0.5 text-[10px] font-semibold ${
                          testMassKg === p.kg
                            ? 'bg-amber-500 text-slate-950'
                            : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
                <input
                  type="range"
                  min={10}
                  max={1100}
                  step={5}
                  value={testMassKg}
                  onChange={(e) => setTestMassKg(Number(e.target.value))}
                  aria-label={t.gravityInputLabel}
                  className="mt-2 h-2 w-full cursor-pointer accent-amber-400"
                />
                <div className="mt-2.5 grid grid-cols-3 gap-2">
                  {[
                    {
                      name: t.gravityEarth,
                      weightN: earthWeightN,
                      appKg: testMassKg,
                      jumpCm: 45,
                      accent: 'text-sky-300',
                    },
                    {
                      name: t.gravityMoon,
                      weightN: moonWeightN,
                      appKg: moonApparentKg,
                      jumpCm: 270,
                      accent: 'text-slate-100',
                    },
                    {
                      name: t.gravityMars,
                      weightN: marsWeightN,
                      appKg: marsApparentKg,
                      jumpCm: 118,
                      accent: 'text-amber-300',
                    },
                  ].map((planet) => (
                    <div
                      key={planet.name}
                      className="rounded-lg border border-slate-800 bg-[#07090e] p-2 text-center"
                    >
                      <div className={`text-[11px] font-bold ${planet.accent}`}>{planet.name}</div>
                      <div className="font-mono-tabular mt-1 text-xs font-bold text-slate-100">
                        {planet.appKg.toFixed(1)} kg
                      </div>
                      <div className="font-mono-tabular text-[10px] text-slate-400">
                        {Math.round(planet.weightN)} N · {planet.jumpCm} cm
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 4. INTERACTIVE RADAR MINI-MAP (Mobile & Popover) */}
            {activeTool === 'radar' && (
              <div>
                <div className="mb-2 flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-amber-300">
                    {t.toolRadar} · {PANORAMA_WIDTH} px
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveTool('none')}
                    aria-label={t.closeTool}
                    className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-md text-slate-400 hover:bg-slate-800 hover:text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div
                  ref={radarTrackRef}
                  onPointerDown={(e) => handleRadarScrub(e.clientX)}
                  onPointerMove={(e) => {
                    if (e.buttons === 1) handleRadarScrub(e.clientX);
                  }}
                  className="relative h-8 w-full cursor-crosshair overflow-hidden rounded-lg border border-slate-700 bg-[#07090e]"
                >
                  <div
                    className="pointer-events-none absolute top-0 bottom-0 border border-amber-400/80 bg-amber-400/15"
                    style={{ left: `${radarViewLeftPct}%`, width: `${radarViewWidthPct}%` }}
                  />
                  {hotspots.map((spot) => {
                    const leftPct = (spot.x / PANORAMA_WIDTH) * 100;
                    const visited = visitedIds.has(spot.id);
                    return (
                      <span
                        key={spot.id}
                        style={{ left: `${leftPct}%` }}
                        className={`pointer-events-none absolute top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full ${
                          visited
                            ? 'bg-sky-400'
                            : spot.status === 'active'
                              ? 'bg-emerald-400'
                              : 'bg-amber-400'
                        }`}
                      />
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Inline Desktop Radar Mini-Map + Tool Dock Row */}
        <div className="flex w-full items-center justify-center gap-2">
          {/* Interactive Tools Strip */}
          <div className="flex items-center gap-1 rounded-xl border border-slate-800 bg-[#0b101b]/95 p-1 backdrop-blur-md">
            <button
              type="button"
              onClick={() => toggleTool('solar')}
              className={`flex min-h-[34px] cursor-pointer items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                activeTool === 'solar'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Sun className="h-3.5 w-3.5" />
              <span>{t.toolSolar}</span>
            </button>
            <button
              type="button"
              onClick={() => toggleTool('timeline')}
              className={`flex min-h-[34px] cursor-pointer items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                activeTool === 'timeline'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Clock className="h-3.5 w-3.5" />
              <span>{t.toolTimeline}</span>
            </button>
            <button
              type="button"
              onClick={() => toggleTool('gravity')}
              className={`flex min-h-[34px] cursor-pointer items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                activeTool === 'gravity'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Scale className="h-3.5 w-3.5" />
              <span>{t.toolGravity}</span>
            </button>
            <button
              type="button"
              onClick={() => toggleTool('radar')}
              className={`flex min-h-[34px] cursor-pointer items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-semibold whitespace-nowrap transition-colors ${
                activeTool === 'radar'
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Radar className="h-3.5 w-3.5" />
              <span className={isMobileLayout ? 'inline' : 'inline sm:hidden lg:inline'}>
                {t.toolRadar}
              </span>
            </button>
          </div>

          {/* Desktop Hint */}
          {!isMobileLayout && (
            <div className="hidden items-center gap-1.5 text-[11px] text-slate-300 lg:flex">
              <Compass className="h-3.5 w-3.5 text-amber-400" />
              <span>{t.panHint}</span>
            </div>
          )}
        </div>

        {/* Bottom Waypoint Quick-Jump Bar */}
        <nav
          aria-label="Surface Artifacts"
          className="no-scrollbar flex w-full max-w-full items-center gap-1.5 overflow-x-auto rounded-xl border border-slate-800 bg-[#0b101b]/95 p-1.5 backdrop-blur-md sm:w-auto"
        >
          {hotspots.map((spot) => {
            const visited = visitedIds.has(spot.id);
            const active = selectedHotspot?.id === spot.id;
            const isActiveSpot = spot.status === 'active';
            return (
              <button
                key={spot.id}
                type="button"
                onClick={() => panToHotspot(spot, true)}
                className={`flex min-h-[38px] shrink-0 cursor-pointer items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-amber-500 text-slate-950'
                    : visited
                      ? 'bg-slate-800/90 text-sky-300 hover:bg-slate-700'
                      : isActiveSpot
                        ? 'text-emerald-300 hover:bg-slate-800/80'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                }`}
              >
                {visited && !active && <Check className="h-3 w-3 text-sky-400" />}
                <span>{spot.shortLabel[lang]}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Narrative Technical Inspection Modal */}
      {selectedHotspot && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="artifact-modal-title"
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/80 p-0 backdrop-blur-sm sm:items-center sm:p-6"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedHotspot(null);
          }}
        >
          <div className="flex max-h-[92dvh] w-full max-w-4xl flex-col overflow-hidden rounded-t-2xl border border-slate-800 bg-[#0b101b] sm:rounded-2xl md:grid md:grid-cols-12">
            {/* Left Blueprint Column */}
            <div className="relative flex h-44 shrink-0 flex-col justify-between border-b border-slate-800 md:col-span-5 md:h-auto md:border-r md:border-b-0">
              <SchematicSVG type={selectedHotspot.iconType} />
              <div className="flex items-center justify-between border-t border-slate-800/80 bg-[#07090e] px-4 py-2 font-mono-tabular text-[11px] text-slate-400">
                <span>NSSDCA ARCHIVE</span>
                <span>{selectedIndex + 1} / {hotspots.length}</span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedHotspot(null)}
                aria-label={t.closeDossier}
                className="absolute top-3 right-3 flex h-9 w-9 cursor-pointer items-center justify-center rounded-lg border border-slate-700 bg-[#07090e]/90 text-slate-300 hover:text-white md:hidden"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Right Story & Specs Column */}
            <div className="flex flex-1 flex-col overflow-y-auto p-5 sm:p-6 md:col-span-7">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-mono-tabular text-[11px] font-semibold tracking-wide text-amber-400 uppercase">
                    {selectedHotspot.category[lang]}
                  </p>
                  <h3
                    id="artifact-modal-title"
                    className="font-display mt-1 text-xl font-bold tracking-tight text-slate-50 sm:text-2xl"
                  >
                    {selectedHotspot.name[lang]}
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedHotspot(null)}
                  aria-label={t.closeDossier}
                  className="hidden h-9 w-9 shrink-0 cursor-pointer items-center justify-center rounded-lg border border-slate-800 bg-slate-900 text-slate-400 transition-colors hover:border-slate-600 hover:text-white md:flex"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Operational Status + Physical Motion Reason */}
              <div className="mt-2.5 flex flex-wrap items-center gap-2 text-xs">
                <span
                  className={`font-mono-tabular font-semibold ${
                    selectedHotspot.status === 'active' ? 'text-emerald-400' : 'text-slate-300'
                  }`}
                >
                  {selectedHotspot.status === 'active' ? `● ${t.statusActive}` : `○ ${t.statusSilent}`}
                </span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-slate-400">{selectedHotspot.statusNote[lang]}</span>
              </div>

              <div className="mt-2 rounded-lg border border-slate-800 bg-[#07090e]/80 px-3 py-2 text-xs text-sky-200">
                <span className="font-semibold text-sky-400">{t.behaviorStateTitle}: </span>
                <span>{getBehaviorExplanation(selectedHotspot.behaviorState)}</span>
              </div>

              {/* 4-cell Technical Specs */}
              <dl className="mt-3.5 grid grid-cols-1 gap-2 sm:grid-cols-2">
                <div className="rounded-lg border border-slate-800 bg-[#07090e]/70 p-2.5">
                  <dt className="text-[10px] tracking-wider text-slate-400 uppercase">
                    {t.yearLabel}
                  </dt>
                  <dd className="font-mono-tabular mt-0.5 text-xs font-semibold text-slate-100">
                    {selectedHotspot.year[lang]}
                  </dd>
                </div>
                <div className="rounded-lg border border-slate-800 bg-[#07090e]/70 p-2.5">
                  <dt className="text-[10px] tracking-wider text-slate-400 uppercase">
                    {t.coordsLabel}
                  </dt>
                  <dd className="font-mono-tabular mt-0.5 text-xs font-semibold text-slate-100">
                    {selectedHotspot.coords[lang]}
                  </dd>
                </div>
                <div className="rounded-lg border border-slate-800 bg-[#07090e]/70 p-2.5">
                  <dt className="text-[10px] tracking-wider text-slate-400 uppercase">
                    {t.crewLabel}
                  </dt>
                  <dd className="font-mono-tabular mt-0.5 text-xs font-semibold text-slate-100">
                    {selectedHotspot.crew[lang]}
                  </dd>
                </div>
                <div className="rounded-lg border border-slate-800 bg-[#07090e]/70 p-2.5">
                  <dt className="text-[10px] tracking-wider text-slate-400 uppercase">
                    {t.propLabel}
                  </dt>
                  <dd className="font-mono-tabular mt-0.5 text-xs font-semibold text-slate-100">
                    {selectedHotspot.prop[lang]}
                  </dd>
                </div>
              </dl>

              {/* Challenge Narrative: Why Sent + Discoveries */}
              <div className="mt-4 space-y-3 text-sm leading-relaxed">
                <div>
                  <h4 className="text-xs font-semibold tracking-wide text-sky-300 uppercase">
                    {t.whySentTitle}
                  </h4>
                  <p className="mt-1 text-slate-300">{selectedHotspot.whySent[lang]}</p>
                </div>

                <div>
                  <h4 className="text-xs font-semibold tracking-wide text-emerald-300 uppercase">
                    {t.discoveriesTitle}
                  </h4>
                  <p className="mt-1 text-slate-300">{selectedHotspot.discoveries[lang]}</p>
                </div>
              </div>

              {/* Fun Fact Box */}
              <div className="mt-4 rounded-lg border border-amber-500/30 bg-amber-500/8 p-3.5">
                <div className="text-[11px] font-semibold tracking-wide text-amber-300 uppercase">
                  {t.scienceInsight}
                </div>
                <p className="mt-1 text-xs leading-relaxed text-amber-100/90 sm:text-sm">
                  {selectedHotspot.didactic[lang]}
                </p>
              </div>

              <p className="mt-3 text-xs leading-relaxed text-slate-400 sm:text-sm">
                {selectedHotspot.desc[lang]}
              </p>

              {/* Footer Navigation */}
              <div className="mt-5 flex items-center justify-between gap-2 border-t border-slate-800 pt-4">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => navigateHotspot(-1)}
                    className="flex min-h-[42px] cursor-pointer items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-slate-500 hover:text-white"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    <span>{t.prevArtifact}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateHotspot(1)}
                    className="flex min-h-[42px] cursor-pointer items-center gap-1 rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-200 transition-colors hover:border-slate-500 hover:text-white"
                  >
                    <span>{t.nextArtifact}</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    nasaAudio.playTelemetryChirp(620);
                    setSelectedHotspot(null);
                  }}
                  className="min-h-[42px] cursor-pointer rounded-lg bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-amber-400"
                >
                  {t.closeDossier}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
