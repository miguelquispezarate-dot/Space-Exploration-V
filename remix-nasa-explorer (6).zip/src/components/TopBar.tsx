import React from 'react';
import { BookOpen, Globe2, Laptop, MonitorSmartphone, Rocket, Smartphone, Volume2, VolumeX } from 'lucide-react';
import type { DisplayMode, Language, ScreenView, SurfaceBodyId } from '../types/nasa';
import { UI_COPY } from '../data/nasaData';

interface TopBarProps {
  lang: Language;
  onToggleLang: () => void;
  currentScreen: ScreenView;
  currentSurface: SurfaceBodyId;
  onNavigateScreen: (screen: ScreenView, surface?: SurfaceBodyId) => void;
  onToggleEncyclopedia: () => void;
  audioEnabled: boolean;
  onToggleAudio: () => void;
  displayMode: DisplayMode;
  onChangeDisplayMode: (mode: DisplayMode) => void;
  isMobileLayout: boolean;
}

export const TopBar: React.FC<TopBarProps> = ({
  lang,
  onToggleLang,
  currentScreen,
  currentSurface,
  onNavigateScreen,
  onToggleEncyclopedia,
  audioEnabled,
  onToggleAudio,
  displayMode,
  onChangeDisplayMode,
  isMobileLayout,
}) => {
  const t = UI_COPY[lang];

  const cycleDisplayMode = () => {
    const order: DisplayMode[] = ['auto', 'laptop', 'mobile'];
    const next = order[(order.indexOf(displayMode) + 1) % order.length];
    onChangeDisplayMode(next);
  };

  const modeLabel =
    displayMode === 'mobile'
      ? t.formatMobile
      : displayMode === 'laptop'
        ? t.formatLaptop
        : t.formatAuto;

  return (
    <header className="fixed top-0 right-0 left-0 z-40 border-b border-slate-800/80 bg-[#07090e]/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[1440px] items-center justify-between gap-2 px-3 sm:px-6">
        {/* Zone 1: Brand Wordmark */}
        <button
          type="button"
          onClick={() => onNavigateScreen('launch')}
          className="flex shrink-0 cursor-pointer items-center gap-2 text-left focus-visible:outline-2 focus-visible:outline-amber-400"
        >
          <span
            aria-hidden="true"
            className="relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-slate-400/50 bg-[#0b3d91] font-mono text-[8px] font-bold tracking-wider text-white"
          >
            NASA
            <span className="absolute h-[2px] w-4 -rotate-35 bg-[#ea3943]" />
          </span>
          <span
            className={`font-display font-bold tracking-tight whitespace-nowrap text-slate-50 ${
              isMobileLayout ? 'text-sm' : 'text-base sm:text-lg'
            }`}
          >
            {t.brandTitle}
          </span>
        </button>

        {/* Zone 2: Primary Navigation Links (Desktop / Laptop) */}
        {!isMobileLayout && (
          <nav
            aria-label="Primary Navigation"
            className="hidden items-center gap-6 text-sm font-medium md:flex"
          >
            <button
              type="button"
              onClick={() => onNavigateScreen('launch')}
              className={`cursor-pointer border-b-2 py-1 whitespace-nowrap shrink-0 transition-colors ${
                currentScreen === 'launch'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-slate-400 hover:text-slate-100'
              }`}
            >
              {t.navLaunch}
            </button>
            <button
              type="button"
              onClick={() => onNavigateScreen('solar')}
              className={`cursor-pointer border-b-2 py-1 whitespace-nowrap shrink-0 transition-colors ${
                currentScreen === 'solar'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-slate-400 hover:text-slate-100'
              }`}
            >
              {t.navSolar}
            </button>
            <button
              type="button"
              onClick={() => onNavigateScreen('surface', 'moon')}
              className={`cursor-pointer border-b-2 py-1 whitespace-nowrap shrink-0 transition-colors ${
                currentScreen === 'surface' && currentSurface === 'moon'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-slate-400 hover:text-slate-100'
              }`}
            >
              {t.navMoon}
            </button>
            <button
              type="button"
              onClick={() => onNavigateScreen('surface', 'mars')}
              className={`cursor-pointer border-b-2 py-1 whitespace-nowrap shrink-0 transition-colors ${
                currentScreen === 'surface' && currentSurface === 'mars'
                  ? 'border-amber-400 text-amber-300'
                  : 'border-transparent text-slate-400 hover:text-slate-100'
              }`}
            >
              {t.navMars}
            </button>
          </nav>
        )}

        {/* Zone 3: Format Mode + Quick Nav + Language + Audio + Archive */}
        <div className="flex shrink-0 items-center gap-1 sm:gap-2">
          {currentScreen === 'surface' && (
            <button
              type="button"
              onClick={() => onNavigateScreen('solar')}
              className={`flex min-h-[38px] cursor-pointer items-center gap-1 rounded-lg border border-slate-700/80 bg-slate-900/90 px-2 py-1 text-[11px] font-medium whitespace-nowrap text-slate-200 transition-colors hover:border-amber-400/60 hover:text-amber-300 ${
                isMobileLayout ? 'flex' : 'flex md:hidden'
              }`}
            >
              <Globe2 className="h-3.5 w-3.5" />
              {!isMobileLayout && <span>{t.navSolar}</span>}
            </button>
          )}
          {currentScreen === 'solar' && (
            <button
              type="button"
              onClick={() => onNavigateScreen('launch')}
              aria-label={t.navLaunch}
              className={`flex min-h-[38px] min-w-[38px] cursor-pointer items-center justify-center rounded-lg border border-slate-700/80 bg-slate-900/90 p-1.5 text-slate-200 transition-colors hover:border-amber-400/60 hover:text-amber-300 ${
                isMobileLayout ? 'flex' : 'flex md:hidden'
              }`}
            >
              <Rocket className="h-3.5 w-3.5" />
            </button>
          )}

          <button
            type="button"
            onClick={cycleDisplayMode}
            title={`${t.formatLabel}: ${modeLabel}`}
            aria-label={`${t.formatLabel}: ${modeLabel}`}
            className="flex min-h-[38px] cursor-pointer items-center gap-1 rounded-lg border border-slate-800 bg-slate-900/75 px-2 text-[11px] font-semibold whitespace-nowrap text-slate-300 transition-colors hover:border-sky-400/60 hover:text-sky-300"
          >
            {displayMode === 'mobile' ? (
              <Smartphone className="h-3.5 w-3.5 text-sky-400" />
            ) : displayMode === 'laptop' ? (
              <Laptop className="h-3.5 w-3.5 text-amber-400" />
            ) : (
              <MonitorSmartphone className="h-3.5 w-3.5" />
            )}
            <span className={isMobileLayout ? 'hidden' : 'hidden sm:inline'}>{modeLabel}</span>
          </button>

          <button
            type="button"
            onClick={onToggleLang}
            aria-label="Cambiar idioma / Switch language"
            className="font-mono-tabular flex min-h-[38px] min-w-[36px] cursor-pointer items-center justify-center rounded-lg border border-slate-800 bg-slate-900/70 px-2 text-[11px] font-semibold whitespace-nowrap text-slate-300 transition-colors hover:border-slate-600 hover:text-white"
          >
            {lang.toUpperCase()}
          </button>

          <button
            type="button"
            onClick={onToggleAudio}
            aria-label={audioEnabled ? t.soundOn : t.soundOff}
            title={audioEnabled ? t.soundOn : t.soundOff}
            className="flex min-h-[38px] min-w-[38px] cursor-pointer items-center justify-center rounded-lg border border-slate-800 bg-slate-900/70 text-slate-300 transition-colors hover:border-slate-600 hover:text-amber-300"
          >
            {audioEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4 text-slate-500" />}
          </button>

          <button
            type="button"
            onClick={onToggleEncyclopedia}
            className={`flex min-h-[38px] cursor-pointer items-center gap-1.5 rounded-lg bg-amber-500 font-semibold whitespace-nowrap text-slate-950 transition-colors hover:bg-amber-400 ${
              isMobileLayout ? 'px-2.5 py-1.5 text-[11px]' : 'px-3 py-2 text-xs sm:px-4'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5 shrink-0" />
            <span className={isMobileLayout ? 'hidden' : 'hidden sm:inline'}>{t.encyclopediaBtn}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
