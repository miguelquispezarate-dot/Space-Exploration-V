import type {
  CelestialBody,
  EncyclopediaArticle,
  EncyclopediaTabId,
  Language,
  QuizQuestion,
  SurfaceBodyId,
  SurfaceHotspot,
} from '../types/nasa';

export const UI_COPY: Record<
  Language,
  {
    brandTitle: string;
    navLaunch: string;
    navSolar: string;
    navMoon: string;
    navMars: string;
    encyclopediaBtn: string;
    backToOrbit: string;
    launchLocation: string;
    launchHeroTitle: string;
    launchHeroDesc: string;
    launchCta: string;
    launchingCta: string;
    countdownPrefix: string;
    destinationLabel: string;
    destSolar: string;
    destMoon: string;
    destMars: string;
    stageInspectorTitle: string;
    vehicleLabel: string;
    thrustLabel: string;
    propellantLabel: string;
    countdownLabel: string;
    altitudeLabel: string;
    velocityLabel: string;
    fullSystem: string;
    solarDist: string;
    gravity: string;
    diameter: string;
    leftBehindLabel: string;
    exclusiveMissions: string;
    exploreSurface: string;
    noSurfaceHint: string;
    pauseOrbit: string;
    resumeOrbit: string;
    resetCamera: string;
    zoomIn: string;
    zoomOut: string;
    telemetryPanelMoon: string;
    telemetryPanelMars: string;
    activeSensors: string;
    surfaceTemp: string;
    surfaceGrav: string;
    atmoPress: string;
    diurnalCycle: string;
    diurnalSol: string;
    radiation: string;
    panHint: string;
    exploredCount: string;
    hideTelemetry: string;
    showTelemetry: string;
    filterAll: string;
    filterActive: string;
    filterSilent: string;
    statusActive: string;
    statusSilent: string;
    statusImpacted: string;
    yearLabel: string;
    coordsLabel: string;
    crewLabel: string;
    propLabel: string;
    whySentTitle: string;
    discoveriesTitle: string;
    scienceInsight: string;
    prevArtifact: string;
    nextArtifact: string;
    closeDossier: string;
    encTitle: string;
    encSubtitle: string;
    encSearchPlaceholder: string;
    encNoResults: string;
    tabApollo: string;
    tabMars: string;
    tabDeep: string;
    tabConcepts: string;
    tabQuiz: string;
    quizTitle: string;
    quizSubtitle: string;
    quizScoreLabel: string;
    quizResetBtn: string;
    quizCorrect: string;
    quizIncorrect: string;
    soundOn: string;
    soundOff: string;
    formatLabel: string;
    formatAuto: string;
    formatLaptop: string;
    formatMobile: string;
    introTitle: string;
    introHide: string;
    introShow: string;
    introStep1Title: string;
    introStep1Desc: string;
    introStep2Title: string;
    introStep2Desc: string;
    introStep3Title: string;
    introStep3Desc: string;
    helioName: string;
    helioRole: string;
    helioLaunchMsg: string;
    helioLiftoffMsg: string;
    helioSolarMsg: string;
    helioMoonMsg: string;
    helioMarsMsg: string;
    helioDismiss: string;
    helioSummon: string;
    telemetryLabel: string;
    minimizeTelemetry: string;
    expandTelemetry: string;
    resetView: string;
    toolSolar: string;
    toolTimeline: string;
    toolGravity: string;
    toolRadar: string;
    closeTool: string;
    solarElevationLabel: string;
    solarPresetDawn: string;
    solarPresetNoon: string;
    solarPresetDusk: string;
    solarPresetNight: string;
    timelineTitle: string;
    timelineSubtitle: string;
    gravityTitle: string;
    gravityInputLabel: string;
    gravityPresetHuman: string;
    gravityPresetSuit: string;
    gravityPresetRover: string;
    gravityEarth: string;
    gravityMoon: string;
    gravityMars: string;
    gravityWeightN: string;
    gravityApparentKg: string;
    gravityJumpCm: string;
    behaviorStateTitle: string;
  }
> = {
  es: {
    brandTitle: 'NASA Explorer',
    navLaunch: 'Plataforma',
    navSolar: 'Sistema Solar',
    navMoon: 'Luna',
    navMars: 'Marte',
    encyclopediaBtn: 'Archivo y Reto',
    backToOrbit: 'Volver a órbita',
    launchLocation: 'Centro Espacial Kennedy · Complejo de Lanzamiento 39A',
    launchHeroTitle: 'Abandonados pero no olvidados',
    launchHeroDesc:
      'Descubre las historias reales de los rovers, naves, instrumentos y objetos que la NASA ha dejado en la Luna, Marte y los confines del Sistema Solar desde 1969.',
    launchCta: 'Iniciar cuenta regresiva',
    launchingCta: 'Ascenso orbital en curso...',
    countdownPrefix: 'Ignición en',
    destinationLabel: 'Destino de la expedición',
    destSolar: 'Sistema Solar',
    destMoon: 'La Luna',
    destMars: 'Marte',
    stageInspectorTitle: 'Arquitectura NASA SLS Block 1B',
    vehicleLabel: 'Vehículo',
    thrustLabel: 'Empuje al despegue',
    propellantLabel: 'Propelentes',
    countdownLabel: 'Secuencia',
    altitudeLabel: 'Altitud',
    velocityLabel: 'Velocidad',
    fullSystem: 'Sistema completo',
    solarDist: 'Distancia solar',
    gravity: 'Gravedad',
    diameter: 'Diámetro',
    leftBehindLabel: 'Equipo NASA dejado allí',
    exclusiveMissions: 'Misiones históricas de la NASA',
    exploreSurface: 'Explorar artefactos en',
    noSurfaceHint: 'Cuerpo orbital — explora su legado NASA y sus sondas enviadas arriba.',
    pauseOrbit: 'Pausar órbita',
    resumeOrbit: 'Reanudar órbita',
    resetCamera: 'Centrar vista',
    zoomIn: 'Acercar',
    zoomOut: 'Alejar',
    telemetryPanelMoon: 'Estación ALSEP · La Luna',
    telemetryPanelMars: 'Sensores REMS & InSight · Marte',
    activeSensors: 'Sensores activos',
    surfaceTemp: 'Temperatura superficial',
    surfaceGrav: 'Gravedad superficial',
    atmoPress: 'Presión atmosférica',
    diurnalCycle: 'Ciclo diurno',
    diurnalSol: 'Sol marciano',
    radiation: 'Radiación cósmica',
    panHint: 'Desliza el horizonte o toca cualquier modelo en el terreno para leer su historia',
    exploredCount: 'Descubiertos',
    hideTelemetry: 'Minimizar datos',
    showTelemetry: 'Ver datos',
    filterAll: 'Todos',
    filterActive: 'Activos hoy',
    filterSilent: 'Silenciosos',
    statusActive: 'Activo hoy',
    statusSilent: 'Silencioso',
    statusImpacted: 'Impactado',
    yearLabel: 'Misión y fecha',
    coordsLabel: 'Ubicación exacta',
    crewLabel: 'Tripulación o centro NASA',
    propLabel: 'Masa y energía',
    whySentTitle: '¿Por qué la NASA lo envió al espacio?',
    discoveriesTitle: 'Descubrimientos y estado actual',
    scienceInsight: 'Curiosidad para exploradores',
    prevArtifact: 'Anterior',
    nextArtifact: 'Siguiente',
    closeDossier: 'Cerrar historia',
    encTitle: 'Archivo Vivo y Desafío NASA',
    encSubtitle: 'Historias educativas sobre el equipo dejado en la Luna, Marte y el espacio profundo',
    encSearchPlaceholder: 'Buscar rover, sonda, planeta o historia...',
    encNoResults: 'No se encontraron historias que coincidan con tu búsqueda.',
    tabApollo: 'Luna (Apolo)',
    tabMars: 'Marte (JPL)',
    tabDeep: 'Espacio Profundo',
    tabConcepts: 'Ciencia',
    tabQuiz: 'Reto NASA',
    quizTitle: 'Desafío del Explorador Espacial',
    quizSubtitle: 'Pon a prueba lo que aprendiste sobre los equipos abandonados de la NASA.',
    quizScoreLabel: 'Puntuación',
    quizResetBtn: 'Reiniciar reto',
    quizCorrect: '¡Correcto!',
    quizIncorrect: 'No exactamente — lee la explicación:',
    soundOn: 'Audio activo',
    soundOff: 'Audio silenciado',
    formatLabel: 'Formato de pantalla',
    formatAuto: 'Auto',
    formatLaptop: 'Laptop',
    formatMobile: 'Celular',
    introTitle: 'Cómo funciona la expedición',
    introHide: 'Ocultar guía',
    introShow: 'Cómo explorar',
    introStep1Title: '1. Ignición desde LC-39A',
    introStep1Desc: 'Elige tu formato y destino, luego pulsa iniciar cuenta regresiva para despegar en el cohete SLS.',
    introStep2Title: '2. Toca un planeta en órbita',
    introStep2Desc: 'Presiona cualquier planeta o sonda en el Sistema Solar para leer su historia y descender a su superficie.',
    introStep3Title: '3. Explora dentro de Luna y Marte',
    introStep3Desc: 'Recorre el paisaje, observa qué robots siguen activos o averiados y toca cada objeto para ver su expediente.',
    helioName: 'HELIO',
    helioRole: 'Guía Espacial NASA',
    helioLaunchMsg: '¡Hola! Elige formato Celular o Laptop, selecciona destino y pulsa la ignición para despegar.',
    helioLiftoffMsg: '¡Motores RS-25 al máximo! Ascendiendo hacia la órbita para explorar mundos NASA.',
    helioSolarMsg: 'Toca cualquier planeta para conocer su historia, o entra directo a la Luna y Marte.',
    helioMoonMsg: 'Bienvenido a la Luna. Solo el reflector láser sigue activo; toca cada objeto para leer su historia.',
    helioMarsMsg: 'Estás en Marte: Perseverance y Curiosity siguen rodando; Ingenuity y Spirit descansan por averías.',
    helioDismiss: 'Ocultar guía Helio',
    helioSummon: 'Tip de Helio',
    telemetryLabel: 'Telemetría',
    minimizeTelemetry: 'Minimizar panel',
    expandTelemetry: 'Mostrar temperatura y datos',
    resetView: 'Ajustar vista',
    toolSolar: 'Luz Solar',
    toolTimeline: 'Historia',
    toolGravity: 'Gravedad',
    toolRadar: 'Radar',
    closeTool: 'Cerrar herramienta',
    solarElevationLabel: 'Elevación solar',
    solarPresetDawn: 'Amanecer',
    solarPresetNoon: 'Mediodía',
    solarPresetDusk: 'Atardecer',
    solarPresetNight: 'Noche',
    timelineTitle: 'Línea Temporal de Aterrizajes',
    timelineSubtitle: 'Selecciona un hito histórico para viajar al artefacto',
    gravityTitle: 'Comparador de Gravedad y Peso',
    gravityInputLabel: 'Masa de prueba (kg)',
    gravityPresetHuman: 'Persona (70 kg)',
    gravityPresetSuit: 'Con traje (150 kg)',
    gravityPresetRover: 'Perseverance (1025 kg)',
    gravityEarth: 'Tierra',
    gravityMoon: 'La Luna',
    gravityMars: 'Marte',
    gravityWeightN: 'Peso (N)',
    gravityApparentKg: 'Peso aparente',
    gravityJumpCm: 'Salto est.',
    behaviorStateTitle: 'Estado físico en el terreno',
  },
  en: {
    brandTitle: 'NASA Explorer',
    navLaunch: 'Launchpad',
    navSolar: 'Solar System',
    navMoon: 'The Moon',
    navMars: 'Mars',
    encyclopediaBtn: 'Archive & Quiz',
    backToOrbit: 'Return to Orbit',
    launchLocation: 'Kennedy Space Center · Launch Complex 39A',
    launchHeroTitle: 'Abandoned, Not Forgotten',
    launchHeroDesc:
      'Uncover the true stories of NASA’s rovers, landers, instruments, and artifacts left behind on the Moon, Mars, and across the Solar System since the 1960s.',
    launchCta: 'Start Countdown',
    launchingCta: 'Orbital ascent in progress...',
    countdownPrefix: 'Ignition in',
    destinationLabel: 'Expedition Destination',
    destSolar: 'Solar System',
    destMoon: 'The Moon',
    destMars: 'Mars',
    stageInspectorTitle: 'NASA SLS Block 1B Architecture',
    vehicleLabel: 'Launch Vehicle',
    thrustLabel: 'Liftoff Thrust',
    propellantLabel: 'Propellants',
    countdownLabel: 'Sequence',
    altitudeLabel: 'Altitude',
    velocityLabel: 'Velocity',
    fullSystem: 'Full System',
    solarDist: 'Solar Distance',
    gravity: 'Gravity',
    diameter: 'Diameter',
    leftBehindLabel: 'NASA Equipment Left Behind',
    exclusiveMissions: 'Exclusive NASA Missions',
    exploreSurface: 'Explore artifacts on',
    noSurfaceHint: 'Orbital world — explore the NASA hardware legacy above.',
    pauseOrbit: 'Pause Orbit',
    resumeOrbit: 'Resume Orbit',
    resetCamera: 'Reset View',
    zoomIn: 'Zoom In',
    zoomOut: 'Zoom Out',
    telemetryPanelMoon: 'ALSEP Station · The Moon',
    telemetryPanelMars: 'REMS & InSight Sensors · Mars',
    activeSensors: 'Active Sensors',
    surfaceTemp: 'Surface Temperature',
    surfaceGrav: 'Surface Gravity',
    atmoPress: 'Atmospheric Pressure',
    diurnalCycle: 'Diurnal Cycle',
    diurnalSol: 'Diurnal Sol',
    radiation: 'Cosmic Radiation',
    panHint: 'Swipe the horizon or tap any terrain model to read its story',
    exploredCount: 'Discovered',
    hideTelemetry: 'Minimize',
    showTelemetry: 'Telemetry',
    filterAll: 'All',
    filterActive: 'Active Today',
    filterSilent: 'Silent',
    statusActive: 'Active Today',
    statusSilent: 'Silent',
    statusImpacted: 'Impacted',
    yearLabel: 'Mission & Date',
    coordsLabel: 'Exact Location',
    crewLabel: 'Crew / NASA Center',
    propLabel: 'Mass & Power',
    whySentTitle: 'Why did NASA send it to space?',
    discoveriesTitle: 'Discoveries & Current Status',
    scienceInsight: 'Explorer Fun Fact',
    prevArtifact: 'Previous',
    nextArtifact: 'Next',
    closeDossier: 'Close Story',
    encTitle: 'NASA Living Archive & Quiz',
    encSubtitle: 'Educational stories about NASA hardware left on the Moon, Mars, and deep space',
    encSearchPlaceholder: 'Search rover, probe, planet, or story...',
    encNoResults: 'No matching stories found for your query.',
    tabApollo: 'Moon (Apollo)',
    tabMars: 'Mars (JPL)',
    tabDeep: 'Deep Space',
    tabConcepts: 'Science',
    tabQuiz: 'NASA Quiz',
    quizTitle: 'Space Explorer Challenge',
    quizSubtitle: 'Test what you learned about NASA’s left-behind equipment across space.',
    quizScoreLabel: 'Score',
    quizResetBtn: 'Restart Quiz',
    quizCorrect: 'Correct!',
    quizIncorrect: 'Not quite — here is why:',
    soundOn: 'Audio Active',
    soundOff: 'Audio Muted',
    formatLabel: 'Display format',
    formatAuto: 'Auto',
    formatLaptop: 'Laptop',
    formatMobile: 'Mobile',
    introTitle: 'How the expedition works',
    introHide: 'Hide guide',
    introShow: 'How it works',
    introStep1Title: '1. Ignition at LC-39A',
    introStep1Desc: 'Pick Mobile or Laptop format, choose your target, and start the SLS rocket countdown.',
    introStep2Title: '2. Tap a planet in orbit',
    introStep2Desc: 'Select any planet or probe in the Solar System to read its NASA story and land on Moon or Mars.',
    introStep3Title: '3. Explore inside Moon & Mars',
    introStep3Desc: 'Pan the landscape, spot active rovers vs. damaged artifacts, and tap any model to open its dossier.',
    helioName: 'HELIO',
    helioRole: 'NASA Space Guide',
    helioLaunchMsg: 'Hey! Pick Mobile or Laptop format, choose a destination, and hit countdown to launch.',
    helioLiftoffMsg: 'RS-25 engines at full thrust! Ascending into orbit to explore NASA worlds.',
    helioSolarMsg: 'Tap any planet to read its NASA story, or dive down to the Moon and Mars.',
    helioMoonMsg: 'Welcome to the Moon. Only the laser reflector remains active; tap any model to explore.',
    helioMarsMsg: 'Welcome to Mars: Perseverance & Curiosity keep rolling; Ingenuity & Spirit rest after hardware damage.',
    helioDismiss: 'Dismiss Helio guide',
    helioSummon: 'Helio tip',
    telemetryLabel: 'Telemetry',
    minimizeTelemetry: 'Minimize panel',
    expandTelemetry: 'Show temp & surface data',
    resetView: 'Reset view',
    toolSolar: 'Sunlight',
    toolTimeline: 'Timeline',
    toolGravity: 'Gravity',
    toolRadar: 'Radar',
    closeTool: 'Close tool',
    solarElevationLabel: 'Solar elevation',
    solarPresetDawn: 'Dawn',
    solarPresetNoon: 'Noon',
    solarPresetDusk: 'Dusk',
    solarPresetNight: 'Night',
    timelineTitle: 'Landing & Mission Timeline',
    timelineSubtitle: 'Select a milestone to pan straight to that artifact',
    gravityTitle: 'Gravity & Weight Comparator',
    gravityInputLabel: 'Test mass (kg)',
    gravityPresetHuman: 'Person (70 kg)',
    gravityPresetSuit: 'Suited (150 kg)',
    gravityPresetRover: 'Perseverance (1025 kg)',
    gravityEarth: 'Earth',
    gravityMoon: 'The Moon',
    gravityMars: 'Mars',
    gravityWeightN: 'Weight (N)',
    gravityApparentKg: 'Apparent kg',
    gravityJumpCm: 'Est. jump',
    behaviorStateTitle: 'Physical state on surface',
  },
};

export const NASA_CELESTIAL_BODIES: Record<string, CelestialBody> = {
  sun: {
    id: 'sun',
    name: { es: 'El Sol', en: 'The Sun' },
    shortName: { es: 'Sol', en: 'Sun' },
    tag: { es: 'Estrella anfitriona · Clase G2V', en: 'Host Star · G2V Spectral Class' },
    dist: { es: '0.00 UA', en: '0.00 AU' },
    grav: '274.0 m/s²',
    diam: '1,392,700 km',
    missions: ['Parker Solar Probe', 'SOHO', 'Solar Dynamics Observatory', 'Genesis'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: 'La sonda Parker Solar Probe de la NASA sigue volando hoy directamente a través de la corona solar con su escudo térmico de carbono.',
      en: 'NASA’s Parker Solar Probe is actively flying straight through the Sun’s corona today behind its carbon-composite heat shield.',
    },
    narrative: {
      es: 'El motor gravitacional de nuestro sistema solar. La sonda Parker Solar Probe se acerca más al Sol que ninguna otra nave en la historia, resistiendo más de 1,300 °C en su escudo frontal para entender las tormentas solares que afectan a la Tierra.',
      en: 'The gravitational engine of our solar system. NASA’s Parker Solar Probe flies closer to the Sun than any spacecraft in history, withstanding over 1,300 °C on its heat shield to study solar wind.',
    },
    color: '#fbbf24',
    radius: 34,
    orbitRadius: 0,
    speed: 0,
    hasSurface: false,
    textureType: 'sun',
  },
  mercury: {
    id: 'mercury',
    name: { es: 'Mercurio', en: 'Mercury' },
    shortName: { es: 'Mercurio', en: 'Mercury' },
    tag: { es: 'Planeta 1 · Cráter MESSENGER', en: 'Planet 1 · MESSENGER Impact Site' },
    dist: { es: '0.39 UA (57.9M km)', en: '0.39 AU (57.9M km)' },
    grav: '3.70 m/s²',
    diam: '4,879 km',
    missions: ['Mariner 10 (1974–1975)', 'MESSENGER (2004–2015)'],
    leftBehindStatus: 'impacted',
    leftBehindSummary: {
      es: 'En abril de 2015, tras quedarse sin combustible, la sonda MESSENGER de la NASA impactó contra Mercurio a 14,000 km/h dejando un cráter de ~16 metros.',
      en: 'In April 2015, after exhausting its propellant, NASA’s MESSENGER spacecraft impacted Mercury at 14,000 km/h, carving a ~16-meter crater.',
    },
    narrative: {
      es: 'El planeta más cercano al Sol sufre contrastes de +430 °C de día y -180 °C de noche. Gracias a MESSENGER de la NASA —que orbitó Mercurio 4,104 veces antes de estrellarse en su superficie— descubrimos hielo de agua escondido en sus cráteres polares.',
      en: 'The innermost planet swings from +430 °C by day to -180 °C at night. NASA’s MESSENGER orbited Mercury 4,104 times before impacting its surface, discovering water ice preserved in permanently shadowed polar craters.',
    },
    color: '#9ca3af',
    radius: 6,
    orbitRadius: 64,
    speed: 0.011,
    hasSurface: false,
    textureType: 'mercury',
  },
  venus: {
    id: 'venus',
    name: { es: 'Venus', en: 'Venus' },
    shortName: { es: 'Venus', en: 'Venus' },
    tag: { es: 'Planeta 2 · Sondas Pioneer Venus', en: 'Planet 2 · Pioneer Venus Probes' },
    dist: { es: '0.72 UA (108.2M km)', en: '0.72 AU (108.2M km)' },
    grav: '8.87 m/s²',
    diam: '12,104 km',
    missions: ['Mariner 2 (1962)', 'Pioneer Venus Multiprobe (1978)', 'Magellan (1989–1994)'],
    leftBehindStatus: 'silent',
    leftBehindSummary: {
      es: 'Cuatro cápsulas atmosféricas de Pioneer Venus descendieron en 1978; la "Day Probe" sobrevivió aplastada 67 minutos transmitiendo desde la superficie infernal de 460 °C.',
      en: 'Four Pioneer Venus entry probes descended in 1978; the Day Probe famously survived 67 minutes transmitting directly from Venus’s 460 °C surface.',
    },
    narrative: {
      es: 'Envuelto en espesas nubes de ácido sulfúrico y una presión 92 veces mayor que la terrestre, Venus es el planeta más caliente del sistema. La nave Magellan de la NASA cartografió el 98% de sus volcanes con radar antes de sumergirse en su atmósfera en 1994.',
      en: 'Wrapped in sulfuric acid clouds with 92 times Earth’s surface pressure, Venus is our hottest planet. NASA’s Magellan mapped 98% of its volcanic terrain by radar before plunging into its atmosphere in 1994.',
    },
    color: '#eab308',
    radius: 10.5,
    orbitRadius: 94,
    speed: 0.0078,
    hasSurface: false,
    textureType: 'venus',
  },
  earth: {
    id: 'earth',
    name: { es: 'La Tierra', en: 'Earth' },
    shortName: { es: 'Tierra', en: 'Earth' },
    tag: { es: 'Planeta 3 · Origen de la NASA', en: 'Planet 3 · NASA Home World' },
    dist: { es: '1.00 UA (149.6M km)', en: '1.00 AU (149.6M km)' },
    grav: '9.81 m/s²',
    diam: '12,742 km',
    missions: ['Apollo Program', 'Landsat', 'Hubble Space Telescope', 'James Webb (L2)'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: 'Desde Cabo Cañaveral y Houston, la Red del Espacio Profundo (DSN) de la NASA aún escucha hoy señales débiles de sondas enviadas hace más de 45 años.',
      en: 'From Cape Canaveral and Houston, NASA’s Deep Space Network still listens today for faint radio whispers from probes launched over 45 years ago.',
    },
    narrative: {
      es: 'Nuestro hogar azul y punto de partida de todas las misiones. Desde el Complejo 39 en Florida despegaron los Saturno V hacia la Luna y los cohetes Atlas y Delta que enviaron rovers hacia Marte y sondas más allá de Plutón.',
      en: 'Our blue home and launchpad for every mission. From Launch Complex 39 in Florida, Saturn V rockets lifted off to the Moon and robotic spacecraft departed toward Mars and the outer planets.',
    },
    color: '#38bdf8',
    radius: 12,
    orbitRadius: 128,
    speed: 0.0056,
    hasSurface: false,
    textureType: 'earth',
  },
  moon: {
    id: 'moon',
    name: { es: 'La Luna', en: 'The Moon' },
    shortName: { es: 'La Luna', en: 'Moon' },
    tag: { es: 'Satélite terrestre · Museo Apolo de la NASA', en: 'Earth’s Moon · NASA Apollo Museum' },
    dist: { es: '384,400 km de la Tierra', en: '384,400 km from Earth' },
    grav: '1.622 m/s² (1/6 g)',
    diam: '3,474 km',
    missions: ['Apollo 11', 'Apollo 12', 'Apollo 14', 'Apollo 15', 'Apollo 16', 'Apollo 17', 'Surveyor 3', 'LRO'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: 'Más de 180 toneladas de historia NASA permanecen intactas en la Luna: 6 módulos Eagle/Falcon, 3 rovers LRV, huellas, pelotas de golf y retrorreflectores láser ¡aún activos!',
      en: 'Over 180 tons of NASA history remain intact on the Moon: 6 descent stages, 3 Lunar Rovers, bootprints, golf balls, and laser retroreflectors still active today!',
    },
    narrative: {
      es: 'Al no haber viento, lluvia ni atmósfera, cada huella de bota y cada vehículo que la NASA dejó entre 1969 y 1972 permanece congelado en el tiempo. Entra en la superficie para recorrer 11 artefactos históricos, desde el Águila del Apolo 11 hasta experimentos láser vigentes.',
      en: 'With zero wind, rain, or atmosphere, every bootprint and vehicle NASA left behind between 1969 and 1972 remains frozen in time. Dive onto the surface to explore 11 artifacts from Apollo 11 Eagle to active laser experiments.',
    },
    color: '#cbd5e1',
    radius: 7,
    orbitRadius: 162,
    speed: 0.0085,
    hasSurface: true,
    surfaceType: 'moon',
    textureType: 'moon',
  },
  mars: {
    id: 'mars',
    name: { es: 'Marte', en: 'Mars' },
    shortName: { es: 'Marte', en: 'Mars' },
    tag: { es: 'Planeta 4 · Cementerio y Laboratorio JPL', en: 'Planet 4 · NASA JPL Field Lab' },
    dist: { es: '1.52 UA (227.9M km)', en: '1.52 AU (227.9M km)' },
    grav: '3.72 m/s²',
    diam: '6,779 km',
    missions: ['Viking 1 & 2', 'Pathfinder & Sojourner', 'Spirit & Opportunity', 'Phoenix', 'Curiosity', 'InSight', 'Perseverance & Ingenuity'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: 'Perseverance y Curiosity siguen activos hoy enviando datos y fotos, acompañando a veteranos silenciosos como Opportunity, Spirit, InSight, Phoenix, Sojourner y Viking.',
      en: 'Perseverance and Curiosity are actively transmitting today alongside silent pioneers like Opportunity, Spirit, InSight, Phoenix, Sojourner, and Viking.',
    },
    narrative: {
      es: 'El Planeta Rojo es el único mundo poblado únicamente por robots. Explora la superficie marciana para conocer por qué rovers como Opportunity funcionaron 14 años en lugar de 90 días, cómo voló el helicóptero Ingenuity y qué descubrió InSight en el corazón del planeta.',
      en: 'The Red Planet is a world inhabited entirely by robots. Dive onto Mars to learn how Opportunity worked for 14 years instead of 90 days, how Ingenuity flew in thin air, and what InSight heard inside the Martian core.',
    },
    color: '#ea580c',
    radius: 9.5,
    orbitRadius: 204,
    speed: 0.0042,
    hasSurface: true,
    surfaceType: 'mars',
    textureType: 'mars',
  },
  asteroids: {
    id: 'asteroids',
    name: { es: 'Cinturón de Asteroides', en: 'Asteroid Belt' },
    shortName: { es: 'Asteroides', en: 'Asteroids' },
    tag: { es: 'Sondas silenciosas · Dawn y NEAR Shoemaker', en: 'Silent Probes · Dawn & NEAR Shoemaker' },
    dist: { es: '2.2 – 3.2 UA', en: '2.2 – 3.2 AU' },
    grav: '0.27 m/s² (Ceres)',
    diam: '940 km (Ceres)',
    missions: ['NEAR Shoemaker (Eros)', 'NASA Dawn (Vesta & Ceres)', 'OSIRIS-REx (Bennu)', 'Lucy'],
    leftBehindStatus: 'silent',
    leftBehindSummary: {
      es: 'La sonda Dawn orbita hoy en silencio eterno alrededor del planeta enano Ceres, mientras NEAR Shoemaker descansa posada sobre la superficie del asteroide Eros desde 2001.',
      en: 'NASA’s Dawn silently orbits dwarf planet Ceres forever, while NEAR Shoemaker rests gently on asteroid Eros since its historic 2001 landing.',
    },
    narrative: {
      es: 'Restos rocosos de la formación del Sistema Solar. En 2001, NEAR Shoemaker improvisó un aterrizaje suave sobre Eros sin haber sido diseñada para aterrizar. En 2018, Dawn agotó su hidracina quedando como monumento silencioso orbitando Ceres.',
      en: 'Rocky remnants from the birth of our Solar System. In 2001, NEAR Shoemaker pulled off an unplanned soft landing on asteroid Eros. In 2018, Dawn exhausted its fuel and remains a silent monument orbiting Ceres.',
    },
    color: '#94a3b8',
    radius: 5.5,
    orbitRadius: 254,
    speed: 0.003,
    hasSurface: false,
    textureType: 'asteroids',
  },
  jupiter: {
    id: 'jupiter',
    name: { es: 'Júpiter', en: 'Jupiter' },
    shortName: { es: 'Júpiter', en: 'Jupiter' },
    tag: { es: 'Planeta 5 · Sonda Galileo y Juno', en: 'Planet 5 · Galileo & Juno' },
    dist: { es: '5.20 UA (778.5M km)', en: '5.20 AU (778.5M km)' },
    grav: '24.79 m/s²',
    diam: '139,820 km',
    missions: ['Pioneer 10 & 11', 'Voyager 1 & 2', 'Galileo (1989–2003)', 'Juno (2011–Presente)'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: 'La sonda atmosférica Galileo se sumergió en Júpiter en 1995 (y su nave madre en 2003 para proteger a la luna Europa). Hoy la nave Juno de la NASA sigue estudiando sus auroras.',
      en: 'The Galileo atmospheric probe plunged into Jupiter in 1995 (followed by the orbiter in 2003 to protect icy moon Europa). NASA’s Juno continues orbiting today.',
    },
    narrative: {
      es: 'El gigante gaseoso más grande del Sistema Solar. En 1995, una cápsula de titanio soltada por la nave Galileo de la NASA descendió en paracaídas por sus nubes enviando datos durante 58 minutos antes de ser vaporizada por la presión extrema.',
      en: 'Our largest gas giant. In 1995, a titanium probe released by NASA’s Galileo parachuted into Jupiter’s clouds, transmitting 58 minutes of storm data before crushing pressure vaporized it.',
    },
    color: '#d97706',
    radius: 20,
    orbitRadius: 318,
    speed: 0.002,
    hasSurface: false,
    textureType: 'jupiter',
  },
  saturn: {
    id: 'saturn',
    name: { es: 'Saturno', en: 'Saturn' },
    shortName: { es: 'Saturno', en: 'Saturn' },
    tag: { es: 'Planeta 6 · Gran Final de Cassini', en: 'Planet 6 · Cassini Grand Finale' },
    dist: { es: '9.58 UA (1,434M km)', en: '9.58 AU (1,434M km)' },
    grav: '10.44 m/s²',
    diam: '116,460 km',
    missions: ['Pioneer 11 (1979)', 'Voyager 1 & 2', 'Cassini (1997–2017)'],
    leftBehindStatus: 'impacted',
    leftBehindSummary: {
      es: 'El 15 de septiembre de 2017, la nave Cassini de la NASA se zambulló intencionalmente en Saturno transmitiendo datos hasta su último segundo para no contaminar Encélado ni Titán.',
      en: 'On September 15, 2017, NASA’s Cassini intentionally plunged into Saturn, transmitting atmospheric data to its final second to protect Enceladus and Titan.',
    },
    narrative: {
      es: 'Famoso por sus deslumbrantes anillos de hielo y roca. Durante 13 años en órbita, Cassini descubrió géiseres de agua salada brotando de la luna Encélado antes de convertirse en parte del propio Saturno en su "Gran Final".',
      en: 'Famous for its dazzling icy rings. Over 13 years in orbit, Cassini discovered subsurface water-ice plumes erupting from Enceladus before vaporizing inside Saturn in its "Grand Finale".',
    },
    color: '#fcd34d',
    radius: 17,
    orbitRadius: 392,
    speed: 0.0014,
    hasSurface: false,
    textureType: 'saturn',
  },
  uranus: {
    id: 'uranus',
    name: { es: 'Urano', en: 'Uranus' },
    shortName: { es: 'Urano', en: 'Uranus' },
    tag: { es: 'Planeta 7 · Visitado solo por Voyager 2', en: 'Planet 7 · Visited Once by Voyager 2' },
    dist: { es: '19.2 UA (2,871M km)', en: '19.2 AU (2,871M km)' },
    grav: '8.69 m/s²',
    diam: '50,724 km',
    missions: ['Voyager 2 (Sobrevólo en enero de 1986)'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: 'Ninguna nave quedó en Urano, pero Voyager 2 —la única nave en la historia que lo ha visitado— sigue volando hoy en el espacio interestelar a más de 20 mil millones de km.',
      en: 'No probe remains at Uranus, yet Voyager 2 — the only spacecraft ever to visit it — continues flying actively in interstellar space over 20 billion km away.',
    },
    narrative: {
      es: 'Un gigante de hielo que rueda literalmente de costado con una inclinación de 98°. En enero de 1986, la sonda Voyager 2 de la NASA pasó a 81,500 km de sus nubes descubriendo 10 nuevas lunas y dos anillos tenues.',
      en: 'An ice giant that literally rolls on its side at a 98° axial tilt. In January 1986, NASA’s Voyager 2 flew 81,500 km above its clouds, discovering 10 new moons and two faint rings.',
    },
    color: '#67e8f9',
    radius: 13,
    orbitRadius: 454,
    speed: 0.00095,
    hasSurface: false,
    textureType: 'uranus',
  },
  neptune: {
    id: 'neptune',
    name: { es: 'Neptuno', en: 'Neptune' },
    shortName: { es: 'Neptuno', en: 'Neptune' },
    tag: { es: 'Planeta 8 · Frontera de Voyager 2', en: 'Planet 8 · Voyager 2 Frontier' },
    dist: { es: '30.05 UA (4,495M km)', en: '30.05 AU (4,495M km)' },
    grav: '11.15 m/s²',
    diam: '49,244 km',
    missions: ['Voyager 2 (Sobrevuelo en agosto de 1989)'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: 'Voyager 2 realizó en 1989 el único encuentro humano con Neptuno y su luna helada Tritón, y hoy continúa enviando lecturas del viento interestelar a la NASA.',
      en: 'Voyager 2 completed humanity’s sole encounter with Neptune and icy moon Triton in 1989, and still beams interstellar plasma data back to NASA today.',
    },
    narrative: {
      es: 'El planeta más lejano y ventoso del Sistema Solar, con ráfagas supersónicas de más de 2,100 km/h. Voyager 2 capturó su Gran Mancha Oscura y descubrió géiseres de nitrógeno helado en Tritón antes de abandonar la región planetaria.',
      en: 'The outermost and windiest planet in the Solar System, with supersonic gusts exceeding 2,100 km/h. Voyager 2 photographed its Great Dark Spot and nitrogen geysers on Triton before leaving the planets behind.',
    },
    color: '#3b82f6',
    radius: 12.5,
    orbitRadius: 510,
    speed: 0.00068,
    hasSurface: false,
    textureType: 'neptune',
  },
  voyager: {
    id: 'voyager',
    name: { es: 'Sondas Voyager 1 y 2', en: 'Voyager 1 & 2 Probes' },
    shortName: { es: 'Voyager 1 y 2', en: 'Voyager 1 & 2' },
    tag: { es: 'Espacio Interestelar · Más allá de los planetas', en: 'Interstellar Space · Beyond the Planets' },
    dist: { es: '> 136 – 166 UA (24,500M km)', en: '> 136 – 166 AU (24.5B km)' },
    grav: 'Microgravedad interestelar',
    diam: 'Antena 3.7 m · Disco de Oro',
    missions: ['Voyager 1 (1977–Presente)', 'Voyager 2 (1977–Presente)', 'Pioneer 10 & 11', 'New Horizons'],
    leftBehindStatus: 'active',
    leftBehindSummary: {
      es: '¡Siguen activas después de casi 50 años! A más de 22 horas-luz de distancia, sus baterías RTG de Plutonio-238 aún transmiten datos científicos del medio interestelar.',
      en: 'Still active after nearly 50 years! Over 22 light-hours away, their Plutonium-238 RTGs still power instruments sending back interstellar space data.',
    },
    narrative: {
      es: 'Son los objetos fabricados por la humanidad más lejanos de la Tierra. Cada Voyager lleva un Disco de Oro fonográfico con saludos en 55 idiomas, música y sonidos de la Tierra como cápsula del tiempo eterna entre las estrellas.',
      en: 'Humanity’s farthest spacecraft. Each Voyager carries a Golden Record phonograph engraved with greetings in 55 languages, music, and sounds of Earth as an eternal time capsule among the stars.',
    },
    color: '#f59e0b',
    radius: 7,
    orbitRadius: 568,
    speed: 0.00045,
    hasSurface: false,
    textureType: 'voyager',
  },
};

export const NASA_SURFACE_HOTSPOTS: Record<SurfaceBodyId, SurfaceHotspot[]> = {
  moon: [
    {
      id: 'eagle11',
      name: { es: "Módulo Lunar Apolo 11 'Eagle' y Placa", en: "Apollo 11 Lunar Module 'Eagle' & Plaque" },
      shortLabel: { es: 'Apolo 11 Eagle', en: 'Apollo 11 Eagle' },
      category: { es: 'Base Tranquilidad · Primer alunizaje', en: 'Tranquility Base · First Landing' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde 1969 · Monumento histórico protegido',
        en: 'Silent since 1969 · Protected heritage site',
      },
      behaviorState: 'static_heritage',
      missionYear: 1969,
      x: 280,
      yRatio: 0.69,
      year: { es: '20 de julio de 1969', en: 'July 20, 1969' },
      coords: { es: '0.674° N, 23.473° E (Mar de la Tranquilidad)', en: '0.674° N, 23.473° E (Mare Tranquillitatis)' },
      crew: { es: 'Neil Armstrong y Buzz Aldrin', en: 'Neil Armstrong & Buzz Aldrin' },
      prop: { es: 'Etapa de descenso: 2,034 kg en seco', en: 'Descent stage: 2,034 kg dry mass' },
      iconType: 'lunar_module',
      whySent: {
        es: 'Fue diseñado como plataforma de descenso y plataforma de lanzamiento para que Armstrong y Aldrin pudieran alunizar suavemente y luego despegar hacia el módulo Columbia en la parte superior.',
        en: 'Engineered as both a landing cradle and launchpad so Armstrong and Aldrin could touch down safely and blast the upper cabin back to Columbia.',
      },
      discoveries: {
        es: 'Permitió recolectar los primeros 21.55 kg de basaltos lunares, demostrando que los oscuros "mares" lunares son antiguos campos de lava de hace 3,700 millones de años. Su base metálica dorada sigue ahí, silenciosa.',
        en: 'Enabled collection of the first 21.55 kg of lunar basalt, proving the dark lunar maria are ancient lava plains 3.7 billion years old. Its gold-clad descent stage remains silent there today.',
      },
      didactic: {
        es: 'Armstrong esquivó manualmente un cráter lleno de rocas gigantes y posó el Eagle con menos de 25 segundos de combustible restante.',
        en: 'Armstrong manually steered past a boulder-strewn crater and touched down with less than 25 seconds of fuel remaining.',
      },
      desc: {
        es: 'En su pata frontal permanece atornillada la placa de acero inoxidable que dice: "Aquí hombres del planeta Tierra pusieron por primera vez un pie sobre la Luna. Julio de 1969. Vinimos en paz para toda la humanidad".',
        en: 'Bolted to its front landing strut is the stainless steel plaque reading: "Here men from the planet Earth first set foot upon the Moon July 1969, A.D. We came in peace for all mankind."',
      },
    },
    {
      id: 'surveyor3',
      name: { es: 'Sonda Surveyor 3 y Apolo 12', en: 'Surveyor 3 Lander & Apollo 12' },
      shortLabel: { es: 'Surveyor 3', en: 'Surveyor 3' },
      category: { es: 'Arqueología espacial comparativa', en: 'Comparative Space Archaeology' },
      status: 'silent',
      statusNote: {
        es: 'Silenciosa desde 1967 · Visitada por humanos en 1969',
        en: 'Silent since 1967 · Visited by crew in 1969',
      },
      behaviorState: 'static_heritage',
      missionYear: 1967,
      x: 610,
      yRatio: 0.63,
      year: { es: 'Alunizaje 1967 · Visita Apolo 12 (1969)', en: 'Landed 1967 · Apollo 12 Visit (1969)' },
      coords: { es: '3.013° S, 23.422° W (Océano de las Tormentas)', en: '3.013° S, 23.422° W (Oceanus Procellarum)' },
      crew: { es: 'Visitada por Pete Conrad y Alan Bean', en: 'Visited by Pete Conrad & Alan Bean' },
      prop: { es: 'Aterrizador robótico: 296 kg', en: 'Robotic lander: 296 kg' },
      iconType: 'surveyor',
      whySent: {
        es: 'Surveyor 3 fue enviada en 1967 para comprobar si el suelo lunar era lo bastante firme para soportar el peso de una nave tripulada Apolo antes de enviar astronautas.',
        en: 'Surveyor 3 was sent in 1967 to test whether lunar soil was firm enough to support a heavy crewed Apollo lander before humans arrived.',
      },
      discoveries: {
        es: 'Dos años y medio después, Apolo 12 alunizó a solo 180 metros. Conrad y Bean desmontaron su cámara y pala para traerlas a la Tierra y estudiar cómo 31 meses de vacío y radiación afectan a metales y lentes.',
        en: 'Two and a half years later, Apollo 12 landed just 180 meters away. Conrad and Bean removed its camera and scoop to return to Earth, teaching engineers how 31 months in hard vacuum affects spacecraft.',
      },
      didactic: {
        es: 'Fue la primera y única vez en la historia que astronautas caminaron hacia una sonda robótica abandonada en otro mundo para inspeccionarla.',
        en: 'It remains the first and only time humans walked over to an abandoned robotic probe on another world to inspect and recover its parts.',
      },
      desc: {
        es: 'Su esqueleto trípode blanco (ahora teñido de polvo lunar marrón-grisáceo) descansa en la ladera interior del cráter Surveyor.',
        en: 'Its white tripod frame (now coated in brownish-gray lunar dust) still rests along the inner slope of Surveyor Crater.',
      },
    },
    {
      id: 'golf_apolo14',
      name: { es: 'Carrito MET y Pelotas de Golf (Apolo 14)', en: 'MET Cart & Alan Shepard’s Golf Balls (Apollo 14)' },
      shortLabel: { es: 'Golf Apolo 14', en: 'Apollo 14 Golf' },
      category: { es: 'Objetos personales y transporte manual', en: 'Crew Artifacts & Hand Cart' },
      status: 'silent',
      statusNote: {
        es: 'Silenciosos desde 1971 · Siguen en Fra Mauro',
        en: 'Silent since 1971 · Still at Fra Mauro',
      },
      behaviorState: 'static_heritage',
      missionYear: 1971,
      x: 940,
      yRatio: 0.74,
      year: { es: '6 de febrero de 1971 (Apolo 14)', en: 'February 6, 1971 (Apollo 14)' },
      coords: { es: '3.645° S, 17.471° W (Tierras Altas de Fra Mauro)', en: '3.645° S, 17.471° W (Fra Mauro Highlands)' },
      crew: { es: 'Alan Shepard y Edgar Mitchell', en: 'Alan Shepard & Edgar Mitchell' },
      prop: { es: '2 pelotas de golf · Carrito MET de 75 kg', en: '2 golf balls · 75 kg MET hand cart' },
      iconType: 'golf_met',
      whySent: {
        es: 'El carrito de dos ruedas (MET) fue enviado para cargar herramientas y muestras pesadas. Shepard llevó en secreto una cabeza de palo de golf hierro 6 y dos pelotas para demostrar la baja gravedad lunar ante las cámaras de TV.',
        en: 'The two-wheeled MET cart carried heavy geology tools and rocks. Shepard smuggled a 6-iron club head and two golf balls to demonstrate low lunar gravity live on television.',
      },
      discoveries: {
        es: 'El primer golpe falló ligeramente, pero el segundo envió la pelota volar "millas y millas" (en realidad ~36 metros en traje presurizado rígido). El carrito MET y ambas pelotas siguen ahí como prueba de la física en 1/6 de gravedad.',
        en: 'Shepard famously remarked the second ball flew "miles and miles" (actually ~36 meters in a stiff spacesuit). Both balls and the MET cart remain at Fra Mauro.',
      },
      didactic: {
        es: 'Sin resistencia del aire y con solo 1/6 de la gravedad terrestre, ¡una pelota golpeada con un swing completo en la Luna viajaría más de 4 kilómetros!',
        en: 'With zero air drag and 1/6th Earth gravity, a full-power golf swing on the Moon could theoretically send a ball over 4 kilometers!',
      },
      desc: {
        es: 'En 2021, especialistas en imágenes restauraron fotografías originales de Apolo 14 y lograron ubicar las dos pelotas blancas entre los pequeños cráteres cerca del Módulo Antares.',
        en: 'In 2021, imaging specialists digitally restored original Apollo 14 photos and pinpointed the exact resting spots of both white golf balls near the Antares lander.',
      },
    },
    {
      id: 'falcon15',
      name: { es: "Módulo Lunar Apolo 15 'Falcon'", en: "Apollo 15 Lunar Module 'Falcon'" },
      shortLabel: { es: 'Apolo 15 Falcon', en: 'Apollo 15 Falcon' },
      category: { es: 'Etapa de descenso · Hadley-Apeninos', en: 'Descent Stage · Hadley-Apennine' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde 1971 · Aún visible desde órbita LRO',
        en: 'Silent since 1971 · Visible from LRO orbiter',
      },
      behaviorState: 'static_heritage',
      missionYear: 1971,
      x: 1270,
      yRatio: 0.67,
      year: { es: '30 de julio de 1971', en: 'July 30, 1971' },
      coords: { es: '26.132° N, 3.634° E (Planicie de Hadley)', en: '26.132° N, 3.634° E (Hadley Plain)' },
      crew: { es: 'David Scott y James Irwin', en: 'David Scott & James Irwin' },
      prop: { es: '16,430 kg total · Aerozine 50 y N₂O₄', en: '16,430 kg total · Aerozine 50 & N₂O₄' },
      iconType: 'lunar_module',
      whySent: {
        es: 'Fue el primer Módulo Lunar serie J mejorado con tanques más grandes y baterías adicionales para sostener 3 días completos de exploración geológica en las montañas Apeninos.',
        en: 'The first upgraded J-series Lunar Module with larger tanks and batteries to support 3 full days of geological fieldwork near the Apennine Mountains.',
      },
      discoveries: {
        es: 'Permitió recolectar 77.31 kg de rocas, incluida la "Roca Génesis" de 4,100 millones de años. Frente a su cámara, Dave Scott dejó caer un martillo y una pluma de halcón confirmando la ley de caída libre de Galileo.',
        en: 'Supported collection of 77.31 kg of rocks, including the 4.1-billion-year-old Genesis Rock. In front of its TV camera, Dave Scott dropped a hammer and falcon feather proving Galileo’s law.',
      },
      didactic: {
        es: 'Sus láminas doradas de Mylar y Kapton protegen el metal contra cambios térmicos extremos de más de 250 °C entre el día y la noche lunar.',
        en: 'Its crinkly gold Kapton and Mylar thermal blankets shielded the lander against 250 °C temperature swings between lunar day and night.',
      },
      desc: {
        es: 'Cuando la cabina superior despegó hacia la órbita, dejó atrás la base octogonal dorada y sus cuatro patas posadas frente a la enorme grieta volcánica de Hadley.',
        en: 'When the upper ascent cabin blasted back to orbit, it left behind the gold-foil octagonal descent base standing near Hadley Rille.',
      },
    },
    {
      id: 'lrv15',
      name: { es: 'Rover Lunar LRV-1 (Apolo 15)', en: 'Lunar Roving Vehicle LRV-1 (Apollo 15)' },
      shortLabel: { es: 'Rover Lunar LRV', en: 'Lunar Rover LRV' },
      category: { es: 'Primer automóvil tripulado extraterrestre', en: 'First Crewed Off-World Automobile' },
      status: 'silent',
      statusNote: {
        es: 'Estacionado desde agosto de 1971 · Baterías agotadas',
        en: 'Parked since August 1971 · Batteries depleted',
      },
      behaviorState: 'static_heritage',
      missionYear: 1971,
      x: 1600,
      yRatio: 0.74,
      year: { es: '31 de julio de 1971', en: 'July 31, 1971' },
      coords: { es: 'Grieta de Hadley · Apolo 15', en: 'Hadley Rille · Apollo 15' },
      crew: { es: 'David Scott y James Irwin', en: 'David Scott & James Irwin' },
      prop: { es: '210 kg masa terrestre · 4 motores 0.25 HP', en: '210 kg Earth mass · Four 0.25 HP motors' },
      iconType: 'lrv_rover',
      whySent: {
        es: 'Caminar con trajes presurizados limitaba a los astronautas a unos cientos de metros del módulo. La NASA necesitaba un jeep eléctrico plegable para explorar valles, montañas y cráteres a kilómetros de distancia.',
        en: 'Walking in stiff spacesuits limited astronauts to short distances. NASA needed a foldable electric buggy to reach mountains and rilles kilometers away.',
      },
      discoveries: {
        es: 'Recorrió 27.9 km llevando cámaras, herramientas y muestras. Al terminar la misión, los astronautas lo estacionaron orientado hacia el Módulo Falcon para que su cámara controlada desde Houston filmara el despegue final.',
        en: 'Drove 27.9 km carrying tools and rock samples. Before departing, the crew parked it facing Falcon so Mission Control in Houston could film the final liftoff via remote camera.',
      },
      didactic: {
        es: 'Sus llantas no tenían aire ni goma (se habrían reventado o congelado): estaban tejidas con alambre de acero de piano galvanizado y placas de titanio.',
        en: 'Its wheels had no rubber or air (which would burst or freeze); they were woven from springy zinc-coated piano wire with titanium chevrons.',
      },
      desc: {
        es: 'Tres rovers LRV (Apolo 15, 16 y 17) permanecen estacionados hoy en diferentes regiones lunares como los únicos automóviles que han circulado fuera de la Tierra.',
        en: 'Three Apollo LRVs (15, 16, and 17) remain parked in silence across the Moon — the only automobiles ever driven on another world.',
      },
    },
    {
      id: 'footprints',
      name: { es: 'Huellas de Botas Lunares (Apolo)', en: 'Apollo Astronaut Bootprints' },
      shortLabel: { es: 'Huellas Apolo', en: 'Bootprints' },
      category: { es: 'Icnología humana en el regolito', en: 'Human Planetary Ichnology' },
      status: 'silent',
      statusNote: {
        es: 'Preservadas por más de 1,000,000 de años',
        en: 'Preserved for over 1,000,000 years',
      },
      behaviorState: 'static_heritage',
      missionYear: 1969,
      x: 1930,
      yRatio: 0.81,
      year: { es: '1969 – 1972 (Apolo 11 a 17)', en: '1969 – 1972 (Apollo 11–17)' },
      coords: { es: '6 sitios de alunizaje Apolo', en: 'All 6 Apollo landing sites' },
      crew: { es: '12 astronautas de la NASA', en: '12 NASA Astronauts' },
      prop: { es: 'Botas lunares de silicona con suela estriada', en: 'Molded silicone ribbed overshoes' },
      iconType: 'footprint',
      whySent: {
        es: 'Las suelas acanaladas brindaban tracción sobre el polvo lunar fino y resbaladizo (regolito), protegiendo los pies de rocas afiladas y temperaturas extremas.',
        en: 'The ribbed treads provided grip over slippery pulverized regolith while shielding boots from razor-sharp basalt and extreme temperatures.',
      },
      discoveries: {
        es: 'Al analizar en fotos la profundidad de las pisadas y las marcas de las ruedas del rover, los geólogos calcularon la densidad, cohesión y resistencia mecánica del suelo lunar para futuras bases humanas.',
        en: 'By measuring bootprint depth and rover tracks in photos, geologists calculated the bearing strength and density of lunar soil for future habitats.',
      },
      didactic: {
        es: 'Sin lluvia, viento ni ríos, las únicas cosas que borran lentamente una huella lunar son los impactos microscópicos de micrometeoritos espaciales.',
        en: 'Without wind, rain, or rivers, only microscopic micrometeorites slowly erode a lunar footprint over millions of years.',
      },
      desc: {
        es: 'Los granos de regolito son tan afilados y electrostáticos que se compactaron bajo las botas como yeso húmedo, conservando cada línea nítida.',
        en: 'Lunar regolith grains are jagged and electrostatically charged, compacting beneath boots like damp plaster to hold every crisp tread line.',
      },
    },
    {
      id: 'snap27',
      name: { es: 'Batería Atómica SNAP-27 (Estación ALSEP)', en: 'SNAP-27 Atomic Battery (ALSEP Station)' },
      shortLabel: { es: 'Batería SNAP-27', en: 'SNAP-27 RTG' },
      category: { es: 'Generador nuclear termoeléctrico', en: 'Radioisotope Thermoelectric Generator' },
      status: 'silent',
      statusNote: {
        es: 'Apagada por la NASA en 1977 tras 8 años continuos',
        en: 'Shut down by NASA in 1977 after 8 years',
      },
      behaviorState: 'static_heritage',
      missionYear: 1969,
      x: 2260,
      yRatio: 0.69,
      year: { es: 'Desplegada en 1969–1972 (Apolo 12–17)', en: 'Deployed 1969–1972 (Apollo 12–17)' },
      coords: { es: 'Estaciones científicas ALSEP', en: 'ALSEP Scientific Stations' },
      crew: { es: 'Ciencia Lunar Apolo NASA', en: 'NASA Apollo Lunar Science' },
      prop: { es: '15.2 kg · 3.8 kg de Plutonio-238 (73.5 W)', en: '15.2 kg · 3.8 kg Plutonium-238 (73.5 W)' },
      iconType: 'snap27',
      whySent: {
        es: 'Una noche lunar dura 14 días terrestres a -130 °C, apagando cualquier panel solar. La NASA necesitaba una fuente térmica nuclear compacta para mantener sismómetros y magnetómetros encendidos día y noche.',
        en: 'A lunar night lasts 14 Earth days at -130 °C, starving solar panels. NASA needed a compact nuclear heat source to power seismometers day and night.',
      },
      discoveries: {
        es: 'Alimentó la red sísmica lunar durante casi una década, detectando por primera vez "lunamotos" profundos, impactos de meteoritos y vibraciones que revelaron el tamaño del núcleo interno de la Luna.',
        en: 'Powered the lunar seismic network for nearly a decade, discovering deep moonquakes, meteoroid impacts, and the size of the Moon’s inner core.',
      },
      didactic: {
        es: 'Su combustible de Plutonio-238 sigue tibio hoy en día en la superficie lunar aunque las estaciones fueron desconectadas por presupuesto en 1977.',
        en: 'Its Plutonium-238 core still radiates gentle warmth on the Moon today, even though Mission Control turned off the stations in 1977.',
      },
      desc: {
        es: 'Cinco generadores SNAP-27 con aletas negras radiadoras permanecen instalados junto a cables dorados y estaciones científicas abandonadas.',
        en: 'Five finned SNAP-27 generators remain standing next to gold cables and silent ALSEP scientific instruments across the lunar near side.',
      },
    },
    {
      id: 'lrrr',
      name: { es: 'Retrorreflector Láser Lunar (LRRR)', en: 'Lunar Laser Ranging Retroreflector (LRRR)' },
      shortLabel: { es: 'Reflector Láser', en: 'Laser Reflector' },
      category: { es: 'Experimento óptico pasivo · Apolo 11, 14 y 15', en: 'Passive Optical Experiment · Apollo 11, 14, 15' },
      status: 'active',
      statusNote: {
        es: '¡ACTIVO HOY! Genera datos científicos desde 1969',
        en: 'ACTIVE TODAY! Generating science since 1969',
      },
      behaviorState: 'laser_bounce',
      missionYear: 1969,
      x: 2590,
      yRatio: 0.64,
      year: { es: 'Desplegados 1969–1971 · En uso actual', en: 'Deployed 1969–1971 · Still in Use' },
      coords: { es: 'Tranquilidad, Fra Mauro y Hadley', en: 'Tranquility, Fra Mauro & Hadley' },
      crew: { es: 'Equipos Apolo 11, 14 y 15', en: 'Apollo 11, 14 & 15 Crews' },
      prop: { es: 'Cero electricidad · 300 prismas de cuarzo', en: 'Zero electrical power · 300 quartz prisms' },
      iconType: 'lrrr',
      whySent: {
        es: 'Para medir la distancia exacta entre la Tierra y la Luna al milímetro, reflejando pulsos de láser disparados desde telescopios terrestres directamente de vuelta al punto de origen.',
        en: 'To measure the exact Earth-Moon distance down to the millimeter by bouncing laser beams from Earth observatories straight back to their source.',
      },
      discoveries: {
        es: '¡Es el experimento Apolo más longevo aún activo! Ha demostrado que la Luna se aleja de la Tierra 3.8 centímetros cada año por las mareas oceánicas y ha puesto a prueba la Relatividad General de Einstein.',
        en: 'The longest-running active Apollo experiment! It proved the Moon recedes from Earth by 3.8 cm every year due to ocean tides and tests Einstein’s General Relativity.',
      },
      didactic: {
        es: 'Como usa espejos prismáticos de esquina ("corner-cube") y no necesita baterías ni cables, ¡seguirá funcionando durante siglos!',
        en: 'Because it uses pure corner-cube quartz prisms with zero batteries or wires, it can keep working for centuries!',
      },
      desc: {
        es: 'De los millones de billones de fotones en cada disparo láser desde la Tierra, apenas unos pocos regresan tras viajar 768,000 km ida y vuelta, pero bastan para cronometrar la órbita lunar.',
        en: 'Out of quintillions of photons fired from Earth telescopes, only a handful return after the 768,000 km round trip — enough to time the Moon’s orbit precisely.',
      },
    },
    {
      id: 'uv_apollo16',
      name: { es: 'Cámara-Telescopio Ultravioleta (Apolo 16)', en: 'Far-UV Camera / Spectrograph (Apollo 16)' },
      shortLabel: { es: 'Telescopio Apolo 16', en: 'Apollo 16 Telescope' },
      category: { es: 'Primer observatorio astronómico lunar', en: 'First Astronomical Observatory on the Moon' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde 1972 · Su película volvió a la Tierra',
        en: 'Silent since 1972 · Film returned to Earth',
      },
      behaviorState: 'static_heritage',
      missionYear: 1972,
      x: 2920,
      yRatio: 0.72,
      year: { es: 'Abril de 1972 (Apolo 16)', en: 'April 1972 (Apollo 16)' },
      coords: { es: '8.973° S, 15.500° E (Tierras Altas de Descartes)', en: '8.973° S, 15.500° E (Descartes Highlands)' },
      crew: { es: 'John Young y Charles Duke', en: 'John Young & Charles Duke' },
      prop: { es: 'Telescopio Schmidt bañado en oro · 22 kg', en: 'Gold-plated Schmidt telescope · 22 kg' },
      iconType: 'uv_camera',
      whySent: {
        es: 'La atmósfera terrestre bloquea casi toda la luz ultravioleta del universo. El Dr. George Carruthers diseñó este telescopio dorado para usar la Luna como observatorio libre de aire y contaminación lumínica.',
        en: 'Earth’s atmosphere blocks most ultraviolet light from space. Dr. George Carruthers built this gold-plated telescope to turn the airless Moon into a deep-space observatory.',
      },
      discoveries: {
        es: 'Tomó 178 fotografías históricas en ultravioleta lejano de la geocorona de hidrógeno que rodea la Tierra, nebulosas estelares y galaxias cercanas, inaugurando la astronomía desde otro cuerpo celeste.',
        en: 'Captured 178 historic far-UV images of Earth’s glowing hydrogen geocorona, star-forming nebulae, and galaxies — founding lunar astronomy.',
      },
      didactic: {
        es: 'John Young estacionó el telescopio a la sombra del Módulo Lunar Orion para proteger la película fotográfica del calor solar mientras Charlie Duke lo apuntaba manualmente.',
        en: 'John Young parked the telescope in the shadow of Lunar Module Orion to keep its film cool while Charlie Duke aimed it by hand.',
      },
      desc: {
        es: 'Los astronautas extrajeron solo el cartucho de película antes de partir; el cuerpo dorado del primer telescopio lunar de la historia sigue montado en su trípode en Descartes.',
        en: 'Astronauts retrieved only the film canister before liftoff; the gold barrel of humanity’s first lunar telescope still stands on its tripod at Descartes.',
      },
    },
    {
      id: 'fallen',
      name: { es: "Memorial 'Astronauta Caído' (Apolo 15)", en: "'Fallen Astronaut' Memorial (Apollo 15)" },
      shortLabel: { es: 'Astronauta Caído', en: 'Fallen Astronaut' },
      category: { es: 'Homenaje humanitario en el espacio', en: 'Humanitarian Lunar Memorial' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde 1971 · Única obra de arte en la Luna',
        en: 'Silent since 1971 · Only artwork on the Moon',
      },
      behaviorState: 'static_heritage',
      missionYear: 1971,
      x: 3240,
      yRatio: 0.78,
      year: { es: '1 de agosto de 1971', en: 'August 1, 1971' },
      coords: { es: 'Llanura de Hadley-Apeninos', en: 'Hadley-Apennine Plain' },
      crew: { es: 'Colocado por David Scott', en: 'Placed by David Scott' },
      prop: { es: 'Escultura de aluminio de 8.5 cm y placa', en: '8.5 cm aluminum figurine & plaque' },
      iconType: 'fallen_astronaut',
      whySent: {
        es: 'Para honrar la memoria de los 14 astronautas estadounidenses y cosmonautas que perdieron la vida impulsando la exploración espacial humana hasta 1971.',
        en: 'To honor the 14 American astronauts and cosmonauts who lost their lives advancing human spaceflight up to 1971.',
      },
      discoveries: {
        es: 'Demostró que la exploración espacial trasciende fronteras: la pequeña figura estilizada no representa ninguna nacionalidad ni género, sino a toda la humanidad mirando hacia el cosmos.',
        en: 'Symbolizes that space exploration belongs to all humanity: the minimalist figure wears no flag or insignia, representing everyone who looks toward the stars.',
      },
      didactic: {
        es: 'El artista belga Paul Van Hoeydonck tuvo que tallar la figurilla en aluminio anodizado para que resistiera los extremos térmicos de la Luna sin agrietarse.',
        en: 'Belgian artist Paul Van Hoeydonck crafted the statuette out of aluminum so it would survive extreme lunar temperature swings without cracking.',
      },
      desc: {
        es: 'Descansa inclinada suavemente dentro de un pequeño cráter junto a la placa metálica vertical con los 14 nombres grabados.',
        en: 'It rests gently in the lunar dust inside a small crater beside a vertical metal plaque engraved with all 14 names.',
      },
    },
    {
      id: 'apollo17_lrv',
      name: { es: 'Rover Apolo 17 y Suelo Naranja', en: 'Apollo 17 Rover & Orange Glass Soil' },
      shortLabel: { es: 'Apolo 17 LRV-3', en: 'Apollo 17 LRV-3' },
      category: { es: 'Última misión humana lunar (hasta Artemis)', en: 'Final Apollo Crewed Mission' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde diciembre 1972 · Récord de 35.9 km',
        en: 'Silent since December 1972 · 35.9 km record',
      },
      behaviorState: 'static_heritage',
      missionYear: 1972,
      x: 3560,
      yRatio: 0.68,
      year: { es: '11–14 de diciembre de 1972', en: 'December 11–14, 1972' },
      coords: { es: '20.191° N, 30.772° E (Valle Taurus-Littrow)', en: '20.191° N, 30.772° E (Taurus-Littrow Valley)' },
      crew: { es: 'Eugene Cernan y Harrison Schmitt', en: 'Eugene Cernan & Harrison Schmitt' },
      prop: { es: 'LRV-3 · 110.5 kg de muestras recolectadas', en: 'LRV-3 · 110.5 kg samples collected' },
      iconType: 'lrv_rover',
      whySent: {
        es: 'Apolo 17 llevó por primera vez a un geólogo profesional (Harrison Schmitt) al valle Taurus-Littrow para estudiar volcanismo reciente y recoger la mayor variedad de rocas lunares.',
        en: 'Apollo 17 flew the first professional geologist (Harrison Schmitt) to Taurus-Littrow Valley to hunt young volcanic deposits and ancient highland crust.',
      },
      discoveries: {
        es: 'En el cráter Shorty, Schmitt gritó "¡Hay suelo naranja!" — diminutas perlas de vidrio volcánico expulsadas por fuentes de lava hace 3,600 millones de años, clave para descubrir agua atrapada en el manto lunar.',
        en: 'At Shorty Crater, Schmitt shouted "There is orange soil!" — microscopic volcanic glass beads erupted 3.6 billion years ago that later revealed water inside the Moon’s mantle.',
      },
      didactic: {
        es: 'Cuando un guardabarros del rover se rompió, Gene Cernan y el equipo de Houston lo repararon usando mapas plastificados y cinta plateada ¡duct tape!',
        en: 'When a rover fender broke off, Gene Cernan and Houston engineers famously repaired it using laminated lunar maps and silver duct tape!',
      },
      desc: {
        es: 'El LRV-3 y la etapa Challenger permanecen como el último campamento humano en la Luna hasta el regreso del programa Artemis de la NASA.',
        en: 'LRV-3 and the Challenger descent stage remain humanity’s most recent lunar camp until NASA’s Artemis crews return.',
      },
    },
  ],
  mars: [
    {
      id: 'perseverance',
      name: { es: 'Rover Perseverance (Mars 2020)', en: 'Perseverance Rover (Mars 2020)' },
      shortLabel: { es: 'Perseverance', en: 'Perseverance' },
      category: { es: 'Buscador de vida antigua · Cráter Jezero', en: 'Ancient Life Seeker · Jezero Crater' },
      status: 'active',
      statusNote: {
        es: '¡ACTIVO HOY! Explorando el borde del cráter Jezero',
        en: 'ACTIVE TODAY! Exploring Jezero Crater rim',
      },
      behaviorState: 'patrol_active',
      missionYear: 2021,
      x: 300,
      yRatio: 0.72,
      year: { es: 'Aterrizaje: 18 de febrero de 2021', en: 'Landing: February 18, 2021' },
      coords: { es: '18.445° N, 77.451° E (Cráter Jezero)', en: '18.445° N, 77.451° E (Jezero Crater)' },
      crew: { es: 'NASA Jet Propulsion Laboratory (JPL)', en: 'NASA Jet Propulsion Laboratory (JPL)' },
      prop: { es: '1,025 kg · Batería nuclear MMRTG', en: '1,025 kg · MMRTG Nuclear Power' },
      iconType: 'rover_curiosity',
      whySent: {
        es: 'Fue enviado a un antiguo lago y delta fluvial marciano para buscar signos microscópicos de vida pasada y sellar rocas selectas en tubos de titanio para traerlos a la Tierra.',
        en: 'Sent to an ancient Martian lake and river delta to search for microscopic signs of past life and seal pristine rock cores in titanium tubes for Earth return.',
      },
      discoveries: {
        es: 'Su experimento MOXIE fabricó oxígeno puro directamente del aire tóxico de Marte, preparando el camino para futuros astronautas. Además lleva micrófonos que grabaron por primera vez el sonido del viento marciano.',
        en: 'Its MOXIE instrument produced breathable oxygen directly from Mars’s CO₂ air for future astronauts, and its microphones recorded the first true sounds of Martian wind.',
      },
      didactic: {
        es: 'Lleva un pequeño chip con los nombres de 10.9 millones de personas de todo el mundo y una muestra de tela de traje espacial para probar su resistencia en Marte.',
        en: 'It carries a silicon chip etched with 10.9 million names from Earth plus a swatch of spacesuit fabric to test radiation durability.',
      },
      desc: {
        es: 'Equipado con 23 cámaras, láseres espectroscópicos y un taladro percutor, Perseverance continúa activo escalando rocas de hace más de 3,800 millones de años.',
        en: 'Equipped with 23 cameras, rock-zapping lasers, and a rotary coring drill, Perseverance remains active climbing 3.8-billion-year-old crater rims.',
      },
    },
    {
      id: 'ingenuity',
      name: { es: 'Helicóptero Marciano Ingenuity', en: 'Ingenuity Mars Helicopter' },
      shortLabel: { es: 'Ingenuity', en: 'Ingenuity' },
      category: { es: 'Primera aeronave en otro planeta', en: 'First Aircraft on Another Planet' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso en Valinor Hills (Misión finalizada en 2024 tras 72 vuelos)',
        en: 'Silent at Valinor Hills (Retired 2024 after 72 flights)',
      },
      behaviorState: 'damaged_rotor_wind',
      missionYear: 2021,
      x: 640,
      yRatio: 0.59,
      year: { es: '2021 – 2024 (72 vuelos)', en: '2021 – 2024 (72 Flights)' },
      coords: { es: 'Campo Wright Brothers → Valinor Hills', en: 'Wright Brothers Field → Valinor Hills' },
      crew: { es: 'NASA JPL & Ames', en: 'NASA JPL & Ames' },
      prop: { es: '1.8 kg · Panel solar + rotores a 2,500 RPM', en: '1.8 kg · Solar panel + 2,500 RPM rotors' },
      iconType: 'helicopter',
      whySent: {
        es: 'Viajó escondido bajo el vientre de Perseverance solo para probar si era posible volar en la atmósfera marciana, 100 veces más delgada que la de la Tierra.',
        en: 'Hitcheda ride under Perseverance’s belly solely to test whether powered flight was even possible in Mars’s ultra-thin air (1% of Earth’s density).',
      },
      discoveries: {
        es: 'Planeado para solo 5 vuelos de prueba, voló ¡72 veces! recorriendo 17 kilómetros y convirtiéndose en el explorador aéreo de Perseverance hasta que una pala de carbono se dañó en un aterrizaje sobre arena.',
        en: 'Planned for just 5 test hops, it flew 72 times across 17 kilometers, serving as Perseverance’s aerial scout until a rotor blade chipped during a sandy landing.',
      },
      didactic: {
        es: 'Llevaba pegado bajo su panel solar un trocito de tela del ala del avión original de los hermanos Wright de 1903.',
        en: 'Tucked under its solar panel is a postage-stamp-sized swatch of fabric from the Wright brothers’ original 1903 Flyer.',
      },
      desc: {
        es: 'Ahora descansa silencioso como estación meteorológica fija en las dunas de Valinor Hills, marcando el nacimiento de la aviación extraterrestre.',
        en: 'Now resting silently in the dunes of Valinor Hills, it marks the historic birthplace of extraterrestrial aviation.',
      },
    },
    {
      id: 'curiosity',
      name: { es: 'Rover Curiosity (MSL)', en: 'Curiosity Rover (MSL)' },
      shortLabel: { es: 'Curiosity', en: 'Curiosity' },
      category: { es: 'Laboratorio químico móvil · Monte Sharp', en: 'Mobile Chemistry Lab · Mount Sharp' },
      status: 'active',
      statusNote: {
        es: '¡ACTIVO HOY! Más de 14 años trabajando en el cráter Gale',
        en: 'ACTIVE TODAY! Over 14 years working in Gale Crater',
      },
      behaviorState: 'slow_worn_drive',
      missionYear: 2012,
      x: 990,
      yRatio: 0.74,
      year: { es: 'Aterrizaje: 6 de agosto de 2012', en: 'Landing: August 6, 2012' },
      coords: { es: '4.589° S, 137.442° E (Cráter Gale)', en: '4.589° S, 137.442° E (Gale Crater)' },
      crew: { es: 'NASA JPL', en: 'NASA JPL' },
      prop: { es: '899 kg · Generador Plutonio-238 RTG', en: '899 kg · Plutonium-238 RTG' },
      iconType: 'rover_curiosity',
      whySent: {
        es: 'Para responder una pregunta clave: ¿Tuvo Marte alguna vez ingredientes químicos, agua dulce y energía suficientes para sostener vida microbiana?',
        en: 'To answer one core question: Did ancient Mars ever possess the water, chemistry, and energy needed to support microbial life?',
      },
      discoveries: {
        es: '¡Sí! En sus primeros meses halló un antiguo lecho fluvial y minerales de arcilla formados en agua neutra potable, además de moléculas orgánicas complejas preservadas en rocas de hace 3,500 millones de años.',
        en: 'Yes! Within months it discovered an ancient streambed and clay minerals formed in drinkable neutral water, plus complex organic carbon molecules in 3.5-billion-year-old mudstone.',
      },
      didactic: {
        es: 'En el aniversario de su primer año en Marte, sus ingenieros programaron su instrumento químico SAM para vibrar tocando la melodía de "Cumpleaños Feliz" en el silencio marciano.',
        en: 'On its first Martian anniversary, engineers programmed its SAM chemistry instrument to vibrate the tune of "Happy Birthday" across the silent crater.',
      },
      desc: {
        es: 'Aunque sus ruedas de aluminio muestran perforaciones tras recorrer más de 32 km sobre rocas afiladas, Curiosity sigue subiendo incansable las laderas del Monte Sharp.',
        en: 'Even with dented aluminum wheels after driving over 32 km across razor-sharp rocks, Curiosity continues climbing Mount Sharp today.',
      },
    },
    {
      id: 'insight',
      name: { es: 'Aterrizador InSight y Sismómetro SEIS', en: 'InSight Lander & SEIS Seismometer' },
      shortLabel: { es: 'InSight', en: 'InSight' },
      category: { es: 'Estación geofísica · El pulso de Marte', en: 'Geophysical Station · Mars Pulse' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde diciembre 2022 · Cubierto de polvo marciano',
        en: 'Silent since December 2022 · Covered by dust',
      },
      behaviorState: 'seismic_station',
      missionYear: 2018,
      x: 1340,
      yRatio: 0.68,
      year: { es: '2018 – 2022 (Elysium Planitia)', en: '2018 – 2022 (Elysium Planitia)' },
      coords: { es: '4.502° N, 135.623° E (Elysium Planitia)', en: '4.502° N, 135.623° E (Elysium Planitia)' },
      crew: { es: 'NASA JPL', en: 'NASA JPL' },
      prop: { es: '358 kg · Paneles solares circulares', en: '358 kg · Twin circular solar arrays' },
      iconType: 'insight',
      whySent: {
        es: 'A diferencia de los rovers que estudian la superficie, InSight se quedó quieta en un solo punto para tomarle el "pulso" sísmico y medir el interior profundo de Marte por primera vez.',
        en: 'Unlike rovers studying surface rocks, InSight stayed motionless to take Mars’s seismic "pulse" and map its deep interior for the first time.',
      },
      discoveries: {
        es: 'Detectó más de 1,300 "martemotos" (incluido uno de magnitud 4.7 en 2022) e impactos de meteoritos, revelando que Marte posee un núcleo líquido de hierro más grande y menos denso de lo que se creía.',
        en: 'Recorded over 1,300 marsquakes (including a magnitude 4.7 quake in 2022) and meteor strikes, revealing Mars has a larger liquid iron core than previously thought.',
      },
      didactic: {
        es: 'Su último mensaje antes de quedarse sin batería por el polvo fue: "Mi energía está muy baja, así que esta podría ser la última imagen que envíe. No se preocupen por mí: mi tiempo aquí ha sido productivo y sereno".',
        en: 'Its final message before dust choked its solar panels read: "My power’s really low, so this may be the last image I can send. Don’t worry about me: my time here has been both productive and serene."',
      },
      desc: {
        es: 'Su brazo robótico dejó el sismómetro SEIS protegido bajo un domo blanco-dorado directamente sobre el suelo rojo de Elysium Planitia.',
        en: 'Its robotic arm placed the dome-shielded SEIS seismometer directly onto the red regolith of Elysium Planitia, where both sit quietly.',
      },
    },
    {
      id: 'opportunity',
      name: { es: 'Rover Opportunity (MER-B)', en: 'Opportunity Rover (MER-B)' },
      shortLabel: { es: 'Opportunity', en: 'Opportunity' },
      category: { es: 'Héroe maratonista · 14 años en Marte', en: 'Marathon Hero · 14 Years on Mars' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde junio 2018 · Valle de la Perseverancia',
        en: 'Silent since June 2018 · Perseverance Valley',
      },
      behaviorState: 'dust_hibernation',
      missionYear: 2004,
      x: 1690,
      yRatio: 0.64,
      year: { es: '2004 – 2018 (5,111 soles)', en: '2004 – 2018 (5,111 Sols)' },
      coords: { es: '1.948° S, 354.474° E (Meridiani Planum)', en: '1.948° S, 354.474° E (Meridiani Planum)' },
      crew: { es: 'NASA JPL', en: 'NASA JPL' },
      prop: { es: '185 kg · Paneles solares', en: '185 kg · Solar arrays' },
      iconType: 'rover_mer',
      whySent: {
        es: 'Construido para durar solo 90 días marcianos buscando evidencia de rocas formadas bajo agua líquida en el pasado de Marte.',
        en: 'Built for just a 90-sol mission to hunt for mineral evidence of ancient liquid water on the Martian plains.',
      },
      discoveries: {
        es: '¡Sobrevivió 55 veces más de lo previsto (14 años)! Halló esférulas de hematita llamadas "arándanos" y vetas de yeso formadas por agua subterránea, batiendo el récord de conducción extraterrestre con 45.16 km.',
        en: 'Lasted 55 times longer than planned (14 years)! Discovered hematite "blueberries" and gypsum veins left by ancient groundwater, setting an off-world driving record of 45.16 km.',
      },
      didactic: {
        es: 'Una tormenta de polvo global que oscureció el cielo durante meses silenció al rover en 2018 tras su poética última transmisión: "Mi batería está baja y está oscureciendo".',
        en: 'A planet-encircling dust storm blocked the Sun in 2018, ending Opportunity’s mission after its poignant last telemetry: "My battery is low and it’s getting dark."',
      },
      desc: {
        es: 'Descansa en el borde del cráter Endeavour como uno de los robots más queridos y exitosos de la historia espacial.',
        en: 'Rests on the rim of Endeavour Crater as one of the most beloved and resilient robotic explorers ever built.',
      },
    },
    {
      id: 'spirit',
      name: { es: 'Rover Spirit (MER-A)', en: 'Spirit Rover (MER-A)' },
      shortLabel: { es: 'Spirit', en: 'Spirit' },
      category: { es: 'Gemelo explorador · Cráter Gusev', en: 'Twin Explorer · Gusev Crater' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde 2010 · Atrapado en arena blanda',
        en: 'Silent since 2010 · Embedded in soft sand',
      },
      behaviorState: 'stuck_in_sand',
      missionYear: 2004,
      x: 2040,
      yRatio: 0.76,
      year: { es: '2004 – 2010 (2,208 soles)', en: '2004 – 2010 (2,208 Sols)' },
      coords: { es: '14.568° S, 175.473° E (Cráter Gusev)', en: '14.568° S, 175.473° E (Gale/Gusev Crater)' },
      crew: { es: 'NASA JPL', en: 'NASA JPL' },
      prop: { es: '185 kg · Paneles solares', en: '185 kg · Solar arrays' },
      iconType: 'rover_mer',
      whySent: {
        es: 'Hermano gemelo de Opportunity, enviado al otro lado de Marte para escalar las Colinas Columbia y estudiar si el cráter Gusev fue un antiguo lago.',
        en: 'Twin to Opportunity, sent to the opposite hemisphere of Mars to climb the Columbia Hills and test whether Gusev Crater once held a lake.',
      },
      discoveries: {
        es: 'Incluso cuando su rueda delantera derecha se atascó en 2006 y tuvo que arrastrarla, esa rueda excavó accidentalmente una franja brillante de sílice casi pura: prueba de antiguos manantiales termales ideales para la vida.',
        en: 'Even after its front wheel jammed in 2006, dragging that broken wheel accidentally scraped open bright nearly-pure silica — proof of ancient hot springs!',
      },
      didactic: {
        es: 'En 2009 sus ruedas rompieron una costra dura y se hundieron en arena blanda; incapaz de inclinar sus paneles hacia el sol invernal, Spirit se durmió en paz en 2010.',
        en: 'In 2009 its wheels broke through a crust into soft sand; unable to tilt toward the winter Sun, Spirit quietly entered eternal hibernation in 2010.',
      },
      desc: {
        es: 'Permanece mirando hacia el norte en el sitio llamado Troy, al oeste de la meseta Home Plate.',
        en: 'It remains parked facing north at "Troy" on the edge of the Home Plate plateau.',
      },
    },
    {
      id: 'phoenix',
      name: { es: 'Aterrizador Polar Phoenix', en: 'Phoenix Mars Polar Lander' },
      shortLabel: { es: 'Phoenix', en: 'Phoenix' },
      category: { es: 'Excavador de hielo ártico marciano', en: 'Martian Arctic Ice Excavator' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde noviembre 2008 · Congelado en invierno polar',
        en: 'Silent since November 2008 · Frozen in polar winter',
      },
      behaviorState: 'polar_frost',
      missionYear: 2008,
      x: 2390,
      yRatio: 0.65,
      year: { es: 'Mayo – Noviembre de 2008', en: 'May – November 2008' },
      coords: { es: '68.219° N, 234.251° E (Vastitas Borealis)', en: '68.219° N, 234.251° E (Vastitas Borealis)' },
      crew: { es: 'NASA JPL / Univ. de Arizona', en: 'NASA JPL / Univ. of Arizona' },
      prop: { es: '350 kg · Brazo excavador de 2.35 m', en: '350 kg · 2.35 m digging arm' },
      iconType: 'phoenix',
      whySent: {
        es: 'Los orbitadores detectaron hidrógeno bajo el polo norte de Marte. Phoenix fue enviada a excavar directamente ese suelo helado para verificar si realmente era agua congelada.',
        en: 'Orbiters sensed underground hydrogen near Mars’s north pole. Phoenix was sent to dig straight into the frozen soil to taste and verify real water ice.',
      },
      discoveries: {
        es: '¡Confirmado! A pocos centímetros bajo el polvo rojo, su pala raspó hielo de agua blanca y pura que se evaporó en cuatro días. También observó caer nieve desde nubes marcianas antes de que llegara la noche polar.',
        en: 'Confirmed! Just centimeters below the red dust, its scoop uncovered bright white water ice that sublimated in four days. It even saw snow falling from Martian clouds!',
      },
      didactic: {
        es: 'Al llegar el invierno polar (-125 °C), capas de hielo seco de CO₂ se acumularon encima de Phoenix fracturando sus paneles solares como vidrio.',
        en: 'When polar winter hit (-125 °C), thick dry ice snow buried Phoenix and snapped its solar wings.',
      },
      desc: {
        es: 'Hoy reposa en las llanuras árticas marcianas junto a las pequeñas zanjas "Dodo-Ricitos de Oro" donde tocó por primera vez hielo de otro planeta.',
        en: 'It rests on the Martian arctic plains beside the "Dodo-Goldilocks" trenches where humanity first touched water ice on Mars.',
      },
    },
    {
      id: 'olympus',
      name: { es: 'Volcán Olympus Mons (Mariner 9)', en: 'Olympus Mons Volcano (Mariner 9)' },
      shortLabel: { es: 'Olympus Mons', en: 'Olympus Mons' },
      category: { es: 'Geología planetaria · Cartografía NASA', en: 'Planetary Geology · NASA Survey' },
      status: 'silent',
      statusNote: {
        es: 'Cartografiado por Mariner 9 (1971) — aún en órbita silenciosa',
        en: 'Mapped by Mariner 9 (1971) — still orbiting silently',
      },
      behaviorState: 'static_heritage',
      missionYear: 1971,
      x: 2740,
      yRatio: 0.56,
      year: { es: 'Descubierto por Mariner 9 (1971)', en: 'Surveyed by Mariner 9 (1971)' },
      coords: { es: '18.65° N, 226.2° E (Meseta de Tharsis)', en: '18.65° N, 226.2° E (Tharsis Rise)' },
      crew: { es: 'NASA JPL · Mariner 9', en: 'NASA JPL · Mariner 9' },
      prop: { es: 'Altura: 21.9 km (2.5x Everest) · Ancho: 600 km', en: 'Height: 21.9 km (2.5x Everest) · Width: 600 km' },
      iconType: 'volcano',
      whySent: {
        es: 'Mariner 9 fue la primera nave en orbitar otro planeta. Cuando llegó en 1971 una tormenta de polvo tapaba todo Marte… excepto cuatro picos volcánicos sobresaliendo como islas.',
        en: 'Mariner 9 became the first spacecraft to orbit another planet. Upon arriving in 1971, a global dust storm hid all of Mars — except four giant volcano peaks poking above the dust!',
      },
      discoveries: {
        es: 'Reveló que el punto brillante conocido por telescopios como "Nix Olympica" era en realidad el volcán más colosal del Sistema Solar: casi tres veces más alto que el Monte Everest.',
        en: 'Revealed that a bright spot seen through telescopes was actually the Solar System’s largest volcano — nearly three times taller than Mount Everest.',
      },
      didactic: {
        es: 'La nave Mariner 9 de la NASA completó su misión en 1972 y sigue dando vueltas silenciosas alrededor de Marte en una órbita estable.',
        en: 'NASA’s Mariner 9 finished its mission in 1972 and still orbits Mars silently in a stable path today.',
      },
      desc: {
        es: 'Al carecer Marte de placas tectónicas móviles, la lava brotó por el mismo lugar durante cientos de millones de años creando una montaña tan ancha como España o Arizona.',
        en: 'Because Mars lacks moving tectonic plates, lava piled up over the same hotspot for hundreds of millions of years.',
      },
    },
    {
      id: 'pathfinder',
      name: { es: 'Mars Pathfinder y Rover Sojourner', en: 'Mars Pathfinder & Sojourner Rover' },
      shortLabel: { es: 'Pathfinder', en: 'Pathfinder' },
      category: { es: 'Primer rover de la historia en Marte', en: 'First Rover Ever on Mars' },
      status: 'silent',
      statusNote: {
        es: 'Silenciosos desde septiembre 1997 · Ares Vallis',
        en: 'Silent since September 1997 · Ares Vallis',
      },
      behaviorState: 'static_heritage',
      missionYear: 1997,
      x: 3090,
      yRatio: 0.77,
      year: { es: 'Aterrizaje: 4 de julio de 1997', en: 'Landing: July 4, 1997' },
      coords: { es: '19.33° N, 33.55° W (Ares Vallis)', en: '19.33° N, 33.55° W (Ares Vallis)' },
      crew: { es: 'NASA JPL', en: 'NASA JPL' },
      prop: { es: 'Estación: 360 kg / Sojourner: 10.6 kg', en: 'Station: 360 kg / Sojourner: 10.6 kg' },
      iconType: 'pathfinder',
      whySent: {
        es: 'Para demostrar una forma económica de aterrizar con bolsas de aire gigantes que rebotaron 15 veces y probar por primera vez un carrito robótico móvil fuera de la Tierra.',
        en: 'To prove a low-cost airbag bounce landing (bouncing 15 times!) and test the first free-roaming robotic rover on another planet.',
      },
      discoveries: {
        es: 'El pequeño Sojourner (del tamaño de un horno microondas) rodó 100 metros analizando rocas redondeadas como "Barnacle Bill" y "Yogi", confirmando antiguas inundaciones catastróficas.',
        en: 'Microwave-sized Sojourner drove 100 meters analyzing rocks nicknamed "Barnacle Bill" and "Yogi", confirming ancient catastrophic floods.',
      },
      didactic: {
        es: 'El aterrizador fue rebautizado Estación Conmemorativa Carl Sagan, y bautizó a las rocas cercanas con nombres de dibujos animados como "Yogi", "Scooby-Doo" y "Casper".',
        en: 'Renamed the Carl Sagan Memorial Station, its team nicknamed nearby boulders after cartoon characters like "Yogi", "Scooby-Doo", and "Casper".',
      },
      desc: {
        es: 'Sojourner quedó estacionado en silencio a pocos metros de los pétalos solares abiertos de la estación tras transmitir más de 16,500 imágenes.',
        en: 'Sojourner parked silently a few meters from the open solar petals of its lander after sending back over 16,500 images.',
      },
    },
    {
      id: 'viking1',
      name: { es: 'Aterrizador Viking 1 (Estación Mutch)', en: 'Viking 1 Lander (Thomas Mutch Station)' },
      shortLabel: { es: 'Viking 1', en: 'Viking 1' },
      category: { es: 'Primer aterrizador operativo en Marte', en: 'First Operational Mars Lander' },
      status: 'silent',
      statusNote: {
        es: 'Silencioso desde noviembre 1982 · 6 años activo',
        en: 'Silent since November 1982 · Active 6 years',
      },
      behaviorState: 'misaligned_antenna',
      missionYear: 1976,
      x: 3440,
      yRatio: 0.67,
      year: { es: 'Aterrizaje: 20 de julio de 1976', en: 'Landing: July 20, 1976' },
      coords: { es: '22.697° N, 48.222° W (Chryse Planitia)', en: '22.697° N, 48.222° W (Chryse Planitia)' },
      crew: { es: 'NASA Langley / JPL', en: 'NASA Langley / JPL' },
      prop: { es: '572 kg · Generadores nucleares SNAP-19', en: '572 kg · SNAP-19 RTG power' },
      iconType: 'viking',
      whySent: {
        es: 'Para lograr el primer aterrizaje suave totalmente exitoso en Marte, enviar las primeras fotografías desde el suelo y buscar señales químicas de vida microbiana.',
        en: 'To achieve the first fully successful soft landing on Mars, transmit the first ground-level photos, and test Martian soil for microscopic life.',
      },
      discoveries: {
        es: 'Reveló por primera vez que el cielo de Marte es color caramelo-salmón (y no azul) y que las rocas oscuras están cubiertas de polvo de óxido de hierro. Operó durante más de 6 años como estación climática.',
        en: 'Showed humanity for the first time that Mars’s sky is butterscotch-pink and covered in iron-oxide dust, operating for over 6 years as a weather station.',
      },
      didactic: {
        es: 'Viking 1 tocó Marte exactamente el 20 de julio de 1976: ¡el séptimo aniversario del alunizaje del Apolo 11!',
        en: 'Viking 1 touched down on July 20, 1976 — the exact 7th anniversary of the Apollo 11 Moon landing!',
      },
      desc: {
        es: 'Un error en un comando de software desde la Tierra en 1982 desconectó por accidente la antena de Viking 1; su brazo excavador y sus tres patas siguen intactos en Chryse Planitia.',
        en: 'An accidental software command from Earth in 1982 pointed its antenna away, leaving Viking 1’s robotic scoop and legs resting in Chryse Planitia.',
      },
    },
  ],
};

export const NASA_ENCYCLOPEDIA_ARTICLES: Record<Exclude<EncyclopediaTabId, 'quiz'>, EncyclopediaArticle[]> = {
  apollo: [
    {
      id: 'abandoned_moon_inventory',
      tag: { es: 'Inventario histórico · La Luna', en: 'Heritage Inventory · The Moon' },
      title: {
        es: 'Abandonados pero no olvidados: ¿Qué dejó exactamente la NASA en la Luna?',
        en: 'Abandoned, Not Forgotten: What Exactly Did NASA Leave on the Moon?',
      },
      text: {
        es: 'Para ahorrar combustible y traer rocas lunares de regreso, los astronautas de las misiones Apolo 11 a 17 dejaron atrás todo lo que ya no necesitaban para el viaje de vuelta. Hoy, más de 180 toneladas de hardware NASA descansan intactas en seis sitios lunares.',
        en: 'To save precious fuel for the return trip with Moon rocks, Apollo 11–17 astronauts left behind everything they no longer needed. Today, over 180 tons of NASA hardware remain intact across six lunar sites.',
      },
      table: [
        [
          { es: 'Vehículos mayores', en: 'Major Vehicles' },
          { es: '6 etapas de descenso lunares (Eagle, Intrepid, Antares, Falcon, Orion, Challenger) y 3 Rovers LRV', en: '6 Lunar Module descent stages and 3 electric Lunar Roving Vehicles (LRVs)' },
        ],
        [
          { es: 'Equipo aún activo', en: 'Still Active Today' },
          { es: '3 Retrorreflectores Láser (Apolo 11, 14 y 15) reflejando haces desde la Tierra', en: '3 Laser Retroreflectors (Apollo 11, 14, 15) still bouncing Earth laser beams' },
        ],
        [
          { es: 'Objetos humanos y ciencia', en: 'Human & Science Gear' },
          { es: '6 banderas, 12 pares de botas lunares, cámaras Hasselblad (sin rollo), 2 pelotas de golf y la escultura "Astronauta Caído"', en: '6 flags, 12 pairs of Moon overshoes, Hasselblad camera bodies, 2 golf balls, and the Fallen Astronaut statue' },
        ],
      ],
    },
    {
      id: 'apollo11',
      tag: { es: 'Alunizaje tripulado · Apolo 11', en: 'Crewed Touchdown · Apollo 11' },
      title: {
        es: 'Apolo 11: "El Águila ha alunizado" — Base Tranquilidad',
        en: 'Apollo 11: "The Eagle Has Landed" — Tranquility Base',
      },
      text: {
        es: 'El 20 de julio de 1969, Neil Armstrong y Buzz Aldrin alunizaron en el Módulo Eagle mientras Michael Collins orbitaba en Columbia. Más de 650 millones de personas vieron en vivo el primer paso humano en otro mundo.',
        en: 'On July 20, 1969, Neil Armstrong and Buzz Aldrin touched down in Eagle while Michael Collins orbited in Columbia, watched live by over 650 million people.',
      },
      table: [
        [
          { es: 'Alarmas 1202 y 1201', en: '1202 & 1201 Alarms' },
          { es: 'El software de Margaret Hamilton priorizó los propulsores y descartó tareas secundarias del radar.', en: 'Margaret Hamilton’s priority software kept descent thrusters online during radar overload.' },
        ],
        [
          { es: 'Cosecha científica', en: 'Scientific Harvest' },
          { es: '21.55 kg de rocas basálticas, sismómetro PSEP y retrorreflector láser EASEP.', en: '21.55 kg of lunar basalt, PSEP seismometer, and EASEP laser retroreflector.' },
        ],
      ],
    },
    {
      id: 'saturnv',
      tag: { es: 'Cohete legendario · NASA', en: 'Legendary Rocket · NASA' },
      title: {
        es: 'Saturno V: El gigante que llevó los módulos y rovers a la Luna',
        en: 'Saturn V: The Giant Rocket That Carried Hardware to the Moon',
      },
      text: {
        es: 'Con 110.6 metros de altura y 2,900 toneladas de peso, el Saturno V del Centro Marshall de la NASA sigue siendo el cohete tripulado que ha lanzado más carga útil hacia otro mundo.',
        en: 'Standing 110.6 meters tall and weighing 2,900 metric tons, NASA’s Saturn V remains the only launch vehicle to carry humans beyond low Earth orbit.',
      },
      table: [
        [
          { es: 'Etapa 1 (S-IC)', en: 'Stage 1 (S-IC)' },
          { es: '5 motores F-1 (34.5 MN de empuje) · Cayó al Océano Atlántico', en: '5 F-1 engines (34.5 MN thrust) · Expended into Atlantic Ocean' },
        ],
        [
          { es: 'Etapa 3 (S-IVB)', en: 'Stage 3 (S-IVB)' },
          { es: 'Varias etapas S-IVB fueron estrelladas intencionalmente en la Luna para provocar "lunamotos" medidos por ALSEP', en: 'Several S-IVB stages were intentionally crashed into the Moon to trigger seismic waves for ALSEP!' },
        ],
      ],
    },
  ],
  mars: [
    {
      id: 'mars_active_vs_silent',
      tag: { es: 'Estado operativo · NASA JPL', en: 'Operational Status · NASA JPL' },
      title: {
        es: 'Activos vs. Silenciosos: La historia de los robots dejados en Marte',
        en: 'Active vs. Silent: The Story of NASA’s Left-Behind Robots on Mars',
      },
      text: {
        es: 'Desde 1976, la NASA ha depositado sobre Marte 9 naves exitosas junto con sus paracaídas, escudos térmicos, grúas aéreas (Sky Cranes) y lastres de tungsteno. Algunos siguen trabajando hoy; otros duermen bajo el polvo rojo tras años de servicio heroico.',
        en: 'Since 1976, NASA has placed 9 successful surface missions on Mars along with parachutes, heat shields, Sky Cranes, and tungsten ballasts. Some work actively today; others rest quietly under red dust after heroic careers.',
      },
      table: [
        [
          { es: 'Activos hoy', en: 'Active Today' },
          { es: 'Curiosity (desde 2012) y Perseverance (desde 2021) — ambos alimentados por Plutonio-238', en: 'Curiosity (since 2012) & Perseverance (since 2021) — both powered by Plutonium-238' },
        ],
        [
          { es: 'Silenciosos históricos', en: 'Historic Silent Craft' },
          { es: 'Viking 1 & 2 (1976), Pathfinder/Sojourner (1997), Spirit (2004), Phoenix (2008), Opportunity (2004–2018), InSight (2018–2022), Ingenuity (2021–2024)', en: 'Viking 1 & 2 (1976), Pathfinder/Sojourner (1997), Spirit (2004), Phoenix (2008), Opportunity (2004–2018), InSight (2018–2022), Ingenuity (2021–2024)' },
        ],
      ],
    },
    {
      id: 'sky_crane_debris',
      tag: { es: 'Ingeniería de descenso · JPL', en: 'Entry & Landing Hardware · JPL' },
      title: {
        es: 'Escudos térmicos, paracaídas y grúas Sky Crane en el suelo marciano',
        en: 'Heat Shields, Parachutes & Sky Cranes Left on Martian Soil',
      },
      text: {
        es: 'Aterrizar en Marte requiere frenar de 20,000 km/h a cero en solo 7 minutos ("Los 7 minutos de terror"). Para lograrlo, cada rover deja atrás su escudo térmico, su cápsula trasera con paracaídas supersónico y la etapa propulsada Sky Crane que se estrella a salvo a distancia.',
        en: 'Landing on Mars requires slowing from 20,000 km/h to zero in just 7 minutes ("7 Minutes of Terror"). Each rover leaves behind its heat shield, supersonic parachute backshell, and Sky Crane descent stage crashed safely nearby.',
      },
      table: [
        [
          { es: 'Paracaídas Perseverance', en: 'Perseverance Parachute' },
          { es: '21.5 m de diámetro · Llevaba un mensaje secreto en código binario: "Dare Mighty Things"', en: '21.5 m wide · Encoded a secret binary message: "Dare Mighty Things"' },
        ],
        [
          { es: 'Fotografiado por Ingenuity', en: 'Photographed by Ingenuity' },
          { es: 'En 2022, el helicóptero Ingenuity sobrevoló y fotografió el paracaídas y escudo de Perseverance tirados en el desierto', en: 'In 2022, Ingenuity flew over and photographed Perseverance’s discarded backshell and parachute' },
        ],
      ],
    },
  ],
  deep: [
    {
      id: 'outer_planets_abandoned',
      tag: { es: 'Sistema Solar Exterior · NASA', en: 'Outer Solar System · NASA' },
      title: {
        es: 'Naves en los otros planetas: De Mercurio a Saturno y las Estrellas',
        en: 'Hardware Across Other Worlds: From Mercury to Saturn & the Stars',
      },
      text: {
        es: 'No solo la Luna y Marte guardan reliquias de la NASA. Siete cuerpos más del Sistema Solar conservan sondas que impactaron intencionalmente o siguen viajando en silencio hacia el espacio profundo.',
        en: 'The Moon and Mars aren’t the only worlds holding NASA artifacts. Across the Solar System, probes have impacted planets intentionally or continue flying silently toward the stars.',
      },
      table: [
        [
          { es: 'Mercurio · MESSENGER', en: 'Mercury · MESSENGER' },
          { es: 'Impactó en 2015 al agotar combustible tras mapear el 100% del planeta y hallar hielo polar', en: 'Impacted in 2015 after mapping 100% of Mercury and finding polar water ice' },
        ],
        [
          { es: 'Venus · Pioneer Venus', en: 'Venus · Pioneer Venus' },
          { es: '4 sondas entraron en 1978; la Day Probe resistió 67 min sobre el suelo de 460 °C', en: '4 probes entered in 1978; Day Probe survived 67 min on the 460 °C surface' },
        ],
        [
          { es: 'Asteroides · NEAR & Dawn', en: 'Asteroids · NEAR & Dawn' },
          { es: 'NEAR descansa sobre el asteroide Eros (2001) y Dawn orbita en silencio Ceres (2018)', en: 'NEAR rests on asteroid Eros (2001) and Dawn silently orbits Ceres (2018)' },
        ],
        [
          { es: 'Júpiter · Galileo', en: 'Jupiter · Galileo' },
          { es: 'Cápsula enviada a las nubes en 1995; nave madre vaporizada en 2003 para proteger Europa', en: 'Probe descended into clouds in 1995; orbiter vaporized in 2003 to protect Europa' },
        ],
        [
          { es: 'Saturno · Cassini', en: 'Saturn · Cassini' },
          { es: 'Se sumergió en Saturno el 15 sep 2017 tras 13 años descubriendo océanos en Encélado', en: 'Plunged into Saturn Sept 15, 2017 after 13 years discovering oceans on Enceladus' },
        ],
        [
          { es: 'Interestelar · Voyager 1 y 2', en: 'Interstellar · Voyager 1 & 2' },
          { es: '¡Siguen activas desde 1977! Llevan el Disco de Oro más allá de Neptuno y Plutón', en: 'Still active since 1977! Carrying the Golden Record beyond Neptune and Pluto' },
        ],
      ],
    },
    {
      id: 'pioneer_voyager_records',
      tag: { es: 'Mensajes a las estrellas · NASA', en: 'Messages to the Stars · NASA' },
      title: {
        es: 'Placas de Pioneer y Discos de Oro de Voyager: Cápsulas del tiempo eternas',
        en: 'Pioneer Plaques & Voyager Golden Records: Eternal Time Capsules',
      },
      text: {
        es: 'Las sondas Pioneer 10 y 11 (hoy silenciosas) y las Voyager 1 y 2 (aún activas) viajan tan rápido que nunca regresarán al Sistema Solar. Para cualquier civilización futura, la NASA grabó en ellas quiénes somos y dónde vivimos.',
        en: 'Pioneer 10 & 11 (now silent) and Voyager 1 & 2 (still active) travel so fast they will never return. NASA placed engraved plaques and Golden Records aboard them to tell future finders who we are.',
      },
      table: [
        [
          { es: 'Contenido del Disco de Oro', en: 'Golden Record Contents' },
          { es: 'Saludos en 55 idiomas, cantos de ballenas, música de Bach y Chuck Berry ("Johnny B. Goode")', en: 'Greetings in 55 languages, whale songs, Bach, and Chuck Berry ("Johnny B. Goode")' },
        ],
        [
          { es: 'Mapa cósmico', en: 'Cosmic Map' },
          { es: 'Diagrama de 14 púlsares galácticos que señalan con precisión la posición del Sol', en: 'Diagram of 14 galactic pulsars pinpointing our Sun’s exact neighborhood' },
        ],
      ],
    },
  ],
  concepts: [
    {
      id: 'why_leave_behind',
      tag: { es: 'Física de cohetes · Ecuación de Tsiolkovski', en: 'Rocket Physics · Tsiolkovsky Equation' },
      title: {
        es: '¿Por qué la NASA deja tantos equipos abandonados en el espacio?',
        en: 'Why Does NASA Leave So Much Equipment Behind in Space?',
      },
      text: {
        es: 'Cada kilogramo que se trae de regreso desde la Luna o Marte exige multiplicar por decenas la cantidad de combustible necesario al despegar de la Tierra. Por eso es más inteligente dejar allá los rovers, patas de aterrizaje y baterías usadas.',
        en: 'Every kilogram brought back from the Moon or Mars requires exponentially more launch fuel on Earth. Leaving behind rovers, landing legs, and spent stages makes deep-space science possible.',
      },
      table: [
        [
          { es: 'Protección planetaria', en: 'Planetary Protection' },
          { es: 'Galileo y Cassini fueron destruidas en Júpiter y Saturno para evitar que bacterias terrestres accidentales contaminaran lunas con océanos como Europa o Encélado', en: 'Galileo and Cassini were vaporized in Jupiter and Saturn so Earth microbes could never contaminate ocean moons like Europa or Enceladus' },
        ],
        [
          { es: 'Preservación lunar', en: 'Lunar Preservation' },
          { es: 'Las huellas y módulos Apolo son tratados hoy como patrimonio histórico universal de la humanidad', en: 'Apollo bootprints and landers are protected guidelines as universal human heritage sites' },
        ],
      ],
    },
    {
      id: 'rtg_physics',
      tag: { es: 'Energía nuclear espacial', en: 'Nuclear Power in Space' },
      title: {
        es: 'Baterías atómicas RTG: El secreto para sobrevivir décadas lejos del Sol',
        en: 'RTG Atomic Batteries: Surviving Decades Far from the Sun',
      },
      text: {
        es: 'Los Generadores Termoeléctricos de Radioisótopos (RTG) usan el calor natural del Plutonio-238 (vida media de 87.7 años) para generar electricidad sin partes móviles. Así funcionan Curiosity, Perseverance y las Voyager en la oscuridad.',
        en: 'Radioisotope Thermoelectric Generators (RTGs) convert natural decay heat from Plutonium-238 (87.7-year half-life) directly into electricity with zero moving parts — powering Curiosity, Perseverance, and Voyager.',
      },
      table: [
        [
          { es: 'Paneles solares vs. RTG', en: 'Solar Panels vs. RTG' },
          { es: 'Opportunity y Spirit dependían del Sol (murieron por polvo o invierno); Curiosity y Voyager usan RTG', en: 'Opportunity & Spirit needed sunlight (stopped by dust/winter); Curiosity & Voyager use RTG heat' },
        ],
      ],
    },
    {
      id: 'black_sky',
      tag: { es: 'Óptica y vacío espacial', en: 'Optics & Space Vacuum' },
      title: {
        es: '¿Por qué el cielo lunar es negro y las huellas duran un millón de años?',
        en: 'Why Is the Lunar Sky Pitch Black and Footprints Last a Million Years?',
      },
      text: {
        es: 'Sin atmósfera que disperse la luz azul del Sol (dispersión de Rayleigh) ni viento o lluvia que erosione el polvo afilado de regolito, la Luna funciona como una cámara de vacío perfecta que congela cada artefacto en el tiempo.',
        en: 'Without air molecules to scatter blue sunlight or wind and rain to erode jagged regolith dust, the Moon acts like a giant vacuum chamber freezing every artifact in time.',
      },
      table: [
        [
          { es: 'Presión en la Luna vs. Marte', en: 'Moon vs. Mars Pressure' },
          { es: 'Luna: 3 × 10⁻¹⁵ atm (vacío) · Marte: 6.1 mbar (cielo caramelo con tormentas de polvo)', en: 'Moon: 3 × 10⁻¹⁵ atm (vacuum) · Mars: 6.1 mbar (butterscotch sky & dust storms)' },
        ],
      ],
    },
  ],
};

export const NASA_QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'q1',
    question: {
      es: '¿Cuál de estos artefactos dejados por la NASA en la Luna sigue generando datos científicos activos hoy en día?',
      en: 'Which NASA artifact left on the Moon is STILL actively generating scientific data today?',
    },
    options: {
      es: [
        'El Rover Lunar LRV-1 del Apolo 15',
        'Los Retrorreflectores Láser (LRRR) de Apolo 11, 14 y 15',
        'El Módulo Lunar Eagle del Apolo 11',
        'La batería nuclear SNAP-27',
      ],
      en: [
        'Apollo 15 Lunar Roving Vehicle LRV-1',
        'Laser Ranging Retroreflectors (LRRR) from Apollo 11, 14 & 15',
        'Apollo 11 Lunar Module Eagle',
        'SNAP-27 Atomic Battery',
      ],
    },
    correctIndex: 1,
    explanation: {
      es: 'Los retrorreflectores usan prismas de cuarzo sin baterías ni electricidad. Observatorios terrestres aún rebotan láseres contra ellos y miden que la Luna se aleja 3.8 cm al año.',
      en: 'The retroreflectors use zero-power quartz prisms. Earth observatories still bounce lasers off them, proving the Moon recedes 3.8 cm per year.',
    },
  },
  {
    id: 'q2',
    question: {
      es: '¿Qué objetos deportivos inesperados dejó Alan Shepard en la Luna durante la misión Apolo 14?',
      en: 'What unexpected sports items did Alan Shepard leave on the Moon during Apollo 14?',
    },
    options: {
      es: [
        'Un balón de baloncesto',
        'Dos pelotas de golf',
        'Un disco de hockey',
        'Una pelota de béisbol',
      ],
      en: ['A basketball', 'Two golf balls', 'A hockey puck', 'A baseball'],
    },
    correctIndex: 1,
    explanation: {
      es: 'Shepard llevó en secreto la cabeza de un palo hierro 6 y dos pelotas de golf para demostrar ante la TV cómo la baja gravedad (1/6 g) hace volar los objetos mucho más lejos.',
      en: 'Shepard brought a 6-iron club head and two golf balls to demonstrate live on TV how 1/6th gravity sends objects flying farther.',
    },
  },
  {
    id: 'q3',
    question: {
      es: '¿Por qué los astronautas del Apolo 12 caminaron hacia la sonda robótica Surveyor 3 en 1969?',
      en: 'Why did Apollo 12 astronauts walk over to the silent Surveyor 3 robotic lander in 1969?',
    },
    options: {
      es: [
        'Para recargarle las baterías solares',
        'Para desmontar su cámara y pala y estudiar cómo 31 meses en el vacío lunar afectaron sus materiales',
        'Para usarla como vehículo de transporte',
        'Para recuperar muestras de hielo marciano',
      ],
      en: [
        'To recharge its solar batteries',
        'To unbolt its camera and scoop to study how 31 months in lunar vacuum affected its materials',
        'To drive it like a rover',
        'To collect Mars ice samples',
      ],
    },
    correctIndex: 1,
    explanation: {
      es: 'Apolo 12 alunizó a 180 m de Surveyor 3 y trajo partes de vuelta a la Tierra, iniciando la arqueología espacial comparativa.',
      en: 'Apollo 12 landed 180 meters from Surveyor 3 and returned its camera and scoop to Earth for material degradation research.',
    },
  },
  {
    id: 'q4',
    question: {
      es: '¿Qué rover de la NASA fue diseñado para durar solo 90 días marcianos, pero exploró Marte durante más de 14 años y recorrió 45.16 km?',
      en: 'Which NASA rover was built for 90 Martian days, yet explored Mars for over 14 years and drove 45.16 km?',
    },
    options: {
      es: ['Sojourner', 'Opportunity (MER-B)', 'Phoenix', 'Viking 1'],
      en: ['Sojourner', 'Opportunity (MER-B)', 'Phoenix', 'Viking 1'],
    },
    correctIndex: 1,
    explanation: {
      es: 'Opportunity operó 5,111 soles hasta que una tormenta de polvo global tapó sus paneles solares en 2018.',
      en: 'Opportunity worked for 5,111 sols until a global dust storm blocked sunlight to its solar panels in 2018.',
    },
  },
  {
    id: 'q5',
    question: {
      es: '¿Qué logro histórico alcanzó el pequeño helicóptero Ingenuity en Marte antes de retirarse en 2024?',
      en: 'What historic milestone did the small Ingenuity helicopter achieve on Mars before retiring in 2024?',
    },
    options: {
      es: [
        'Perforó 50 metros bajo el suelo marciano',
        'Realizó 72 vuelos propulsados demostrando que es posible volar en la tenue atmósfera de Marte',
        'Regresó muestras de roca directamente a la Tierra',
        'Orbitó la luna Fobos',
      ],
      en: [
        'Drilled 50 meters underground',
        'Completed 72 powered flights proving aerodynamic flight works in Mars’s thin air',
        'Returned rock samples directly to Earth',
        'Orbited Mars’s moon Phobos',
      ],
    },
    correctIndex: 1,
    explanation: {
      es: 'Aunque solo estaba planeado para 5 vuelos de prueba, Ingenuity voló 72 veces y llevaba un trocito de tela del avión de los hermanos Wright.',
      en: 'Planned for just 5 test flights, Ingenuity flew 72 times and carried a tiny swatch of fabric from the 1903 Wright Flyer.',
    },
  },
  {
    id: 'q6',
    question: {
      es: '¿Qué descubrió la rueda delantera atascada del rover Spirit al arrastrarse sobre el suelo de Marte?',
      en: 'What did Spirit rover’s jammed front wheel accidentally uncover as it dragged through Martian soil?',
    },
    options: {
      es: [
        'Huesos fósiles de dinosaurios',
        'Sílice casi pura formada en antiguos manantiales de agua caliente',
        'Diamantes azules',
        'Un cable olvidado por Viking 1',
      ],
      en: [
        'Fossilized dinosaur bones',
        'Nearly pure silica formed in ancient hydrothermal hot springs',
        'Blue diamonds',
        'A cable left by Viking 1',
      ],
    },
    correctIndex: 1,
    explanation: {
      es: 'El surco reveló sílice hidrotermal, evidencia clave de antiguos ambientes cálidos y húmedos aptos para microbios.',
      en: 'The trench exposed hydrothermal silica, key evidence of ancient hot-spring environments capable of supporting microbial life.',
    },
  },
  {
    id: 'q7',
    question: {
      es: '¿Por qué la NASA estrelló intencionalmente las naves Galileo (en Júpiter) y Cassini (en Saturno) al final de sus misiones?',
      en: 'Why did NASA intentionally plunge Galileo (into Jupiter) and Cassini (into Saturn) at the end of their missions?',
    },
    options: {
      es: [
        'Para ahorrar espacio en el cielo',
        'Para evitar que bacterias terrestres contaminaran lunas con océanos subterráneos como Europa o Encélado',
        'Para probar bombas espaciales',
        'Porque no tenían cámaras',
      ],
      en: [
        'To clear space in the sky',
        'To prevent Earth microbes from ever contaminating subsurface ocean moons like Europa or Enceladus',
        'To test impact weapons',
        'Because they lacked cameras',
      ],
    },
    correctIndex: 1,
    explanation: {
      es: 'Por las reglas de Protección Planetaria de la NASA, destruir las naves en los gigantes gaseosos protegió posibles mundos habitables helados.',
      en: 'Under NASA Planetary Protection rules, vaporizing them in the gas giants protected potentially habitable ocean moons.',
    },
  },
  {
    id: 'q8',
    question: {
      es: '¿Qué nave de la NASA es la única en la historia que ha visitado tanto Urano como Neptuno y sigue activa hoy en el espacio interestelar?',
      en: 'Which NASA spacecraft is the only probe ever to visit both Uranus and Neptune and is still active in interstellar space?',
    },
    options: {
      es: ['Cassini', 'Voyager 2', 'MESSENGER', 'New Horizons'],
      en: ['Cassini', 'Voyager 2', 'MESSENGER', 'New Horizons'],
    },
    correctIndex: 1,
    explanation: {
      es: 'Lanzada en 1977, Voyager 2 aprovechó una alineación planetaria única cada 176 años para visitar Júpiter, Saturno, Urano y Neptuno.',
      en: 'Launched in 1977, Voyager 2 rode a once-in-176-years alignment to fly past Jupiter, Saturn, Uranus, and Neptune.',
    },
  },
];
