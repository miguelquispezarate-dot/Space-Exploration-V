export type Language = 'es' | 'en';

export type DisplayMode = 'auto' | 'laptop' | 'mobile';

export type ScreenView = 'launch' | 'solar' | 'surface';

export type SurfaceBodyId = 'moon' | 'mars';

export type OperationalStatus = 'active' | 'silent' | 'impacted';

export type EncyclopediaTabId = 'apollo' | 'mars' | 'deep' | 'concepts' | 'quiz';

export type CelestialTextureType =
  | 'sun'
  | 'mercury'
  | 'venus'
  | 'earth'
  | 'moon'
  | 'mars'
  | 'asteroids'
  | 'jupiter'
  | 'saturn'
  | 'uranus'
  | 'neptune'
  | 'kepler'
  | 'voyager';

export interface CelestialBody {
  id: string;
  name: Record<Language, string>;
  shortName: Record<Language, string>;
  tag: Record<Language, string>;
  dist: Record<Language, string>;
  grav: string;
  diam: string;
  missions: string[];
  narrative: Record<Language, string>;
  leftBehindSummary: Record<Language, string>;
  leftBehindStatus: OperationalStatus;
  color: string;
  radius: number;
  orbitRadius: number;
  speed: number;
  hasSurface: boolean;
  surfaceType?: SurfaceBodyId;
  textureType: CelestialTextureType;
}

export type SchematicIconType =
  | 'lunar_module'
  | 'lrv_rover'
  | 'snap27'
  | 'rover_curiosity'
  | 'rover_mer'
  | 'helicopter'
  | 'footprint'
  | 'lrrr'
  | 'volcano'
  | 'pathfinder'
  | 'viking'
  | 'fallen_astronaut'
  | 'surveyor'
  | 'golf_met'
  | 'uv_camera'
  | 'insight'
  | 'phoenix';

export type SurfaceBehaviorState =
  | 'patrol_active'
  | 'slow_worn_drive'
  | 'damaged_rotor_wind'
  | 'stuck_in_sand'
  | 'dust_hibernation'
  | 'misaligned_antenna'
  | 'laser_bounce'
  | 'seismic_station'
  | 'polar_frost'
  | 'static_heritage';

export interface SurfaceHotspot {
  id: string;
  name: Record<Language, string>;
  shortLabel: Record<Language, string>;
  category: Record<Language, string>;
  status: OperationalStatus;
  statusNote: Record<Language, string>;
  behaviorState: SurfaceBehaviorState;
  missionYear: number;
  x: number;
  yRatio: number;
  year: Record<Language, string>;
  coords: Record<Language, string>;
  crew: Record<Language, string>;
  prop: Record<Language, string>;
  iconType: SchematicIconType;
  whySent: Record<Language, string>;
  discoveries: Record<Language, string>;
  didactic: Record<Language, string>;
  desc: Record<Language, string>;
}

export interface EncyclopediaArticle {
  id: string;
  tag: Record<Language, string>;
  title: Record<Language, string>;
  text: Record<Language, string>;
  table: Array<[Record<Language, string>, Record<Language, string>]>;
}

export interface QuizQuestion {
  id: string;
  question: Record<Language, string>;
  options: Record<Language, string[]>;
  correctIndex: number;
  explanation: Record<Language, string>;
}
